from __future__ import annotations

import math
from pathlib import Path
import shutil

import numpy as np

from .advanced_sensors import ADVANCED_LIDAR_RING_PITCHES, ADVANCED_LIDAR_RAYS
from .advanced_track import AdvancedTrackWorld
from .mjcf import CAR_COLLISION_HALF_HEIGHT, CAR_COLLISION_HALF_LENGTH, CAR_COLLISION_HALF_WIDTH, _resolve_color
from .track import TrackGeometry, SegmentStyle


WALL_SINK_DEPTH = 0.08
WALL_BOTTOM_MARGIN = 0.016
WALL_LENGTH_OVERLAP = 0.0
CURB_SINK_DEPTH = 0.012
CURB_BOTTOM_MARGIN = 0.008
CURB_LENGTH_OVERLAP = 0.04
CURB_WIDTH_PAD = 0.006
CURB_SURFACE_LIFT = 0.0
CURB_SIDE_SINK = 0.005


def _write_strip_mesh_3d(path: Path, left: np.ndarray, right: np.ndarray) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for point in left:
            handle.write(f"v {point[0]:.6f} {point[1]:.6f} {point[2]:.6f}\n")
        for point in right:
            handle.write(f"v {point[0]:.6f} {point[1]:.6f} {point[2]:.6f}\n")

        count = len(left)
        for index in range(count):
            next_index = (index + 1) % count
            a = index + 1
            b = next_index + 1
            c = count + index + 1
            d = count + next_index + 1
            handle.write(f"f {a} {b} {d}\n")
            handle.write(f"f {a} {d} {c}\n")


def _write_grid_mesh(path: Path, grid_x: np.ndarray, grid_y: np.ndarray, grid_z: np.ndarray) -> None:
    rows, cols = grid_x.shape
    with path.open("w", encoding="utf-8") as handle:
        for row in range(rows):
            for col in range(cols):
                handle.write(f"v {grid_x[row, col]:.6f} {grid_y[row, col]:.6f} {grid_z[row, col]:.6f}\n")
        for row in range(rows - 1):
            for col in range(cols - 1):
                a = row * cols + col + 1
                b = a + 1
                c = a + cols
                d = c + 1
                handle.write(f"f {a} {b} {d}\n")
                handle.write(f"f {a} {d} {c}\n")


def _unit(vector: np.ndarray, fallback: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if norm <= 1e-8:
        return np.asarray(fallback, dtype=np.float32)
    return (vector / norm).astype(np.float32)


def _oriented_quad(
    a: np.ndarray,
    b: np.ndarray,
    c: np.ndarray,
    d: np.ndarray,
    desired_normal: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    normal = np.cross(b - a, d - a)
    if float(np.dot(normal, desired_normal)) >= 0.0:
        return a, b, c, d
    return a, d, c, b


def _write_quad_mesh(path: Path, quads: list[tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for quad in quads:
            for point in quad:
                handle.write(f"v {point[0]:.6f} {point[1]:.6f} {point[2]:.6f}\n")
        for index in range(len(quads)):
            start = index * 4 + 1
            a = start
            b = start + 1
            c = start + 2
            d = start + 3
            handle.write(f"f {a} {b} {c}\n")
            handle.write(f"f {a} {c} {d}\n")


def _euler_matrix(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cr = math.cos(roll)
    sr = math.sin(roll)
    cp = math.cos(pitch)
    sp = math.sin(pitch)
    cy = math.cos(yaw)
    sy = math.sin(yaw)
    rx = np.array([[1.0, 0.0, 0.0], [0.0, cr, -sr], [0.0, sr, cr]], dtype=np.float32)
    ry = np.array([[cp, 0.0, sp], [0.0, 1.0, 0.0], [-sp, 0.0, cp]], dtype=np.float32)
    rz = np.array([[cy, -sy, 0.0], [sy, cy, 0.0], [0.0, 0.0, 1.0]], dtype=np.float32)
    return (rz @ ry @ rx).astype(np.float32)


def _segment_bottom_clearance(
    world: AdvancedTrackWorld,
    *,
    position: np.ndarray,
    euler: tuple[float, float, float],
    size: np.ndarray,
) -> float:
    rotation = _euler_matrix(*euler)
    max_gap = -float("inf")
    for length_sign in (-1.0, 1.0):
        for width_sign in (-1.0, 1.0):
            local = np.array(
                [
                    float(size[0]) * length_sign,
                    float(size[1]) * width_sign,
                    -float(size[2]),
                ],
                dtype=np.float32,
            )
            corner = position + rotation @ local
            sample = world.sample_surface(corner[:2])
            max_gap = max(max_gap, float(corner[2] - sample.height))
    return 0.0 if not math.isfinite(max_gap) else max_gap


def _segment_pose(
    world: AdvancedTrackWorld,
    segment: SegmentStyle,
    *,
    size: np.ndarray,
    sink_depth: float,
    bottom_margin: float,
) -> tuple[np.ndarray, tuple[float, float, float]]:
    sample = world.sample_surface(np.asarray(segment.position[:2], dtype=np.float32))
    half_height = float(size[2])
    euler = (float(sample.roll), float(-sample.pitch), float(segment.yaw))
    position = np.array(
        [
            segment.position[0],
            segment.position[1],
            sample.height + half_height - sink_depth * 0.5,
        ],
        dtype=np.float32,
    )
    floating_gap = _segment_bottom_clearance(world, position=position, euler=euler, size=size)
    if floating_gap > -bottom_margin:
        position[2] -= floating_gap + bottom_margin
    return position, euler


def _segment_visual_size(
    segment: SegmentStyle,
    *,
    length_overlap: float,
    sink_depth: float,
    width_pad: float = 0.0,
) -> np.ndarray:
    return np.array(
        [
            float(segment.size[0]) + max(0.0, length_overlap),
            float(segment.size[1]) + max(0.0, width_pad),
            float(segment.size[2]) + max(0.0, sink_depth) * 0.5,
        ],
        dtype=np.float32,
    )


def _scene_segments(geometry: TrackGeometry, *, reduced_scene_complexity: bool) -> tuple[list[SegmentStyle], list[SegmentStyle]]:
    if not reduced_scene_complexity:
        return geometry.curb_segments, geometry.wall_segments
    return geometry.curb_segments[::2], geometry.wall_segments[::2]


def _build_curb_mesh_files(
    *,
    session_dir: Path,
    geometry: TrackGeometry,
    world: AdvancedTrackWorld,
    reduced_scene_complexity: bool,
) -> dict[str, Path]:
    color_quads: dict[str, list[tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]] = {"red": [], "white": []}

    def append_side(
        road_edge: np.ndarray,
        curb_center: np.ndarray,
        *,
        side_sign: float,
    ) -> None:
        count = len(road_edge)
        if count == 0:
            return

        outer_edge = (curb_center * 2.0 - road_edge).astype(np.float32)
        progresses = geometry.cumulative_lengths[:count]
        road_surface_points: list[np.ndarray] = []
        curb_top_points: list[np.ndarray] = []
        curb_base_points: list[np.ndarray] = []
        ups: list[np.ndarray] = []
        outs: list[np.ndarray] = []

        outer_offset = side_sign * (geometry.settings.half_width + geometry.settings.curb_width)
        road_offset = side_sign * geometry.settings.half_width

        for index in range(count):
            progress = float(progresses[index])
            road_surface_sample = world.sample_surface_at_progress(progress, lateral_offset=road_offset)
            curb_surface_sample = world.sample_surface_at_progress(progress, lateral_offset=outer_offset)
            avg_up = np.array([0.0, 0.0, 1.0], dtype=np.float32)
            road_surface = np.asarray(road_edge[index], dtype=np.float32) + avg_up * CURB_SURFACE_LIFT
            outer_surface = np.asarray(outer_edge[index], dtype=np.float32)
            curb_top = outer_surface + avg_up * (geometry.settings.curb_height + CURB_SURFACE_LIFT)
            curb_base = outer_surface - avg_up * CURB_SIDE_SINK
            outward_xy = np.array(
                [
                    float(outer_surface[0] - road_surface[0]),
                    float(outer_surface[1] - road_surface[1]),
                    0.0,
                ],
                dtype=np.float32,
            )
            outward = _unit(
                outward_xy,
                fallback=np.array(
                    [
                        float(curb_surface_sample.lateral3d[0]),
                        float(curb_surface_sample.lateral3d[1]),
                        0.0,
                    ],
                    dtype=np.float32,
                ),
            )
            road_surface_points.append(road_surface.astype(np.float32))
            curb_top_points.append(curb_top.astype(np.float32))
            curb_base_points.append(curb_base.astype(np.float32))
            ups.append(avg_up.astype(np.float32))
            outs.append(outward.astype(np.float32))

        stripe_length = max(0.45, float(geometry.settings.panel_length) * (1.70 if reduced_scene_complexity else 0.85))
        distance_accum = 0.0
        for index in range(count):
            next_index = (index + 1) % count
            midpoint_a = 0.5 * (road_surface_points[index] + curb_top_points[index])
            midpoint_b = 0.5 * (road_surface_points[next_index] + curb_top_points[next_index])
            segment_length = float(np.linalg.norm(midpoint_b[:2] - midpoint_a[:2]))
            color = "red" if int(distance_accum / stripe_length) % 2 == 0 else "white"
            avg_up = _unit(ups[index] + ups[next_index], fallback=np.array([0.0, 0.0, 1.0], dtype=np.float32))
            avg_out = _unit(outs[index] + outs[next_index], fallback=outs[index])
            top_quad = _oriented_quad(
                road_surface_points[index],
                road_surface_points[next_index],
                curb_top_points[next_index],
                curb_top_points[index],
                avg_up,
            )
            side_quad = _oriented_quad(
                curb_base_points[index],
                curb_top_points[index],
                curb_top_points[next_index],
                curb_base_points[next_index],
                avg_out,
            )
            color_quads[color].append(top_quad)
            color_quads[color].append(side_quad)
            distance_accum += segment_length

    append_side(world.track_outer_3d, world.outer_curb_3d, side_sign=1.0)
    append_side(world.track_inner_3d, world.inner_curb_3d, side_sign=-1.0)

    mesh_paths: dict[str, Path] = {}
    for color, quads in color_quads.items():
        if not quads:
            continue
        path = session_dir / f"curb_{color}.obj"
        _write_quad_mesh(path, quads)
        mesh_paths[color] = path
    return mesh_paths


def _build_wall_mesh_files(
    *,
    session_dir: Path,
    geometry: TrackGeometry,
    world: AdvancedTrackWorld,
    reduced_scene_complexity: bool,
) -> dict[str, Path]:
    color_quads: dict[str, list[tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]] = {"light": [], "dark": []}

    def append_side(face_points: np.ndarray, *, side_sign: float) -> None:
        count = len(face_points)
        if count == 0:
            return
        step = 2 if reduced_scene_complexity else 1
        indices = list(range(0, count, step))
        if indices[-1] != count - 1:
            indices.append(count - 1)
        distance_accum = 0.0
        panel_length = max(0.55, float(geometry.settings.panel_length) * (1.8 if reduced_scene_complexity else 1.0))
        wall_height = float(geometry.settings.wall_height)
        wall_thickness = float(geometry.settings.wall_thickness)
        lateral_offset = side_sign * (geometry.settings.half_width + geometry.settings.curb_width + geometry.settings.wall_gap)

        face_lower: list[np.ndarray] = []
        face_top: list[np.ndarray] = []
        outer_lower: list[np.ndarray] = []
        outer_top: list[np.ndarray] = []
        ups: list[np.ndarray] = []
        outs: list[np.ndarray] = []
        for index in indices:
            progress = float(geometry.cumulative_lengths[index])
            sample = world.sample_surface_at_progress(progress, lateral_offset=lateral_offset, index_hint=index)
            up = np.array([0.0, 0.0, 1.0], dtype=np.float32)
            outward = _unit(
                np.array(
                    [
                        float(sample.lateral3d[0]) * float(side_sign),
                        float(sample.lateral3d[1]) * float(side_sign),
                        0.0,
                    ],
                    dtype=np.float32,
                ),
                fallback=np.array([0.0, side_sign, 0.0], dtype=np.float32),
            )
            face = np.asarray(face_points[index], dtype=np.float32)
            lower = face - up * WALL_SINK_DEPTH
            top = face + up * wall_height
            outer = face + outward * wall_thickness
            face_lower.append(lower.astype(np.float32))
            face_top.append(top.astype(np.float32))
            outer_lower.append((outer - up * WALL_SINK_DEPTH).astype(np.float32))
            outer_top.append((outer + up * wall_height).astype(np.float32))
            ups.append(up.astype(np.float32))
            outs.append(outward.astype(np.float32))

        for local_index in range(len(indices)):
            next_local = (local_index + 1) % len(indices)
            if next_local == 0:
                next_index = indices[0] + count
                current_index = indices[local_index]
            else:
                next_index = indices[next_local]
                current_index = indices[local_index]
            segment_length = float(np.linalg.norm(face_points[next_index % count] - face_points[current_index % count]))
            color = "light" if int(distance_accum / panel_length) % 2 == 0 else "dark"
            avg_up = _unit(ups[local_index] + ups[next_local], fallback=np.array([0.0, 0.0, 1.0], dtype=np.float32))
            avg_out = _unit(outs[local_index] + outs[next_local], fallback=outs[local_index])
            road_face = _oriented_quad(
                face_lower[local_index],
                face_lower[next_local],
                face_top[next_local],
                face_top[local_index],
                -avg_out,
            )
            outer_face = _oriented_quad(
                outer_lower[local_index],
                outer_top[local_index],
                outer_top[next_local],
                outer_lower[next_local],
                avg_out,
            )
            top_face = _oriented_quad(
                face_top[local_index],
                face_top[next_local],
                outer_top[next_local],
                outer_top[local_index],
                avg_up,
            )
            color_quads[color].append(road_face)
            color_quads[color].append(outer_face)
            color_quads[color].append(top_face)
            distance_accum += segment_length

    append_side(world.outer_wall_3d, side_sign=1.0)
    append_side(world.inner_wall_3d, side_sign=-1.0)

    mesh_paths: dict[str, Path] = {}
    for color, quads in color_quads.items():
        if not quads:
            continue
        path = session_dir / f"wall_{color}.obj"
        _write_quad_mesh(path, quads)
        mesh_paths[color] = path
    return mesh_paths


def build_advanced_mjcf(
    *,
    session_dir: Path,
    template_dir: Path,
    geometry: TrackGeometry,
    world: AdvancedTrackWorld,
    cars: list[dict],
    reduced_scene_complexity: bool = False,
) -> Path:
    session_dir.mkdir(parents=True, exist_ok=True)
    icons_src = template_dir / "icons"
    icons_dst = session_dir / "icons"
    if icons_src.is_dir():
        shutil.copytree(icons_src, icons_dst, dirs_exist_ok=True)

    track_mesh = session_dir / "track_surface_advanced.obj"
    _write_strip_mesh_3d(track_mesh, world.track_inner_3d, world.track_outer_3d)

    terrain_mesh = None
    terrain_grid = world.terrain_grid()
    if terrain_grid is not None:
        terrain_mesh = session_dir / "terrain_surface.obj"
        _write_grid_mesh(terrain_mesh, *terrain_grid)

    finish_progress = float(world.base_geometry.cumulative_lengths[0])
    finish_left = world.sample_surface_at_progress(finish_progress, lateral_offset=-geometry.settings.half_width)
    finish_right = world.sample_surface_at_progress(finish_progress, lateral_offset=geometry.settings.half_width)
    finish_center = 0.5 * (
        np.array([geometry.finish_line[0][0], geometry.finish_line[0][1], finish_left.height], dtype=np.float32)
        + np.array([geometry.finish_line[1][0], geometry.finish_line[1][1], finish_right.height], dtype=np.float32)
    )
    finish_delta = np.array(
        [
            geometry.finish_line[1][0] - geometry.finish_line[0][0],
            geometry.finish_line[1][1] - geometry.finish_line[0][1],
            finish_right.height - finish_left.height,
        ],
        dtype=np.float32,
    )
    finish_yaw = math.atan2(float(finish_delta[1]), float(finish_delta[0]))
    finish_pitch = -math.atan2(float(finish_delta[2]), max(1e-6, math.hypot(float(finish_delta[0]), float(finish_delta[1]))))
    finish_len = float(np.linalg.norm(finish_delta))

    curb_mesh_paths = _build_curb_mesh_files(
        session_dir=session_dir,
        geometry=geometry,
        world=world,
        reduced_scene_complexity=reduced_scene_complexity,
    )
    wall_mesh_paths = _build_wall_mesh_files(
        session_dir=session_dir,
        geometry=geometry,
        world=world,
        reduced_scene_complexity=reduced_scene_complexity,
    )

    xml: list[str] = []
    xml.append("<mujoco>")
    xml.append('  <compiler angle="radian" autolimits="true"/>')
    xml.append('  <option timestep="0.0083333333" gravity="0 0 -9.81"/>')
    xml.append("  <visual>")
    xml.append('    <global offwidth="4096" offheight="2160"/>')
    xml.append('    <headlight ambient="0.28 0.28 0.30" diffuse="0.66 0.66 0.68" specular="0.10 0.10 0.10"/>')
    xml.append('    <rgba haze="0.07 0.08 0.09 1"/>')
    xml.append("  </visual>")
    xml.append("  <asset>")
    xml.append('    <texture name="grass" type="2d" builtin="checker" rgb1="0.11 0.14 0.12" rgb2="0.08 0.10 0.09" width="512" height="512"/>')
    xml.append('    <material name="ground" texture="grass" texrepeat="16 16" reflectance="0.01"/>')
    xml.append('    <material name="asphalt" rgba="0.19 0.19 0.20 1.0" specular="0.03" shininess="0.08"/>')
    xml.append('    <material name="finish" rgba="0.98 0.98 0.98 1.0"/>')
    xml.append('    <material name="curb_red" rgba="0.73 0.12 0.10 1.0" specular="0.02" shininess="0.05"/>')
    xml.append('    <material name="curb_white" rgba="0.93 0.93 0.92 1.0" specular="0.02" shininess="0.05"/>')
    xml.append('    <material name="wall_light" rgba="0.80 0.82 0.84 1.0" specular="0.02" shininess="0.04"/>')
    xml.append('    <material name="wall_dark" rgba="0.69 0.72 0.75 1.0" specular="0.02" shininess="0.04"/>')
    xml.append(f'    <mesh name="track_surface" file="{track_mesh.as_posix()}" inertia="shell"/>')
    if terrain_mesh is not None:
        xml.append(f'    <mesh name="terrain_surface" file="{terrain_mesh.as_posix()}" inertia="shell"/>')
    for color, path in curb_mesh_paths.items():
        xml.append(f'    <mesh name="curb_{color}_mesh" file="{path.as_posix()}" inertia="shell"/>')
    for color, path in wall_mesh_paths.items():
        xml.append(f'    <mesh name="wall_{color}_mesh" file="{path.as_posix()}" inertia="shell"/>')
    icon_flags: list[bool] = []
    for index, car in enumerate(cars):
        primary = _resolve_color(car.get("primary", "red"))
        secondary = _resolve_color(car.get("secondary", "white"))
        xml.append(f'    <material name="car_{index}_primary" rgba="{primary[0]} {primary[1]} {primary[2]} 1"/>')
        xml.append(f'    <material name="car_{index}_secondary" rgba="{secondary[0]} {secondary[1]} {secondary[2]} 1"/>')
        xml.append(f'    <material name="car_{index}_wheel" rgba="0.08 0.08 0.08 1"/>')
        icon_name = car.get("icon") or ""
        has_icon = bool(icon_name and (icons_dst / icon_name).is_file())
        icon_flags.append(has_icon)
        if has_icon:
            xml.append(f'    <texture type="2d" name="car_{index}_icon_tex" file="{(icons_dst / icon_name).as_posix()}"/>')
            xml.append(f'    <material name="car_{index}_icon" texture="car_{index}_icon_tex" rgba="1 1 1 1"/>')
    xml.append("  </asset>")
    xml.append("  <worldbody>")
    xml.append('    <light pos="0 0 22" dir="0 0 -1" diffuse="0.85 0.85 0.85"/>')
    xml.append('    <geom name="ground" type="plane" size="240 240 0.1" pos="0 0 -2.5" material="ground" friction="1.4 0.01 0.01"/>')
    if terrain_mesh is not None:
        xml.append('    <geom name="terrain_visual" type="mesh" mesh="terrain_surface" material="ground" contype="0" conaffinity="0"/>')
    xml.append('    <geom name="track_visual" type="mesh" mesh="track_surface" material="asphalt" contype="0" conaffinity="0"/>')
    xml.append(
        f'    <geom name="finish_line" type="box" size="{finish_len * 0.5:.6f} 0.05 0.002" '
        f'pos="{finish_center[0]:.6f} {finish_center[1]:.6f} {finish_center[2] + 0.012:.6f}" '
        f'euler="0 {finish_pitch:.6f} {finish_yaw:.6f}" material="finish" contype="0" conaffinity="0"/>'
    )

    for color in ("red", "white"):
        if color not in curb_mesh_paths:
            continue
        xml.append(
            f'    <geom name="curb_{color}" type="mesh" mesh="curb_{color}_mesh" material="curb_{color}" contype="0" conaffinity="0"/>'
        )

    for color in ("light", "dark"):
        if color not in wall_mesh_paths:
            continue
        xml.append(
            f'    <geom name="wall_{color}" type="mesh" mesh="wall_{color}_mesh" material="wall_{color}" friction="0.9 0.01 0.01"/>'
        )

    for index, car in enumerate(cars):
        xml.extend(_car_body_xml_advanced(i=index, rangefinders=ADVANCED_LIDAR_RAYS, ring_pitches=ADVANCED_LIDAR_RING_PITCHES, has_icon=icon_flags[index]))
    xml.append("  </worldbody>")
    xml.append("  <sensor>")
    for index, _car in enumerate(cars):
        for ring_index, _pitch in enumerate(ADVANCED_LIDAR_RING_PITCHES):
            for ray in range(ADVANCED_LIDAR_RAYS):
                xml.append(f'    <rangefinder name="rangefinder_{index}_{ring_index}_{ray}" site="rangefinder_{index}_{ring_index}_{ray}"/>')
    xml.append("  </sensor>")
    xml.append("</mujoco>")

    mjcf_path = session_dir / "world.xml"
    mjcf_path.write_text("\n".join(xml), encoding="utf-8")
    return mjcf_path


def _car_body_xml_advanced(*, i: int, rangefinders: int, ring_pitches: tuple[float, ...], has_icon: bool) -> list[str]:
    inter_ray_angle = 360.0 / rangefinders
    rx, ry, rz = -0.04, 0.0, 0.12
    lr = 0.03
    lines = [
        f'    <body name="car_{i}" pos="0 0 0.08">',
        f'      <freejoint name="car_{i}"/>',
        f'      <geom name="car_{i}_collision" type="box" size="{CAR_COLLISION_HALF_LENGTH:.3f} {CAR_COLLISION_HALF_WIDTH:.3f} {CAR_COLLISION_HALF_HEIGHT:.3f}" rgba="0 0 0 0" mass="3.0" friction="1.4 0.01 0.01"/>',
        f'      <geom name="car_{i}_floor" type="box" size="0.33 0.15 0.012" pos="0 0 0.018" rgba="0.10 0.10 0.10 1" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_pod_l" type="box" size="0.15 0.05 0.026" pos="0.03 0.095 0.043" material="car_{i}_primary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_pod_r" type="box" size="0.15 0.05 0.026" pos="0.03 -0.095 0.043" material="car_{i}_primary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_spine" type="box" size="0.20 0.045 0.030" pos="0.01 0 0.055" material="car_{i}_primary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_nose" type="box" size="0.15 0.032 0.020" pos="0.28 0 0.042" material="car_{i}_secondary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_cockpit" type="box" size="0.08 0.055 0.024" pos="-0.03 0 0.066" rgba="0.12 0.13 0.14 1" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_front_wing" type="box" size="0.06 0.21 0.006" pos="0.37 0 0.020" material="car_{i}_secondary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_rear_wing" type="box" size="0.04 0.18 0.028" pos="-0.31 0 0.085" material="car_{i}_secondary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_fl" type="cylinder" size="0.055 0.020" pos="0.18 0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_fr" type="cylinder" size="0.055 0.020" pos="0.18 -0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_bl" type="cylinder" size="0.058 0.022" pos="-0.16 0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_br" type="cylinder" size="0.058 0.022" pos="-0.16 -0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_lidar" type="cylinder" size="0.032 0.010" pos="{rx:.6f} {ry:.6f} {rz:.6f}" rgba="0.88 0.88 0.88 1" contype="0" conaffinity="0"/>',
    ]
    if has_icon:
        lines.append(f'      <site type="ellipsoid" size="0.032 0.032 0.003" pos="{rx:.6f} {ry:.6f} {rz + 0.016:.6f}" material="car_{i}_icon"/>')
    for ring_index, pitch_deg in enumerate(ring_pitches):
        for ray in range(rangefinders):
            angle_deg = inter_ray_angle * ray - 90.0
            theta = -math.radians(angle_deg)
            lines.append(
                f'      <site name="rangefinder_{i}_{ring_index}_{ray}" '
                f'pos="{rx + lr * math.sin(theta):.6f} {lr * math.cos(theta):.6f} {rz:.6f}" '
                f'euler="{math.radians(90.0 - pitch_deg):.6f} {math.radians(angle_deg):.6f} 0" rgba="0 0 0 0"/>'
            )
    lines.append("    </body>")
    return lines
