from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
import gc
import importlib.util
import inspect
import json
import math
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile
import textwrap
import time
import traceback
from typing import Callable

import mujoco
import numpy as np
import pygame

try:  # Pygame keeps multi-window support under the optional SDL2 module.
    from pygame._sdl2.video import Renderer as SDLRenderer
    from pygame._sdl2.video import Texture as SDLTexture
    from pygame._sdl2.video import Window as SDLWindow
except Exception:  # pragma: no cover - depends on the installed pygame build.
    SDLRenderer = None
    SDLTexture = None
    SDLWindow = None

from .advanced_dynamics import AdvancedDynamicsFactors, combine_surface_dynamics, vertical_load_factor
from .advanced_mjcf import build_advanced_mjcf
from .advanced_sensors import ADVANCED_LIDAR_RING_PITCHES, ADVANCED_LIDAR_RAYS, AdvancedObservation, flatten_legacy_lidar, reshape_advanced_ranges
from .advanced_track import DEFAULT_ADVANCED_TRACK, AdvancedTrackSpec, AdvancedTrackWorld, discover_advanced_tracks, load_advanced_track_spec, load_advanced_world
from .mjcf import CAR_COLLISION_HALF_LENGTH, CAR_COLLISION_HALF_WIDTH, build_mjcf
from .track import DEFAULT_TRACKS, SegmentStyle, TrackGeometry, TrackSettings, discover_tracks, load_track_geometry


def _clip(value: float, lower: float, upper: float) -> float:
    return lower if value < lower else upper if value > upper else value


def _lerp(a: float, b: float, alpha: float) -> float:
    return a + (b - a) * alpha


def _blend_angle(current: float, target: float, alpha: float) -> float:
    delta = (target - current + math.pi) % (2.0 * math.pi) - math.pi
    return current + delta * alpha


def _cross_2d(a: np.ndarray, b: np.ndarray) -> float:
    return float(a[0] * b[1] - a[1] * b[0])


def _yaw_to_quaternion(yaw: float) -> np.ndarray:
    return _euler_to_quaternion(0.0, 0.0, yaw)


def _euler_to_quaternion(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    return np.array(
        [
            cr * cp * cy + sr * sp * sy,
            sr * cp * cy - cr * sp * sy,
            cr * sp * cy + sr * cp * sy,
            cr * cp * sy - sr * sp * cy,
        ],
        dtype=np.float64,
    )


def _euler_to_matrix(roll: float, pitch: float, yaw: float) -> np.ndarray:
    cy = math.cos(yaw)
    sy = math.sin(yaw)
    cp = math.cos(pitch)
    sp = math.sin(pitch)
    cr = math.cos(roll)
    sr = math.sin(roll)
    rx = np.array([[1.0, 0.0, 0.0], [0.0, cr, -sr], [0.0, sr, cr]], dtype=np.float64)
    ry = np.array([[cp, 0.0, sp], [0.0, 1.0, 0.0], [-sp, 0.0, cp]], dtype=np.float64)
    rz = np.array([[cy, -sy, 0.0], [sy, cy, 0.0], [0.0, 0.0, 1.0]], dtype=np.float64)
    return rz @ ry @ rx


def _format_seconds(value: float | None) -> str:
    if value is None:
        return "--"
    if value >= 60.0:
        minutes = int(value // 60.0)
        seconds = value - minutes * 60.0
        return f"{minutes}:{seconds:05.2f}"
    return f"{value:.2f}s"


def _progress_arc_distance(start: float, end: float, direction: int) -> float:
    if direction >= 0:
        return (end - start) % 1.0
    return (start - end) % 1.0


_GRADIENT_CACHE: dict[tuple[tuple[int, int], tuple[int, int, int], tuple[int, int, int]], pygame.Surface] = {}
_TEXT_CACHE: dict[tuple[int, str, tuple[int, int, int]], pygame.Surface] = {}
_ALPHA_SURFACE_CACHE: dict[tuple[tuple[int, int], tuple[int, int, int, int]], pygame.Surface] = {}


def _text_surface(font: pygame.font.Font, text: str, color: tuple[int, int, int]) -> pygame.Surface:
    key = (id(font), text, color)
    cached = _TEXT_CACHE.get(key)
    if cached is None:
        cached = font.render(text, True, color)
        _TEXT_CACHE[key] = cached
    return cached


def _alpha_surface(size: tuple[int, int], color: tuple[int, int, int, int]) -> pygame.Surface:
    key = ((int(size[0]), int(size[1])), color)
    cached = _ALPHA_SURFACE_CACHE.get(key)
    if cached is None:
        cached = pygame.Surface(key[0], pygame.SRCALPHA)
        cached.fill(color)
        _ALPHA_SURFACE_CACHE[key] = cached
    return cached


def _fit_text(font: pygame.font.Font, text: str, max_width: int) -> str:
    if max_width <= 0:
        return ""
    if font.size(text)[0] <= max_width:
        return text
    ellipsis = "..."
    if font.size(ellipsis)[0] > max_width:
        return ""
    stripped = text.strip()
    low = 0
    high = len(stripped)
    best = ellipsis
    while low <= high:
        mid = (low + high) // 2
        candidate = stripped[:mid].rstrip()
        if candidate:
            candidate = f"{candidate}{ellipsis}"
        else:
            candidate = ellipsis
        if font.size(candidate)[0] <= max_width:
            best = candidate
            low = mid + 1
        else:
            high = mid - 1
    return best


def _select_fitting_font(
    fonts: list[pygame.font.Font] | tuple[pygame.font.Font, ...],
    text: str,
    max_width: int,
) -> tuple[pygame.font.Font, str]:
    if not fonts:
        raise ValueError("at least one font is required")
    if max_width <= 0:
        return fonts[-1], ""
    for font in fonts:
        if font.size(text)[0] <= max_width:
            return font, text
    fallback = fonts[-1]
    return fallback, _fit_text(fallback, text, max_width)


def _wrap_text_lines(
    font: pygame.font.Font,
    text: str,
    max_width: int,
    *,
    max_lines: int | None = None,
) -> list[str]:
    normalized = " ".join(str(text).split())
    if not normalized:
        return []
    words = normalized.split(" ")
    lines: list[str] = []
    current = ""
    for word in words:
        if font.size(word)[0] > max_width:
            word = _fit_text(font, word, max_width)
        candidate = word if not current else f"{current} {word}"
        if current and font.size(candidate)[0] > max_width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    if max_lines is None or len(lines) <= max_lines:
        return lines
    overflow = " ".join(lines[max_lines - 1 :])
    return [*lines[: max_lines - 1], _fit_text(font, overflow, max_width)]


def _draw_vertical_gradient(surface: pygame.Surface, rect: pygame.Rect, top: tuple[int, int, int], bottom: tuple[int, int, int]) -> None:
    if rect.width <= 0 or rect.height <= 0:
        return
    key = ((rect.width, rect.height), top, bottom)
    gradient = _GRADIENT_CACHE.get(key)
    if gradient is None:
        gradient = pygame.Surface((rect.width, rect.height))
        height = max(1, rect.height)
        for row in range(height):
            t = row / max(1, height - 1)
            color = (
                int(_lerp(top[0], bottom[0], t)),
                int(_lerp(top[1], bottom[1], t)),
                int(_lerp(top[2], bottom[2], t)),
            )
            pygame.draw.line(gradient, color, (0, row), (rect.width, row))
        _GRADIENT_CACHE[key] = gradient
    surface.blit(gradient, rect)


def _rounded(surface: pygame.Surface, rect: pygame.Rect, color: tuple[int, int, int], radius: int = 20, width: int = 0) -> None:
    border_radius = max(0, min(radius, rect.width // 2, rect.height // 2))
    pygame.draw.rect(surface, color, rect, width=width, border_radius=border_radius)


def _mix_color(base: tuple[int, int, int], target: tuple[int, int, int], alpha: float) -> tuple[int, int, int]:
    alpha = _clip(float(alpha), 0.0, 1.0)
    return (
        int(_lerp(base[0], target[0], alpha)),
        int(_lerp(base[1], target[1], alpha)),
        int(_lerp(base[2], target[2], alpha)),
    )


def _color_rgb(value) -> tuple[int, int, int]:
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return (
            int(_clip(float(value[0]), 0, 255)),
            int(_clip(float(value[1]), 0, 255)),
            int(_clip(float(value[2]), 0, 255)),
        )
    text = str(value).strip().lower()
    if text in CAR_COLOR_VALUES:
        return CAR_COLOR_VALUES[text]
    if text.startswith("#") and len(text) == 7:
        try:
            return tuple(int(text[index:index + 2], 16) for index in (1, 3, 5))
        except ValueError:
            pass
    return CAR_COLOR_VALUES["white"]


def _color_label(value) -> str:
    text = str(value).strip().lower()
    if text in CAR_COLOR_LABELS:
        return CAR_COLOR_LABELS[text]
    rgb = _color_rgb(value)
    for key, named_rgb in CAR_COLOR_VALUES.items():
        if rgb == named_rgb:
            return CAR_COLOR_LABELS.get(key, _title_from_stem(key))
    return f"#{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"


def _serialize_car_color(rgb: tuple[int, int, int]) -> str | list[int]:
    for key, named_rgb in CAR_COLOR_VALUES.items():
        if rgb == named_rgb:
            return key
    return [int(rgb[0]), int(rgb[1]), int(rgb[2])]


CAR_COLOR_VALUES: dict[str, tuple[int, int, int]] = {
    "trinityred": (177, 42, 35),
    "orangered": (255, 69, 0),
    "crimson": (204, 36, 63),
    "gold": (242, 186, 73),
    "amber": (221, 143, 41),
    "forestgreen": (40, 117, 78),
    "mediumseagreen": (61, 179, 112),
    "dodgerblue": (30, 144, 255),
    "royalblue": (65, 105, 225),
    "silver": (177, 181, 186),
    "white": (245, 245, 245),
    "black": (28, 29, 31),
}

CAR_COLOR_NAMES = tuple(CAR_COLOR_VALUES.keys())
CAR_COLOR_LABELS: dict[str, str] = {
    "trinityred": "FT Red",
    "orangered": "Orange Red",
    "crimson": "Crimson",
    "gold": "Gold",
    "amber": "Amber",
    "forestgreen": "Forest Green",
    "mediumseagreen": "Sea Green",
    "dodgerblue": "Dodger Blue",
    "royalblue": "Royal Blue",
    "silver": "Silver",
    "white": "White",
    "black": "Black",
}
DEFAULT_LIVERIES = (
    ("trinityred", "white"),
    ("dodgerblue", "white"),
    ("forestgreen", "gold"),
    ("silver", "trinityred"),
    ("gold", "black"),
    ("royalblue", "white"),
)

RACE_MODE_INFO: dict[str, dict[str, str]] = {
    "grand_prix": {
        "label": "Grand Prix",
        "summary": "Complete the full lap target in the shortest total time.",
    },
    "qualifying": {
        "label": "Qualifying",
        "summary": "Fastest single completed lap leads the field.",
    },
    "clean_race": {
        "label": "Clean Race",
        "summary": "Least wall and car contacts wins, with race progress as the tie-break.",
    },
    "precision": {
        "label": "Precision",
        "summary": "Lowest average distance from the center line across the run.",
    },
    "consistency": {
        "label": "Consistency",
        "summary": "Lowest lap-time spread rewards repeatable code, not just one flyer.",
    },
}

APP_TITLE = "Formula Trinity GP"
START_LIGHT_COUNT = 5
DEFAULT_CARS_PATH = "template/cars/aigpv2.json"
DEFAULT_ADVANCED_CARS_PATH = "template/cars/advanced_alpine.json"
ADVANCED_WHEEL_CONTACT_POINTS = np.array(
    [
        [0.18, 0.16, 0.024 - 0.055],
        [0.18, -0.16, 0.024 - 0.055],
        [-0.16, 0.16, 0.024 - 0.058],
        [-0.16, -0.16, 0.024 - 0.058],
    ],
    dtype=np.float64,
)
ADVANCED_WHEEL_CONTACT_MARGIN = 0.002
ADVANCED_GRAVITY = 9.81
ADVANCED_LAUNCH_LOAD = 0.97
ADVANCED_PARTIAL_CONTACT_LOAD = 0.62
ADVANCED_LIGHT_LOAD = 0.90
ADVANCED_MIN_LAUNCH_SPEED = 2.8
ADVANCED_LAUNCH_CURVATURE = -0.040
ADVANCED_MAX_RIDE_HEIGHT = 2.8


def _advanced_body_surface_offset(roll: float, pitch: float) -> float:
    rotation = _euler_to_matrix(roll, pitch, 0.0)
    contact_points = (rotation @ ADVANCED_WHEEL_CONTACT_POINTS.T).T
    return float(max(0.0, -float(np.min(contact_points[:, 2]))) + ADVANCED_WHEEL_CONTACT_MARGIN)


def _render_pitch(surface_pitch: float) -> float:
    # In the Rz-Ry-Rx convention used by MuJoCo quaternions here, negative
    # pitch raises the local +X nose. Surface grade is positive uphill.
    return -float(surface_pitch)


def _title_from_stem(stem: str) -> str:
    cleaned = stem.replace("_", " ").replace("-", " ").strip()
    return cleaned.title() if cleaned else "Driver"


class _NullDriver:
    def process_lidar(self, ranges, state=None):
        return 0.0, 0.0

    def process_advanced(self, observation):
        return 0.0, 0.0


@dataclass(slots=True)
class VehicleStateSnapshot:
    laps: int
    velocity: list[float]
    yaw: float
    pitch: float
    roll: float
    lap_completion: float
    absolute_completion: float
    time: float


@dataclass(slots=True)
class RaceConfig:
    track: str = "track"
    world_mode: str = "standard"
    default_advanced_track: str = DEFAULT_ADVANCED_TRACK
    cars_path: str = DEFAULT_CARS_PATH
    cars_path_explicit: bool = False
    drivers_dir: str = "drivers"
    template_dir: str = "template"
    rendered_dir: str = ".rendered"
    cars_data: list[dict] | None = None
    rangefinders: int = 90
    sensor_hz: int = 60
    physics_hz: int = 120
    scene_render_hz: int = 60
    lap_target: int = 10
    race_mode: str = "grand_prix"
    headless: bool = False
    max_steps: int = 0
    max_time: float = 0.0
    auto_reload: bool = True
    max_speed_command: float = 15.0
    max_steer_command: float = 1.0
    max_vehicle_speed: float = 11.5
    max_reverse_speed: float = 3.2
    accel_rate: float = 18.0
    brake_rate: float = 24.0
    drag_coefficient: float = 0.18
    steering_rate: float = 4.5
    max_steer_angle: float = 0.58
    wheelbase: float = 0.42
    car_half_length: float = CAR_COLLISION_HALF_LENGTH
    car_half_width: float = CAR_COLLISION_HALF_WIDTH
    car_radius: float = math.hypot(CAR_COLLISION_HALF_LENGTH, CAR_COLLISION_HALF_WIDTH)
    manual_control_speed: float = 5.5
    window_width: int = 1480
    window_height: int = 900
    lidar_max_distance: float = 20.0
    show_lidar: bool = False
    show_racing_line: bool = False
    camera_mode: str = "overview"
    lock_camera: bool = True
    reduced_scene_complexity: bool = False
    render_scale: float = 0.80

    def __post_init__(self) -> None:
        minimum_one_fields = {
            "rangefinders": self.rangefinders,
            "sensor_hz": self.sensor_hz,
            "physics_hz": self.physics_hz,
            "scene_render_hz": self.scene_render_hz,
            "lap_target": self.lap_target,
        }
        for field_name, value in minimum_one_fields.items():
            if int(value) < 1:
                raise ValueError(f"{field_name} must be at least 1")
        if self.car_half_length <= 0.0 or self.car_half_width <= 0.0:
            raise ValueError("car collision half extents must be positive")
        if self.max_steps < 0:
            raise ValueError("max_steps must be zero or greater")
        if self.max_time < 0.0:
            raise ValueError("max_time must be zero or greater")
        if not 0.55 <= float(self.render_scale) <= 1.0:
            raise ValueError("render_scale must stay between 0.55 and 1.0")
        if self.world_mode not in {"standard", "advanced"}:
            raise ValueError("world_mode must be either 'standard' or 'advanced'")
        self.car_radius = float(max(self.car_radius, math.hypot(self.car_half_length, self.car_half_width)))


@dataclass(slots=True)
class DriverWrapper:
    file_path: Path
    driver: object | None = None
    accepts_state: bool = False
    accepts_advanced: bool = False
    supports_lidar: bool = True
    generation: int = 0
    last_mtime: float = 0.0

    def load(self) -> None:
        generation = self.generation + 1
        module_name = f"aigpv2_driver_{self.file_path.stem}_{generation}"
        spec = importlib.util.spec_from_file_location(module_name, self.file_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not import driver from {self.file_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        if not hasattr(module, "Driver"):
            raise AttributeError(f"{self.file_path} does not define a Driver class")
        driver = module.Driver()
        supports_lidar = hasattr(driver, "process_lidar")
        supports_advanced = hasattr(driver, "process_advanced")
        if not supports_lidar and not supports_advanced:
            raise AttributeError(f"{self.file_path} must define process_lidar(...) or process_advanced(...)")
        signature = inspect.signature(driver.process_lidar) if supports_lidar else None
        self.driver = driver
        self.accepts_state = bool(signature is not None and len(signature.parameters) >= 2)
        self.accepts_advanced = supports_advanced
        self.supports_lidar = supports_lidar
        self.generation = generation
        self.last_mtime = self.file_path.stat().st_mtime

    def maybe_reload(self) -> bool:
        current = self.file_path.stat().st_mtime
        if current <= self.last_mtime:
            return False
        self.load()
        return True


@dataclass(slots=True)
class VehicleRuntime:
    id: int
    name: str
    driver_ref: str
    driver_path: Path
    controller: DriverWrapper
    joint_name: str
    body_name: str
    sensor_ids: np.ndarray
    spawn_progress: float
    spawn_lateral_offset: float
    car_index: int = 0
    qpos_addr: int = -1
    qvel_addr: int = -1
    sensor_shape: tuple[int, ...] = (0,)
    track_index_hint: int = 0
    position: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float32))
    last_safe_position: np.ndarray = field(default_factory=lambda: np.zeros(2, dtype=np.float32))
    velocity: np.ndarray = field(default_factory=lambda: np.zeros(3, dtype=np.float32))
    yaw: float = 0.0
    yaw_rate: float = 0.0
    pitch: float = 0.0
    roll: float = 0.0
    pitch_rate: float = 0.0
    roll_rate: float = 0.0
    speed: float = 0.0
    steer: float = 0.0
    target_speed: float = 0.0
    target_steer: float = 0.0
    raw_progress: float = 0.0
    unwrapped_progress: float = 0.0
    laps: int = 0
    completion: float = 0.0
    absolute_completion: float = 0.0
    good_start: bool = True
    finished: bool = False
    finish_time: float | None = None
    lap_start_time: float = 0.0
    lap_times: list[float] = field(default_factory=list)
    driver_call_count: int = 0
    driver_total_time: float = 0.0
    driver_max_time: float = 0.0
    peak_speed: float = 0.0
    wall_contacts: int = 0
    wall_touching: bool = False
    car_contacts: int = 0
    center_error_total: float = 0.0
    center_error_samples: int = 0
    last_error: str | None = None
    error_count: int = 0
    last_ranges: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))
    last_legacy_ranges: np.ndarray = field(default_factory=lambda: np.zeros(0, dtype=np.float32))
    distance_from_center: float = 0.0
    grounded: bool = True
    surface_height: float = 0.0
    surface_grade: float = 0.0
    surface_bank: float = 0.0
    surface_vertical_curvature: float = 0.0
    surface_load: float = 1.0
    light_contact_time: float = 0.0
    contact_scrub_time: float = 0.0
    ride_height: float = 0.0
    vertical_velocity: float = 0.0
    airborne_time: float = 0.0
    jump_armed: bool = True
    jump_cooldown_time: float = 0.0

    def signed_completion(self) -> float:
        if self.good_start:
            return self.completion
        return -(100.0 - self.completion)


@dataclass(slots=True)
class TracksideCamera:
    progress: float
    lookat: np.ndarray
    azimuth: float
    elevation: float
    distance: float


class RaceApp:
    SETTINGS_TABS = ("Race", "Track", "View", "Drivers", "Modes")
    CAMERA_MODES = ("follow", "chase", "overview", "trackside")
    SCENE_RENDER_HZ_OPTIONS = (30, 60, 90, 120)
    DRIVER_CARD_COLLAPSED_HEIGHT = 116
    DRIVER_CARD_EXPANDED_HEIGHT = 480
    DRIVER_CARD_GAP = 12
    DRIVER_ADD_BUTTON_HEIGHT = 48

    def __init__(self, config: RaceConfig) -> None:
        self.config = config
        self.project_root = Path(__file__).resolve().parents[1]
        self.template_dir = self._resolve_path(self.config.template_dir)
        self.drivers_dir = self._resolve_path(self.config.drivers_dir)
        self.rendered_root = self._resolve_path(self.config.rendered_dir)
        self.rendered_root.mkdir(parents=True, exist_ok=True)
        self.cars_file = self._resolve_cars_file()

        self.cars_raw = self._load_cars_raw()
        self.available_standard_tracks = discover_tracks(self.template_dir)
        if not self.available_standard_tracks:
            self.available_standard_tracks = sorted(DEFAULT_TRACKS.keys())
        self.available_advanced_tracks = []
        self.advanced_track_specs: dict[str, AdvancedTrackSpec] = {}
        self.advanced_track_errors: dict[str, str] = {}
        for name in discover_advanced_tracks(self.template_dir):
            try:
                spec = load_advanced_track_spec(self.template_dir, name)
            except Exception as exc:
                self.advanced_track_errors[name] = str(exc)
                continue
            self.advanced_track_specs[name] = spec
            self.available_advanced_tracks.append(name)
        self.available_tracks = self.available_advanced_tracks if self._is_advanced_mode() else self.available_standard_tracks
        if self._is_advanced_mode():
            if not self.available_tracks:
                if self.advanced_track_errors:
                    details = "; ".join(f"{name}: {message}" for name, message in sorted(self.advanced_track_errors.items()))
                    raise ValueError(f"No valid advanced tracks were found under template/advanced ({details})")
                raise ValueError("No advanced tracks were found under template/advanced")
            if self.config.track not in self.available_tracks:
                preferred = self.config.default_advanced_track if self.config.default_advanced_track in self.available_tracks else self.available_tracks[0]
                self.config.track = preferred
        elif self.config.track not in self.available_tracks:
            self.config.track = self.available_tracks[0]

        self.track_settings = self._default_track_settings(self.config.track)
        self.edit_track_settings = self.track_settings.copy()

        self.geometry: TrackGeometry | None = None
        self.advanced_world: AdvancedTrackWorld | None = None
        self.active_advanced_track = None
        self.session_dir: Path | None = None
        self.model: mujoco.MjModel | None = None
        self.data: mujoco.MjData | None = None
        self.vehicles: list[VehicleRuntime] = []
        self.active_car_indices: list[int] = []
        self.vehicle_id_by_car_index: dict[int, int] = {}

        self.renderer: mujoco.Renderer | None = None
        self.renderer_size: tuple[int, int] | None = None
        self.scene_option = mujoco.MjvOption()
        self.scene_option.flags[mujoco.mjtVisFlag.mjVIS_RANGEFINDER] = False
        self.camera = mujoco.MjvCamera()
        self.camera_mode = self.config.camera_mode if self.config.camera_mode in self.CAMERA_MODES else "overview"
        self.camera_distance = 18.0
        self.camera_azimuth = 36.0
        self.camera_elevation = -28.0
        self.camera_yaw_offset = 0.0
        self.camera_pitch_offset = 0.0
        self.identity_mat = np.eye(3, dtype=np.float64).reshape(9)
        self.zero3 = np.zeros(3, dtype=np.float64)
        self.trackside_cameras: list[TracksideCamera] = []
        self.trackside_camera_index = 0
        self.wall_segment_cell_size = 1.5
        self.wall_segment_query_radius = 0.0
        self.wall_segment_grid: dict[tuple[int, int], list[int]] = {}

        self.running = True
        self.paused = not self.config.headless
        self.awaiting_race_start = not self.config.headless
        self.countdown_active = False
        self.countdown_remaining = 0.0
        self.stop_reason: str | None = None
        self.pending_track_rebuild = False
        self.sim_time = 0.0
        self.step_count = 0
        self.sim_accumulator = 0.0
        self.last_reload_check = 0.0
        self.sim_speed = 1.0
        self.sensor_stride = max(1, int(round(self.config.physics_hz / max(1, self.config.sensor_hz))))

        self.watching: int | None = 0 if self.cars_raw else None
        self.manual_control = False
        self.manual_speed = 0.0
        self.manual_steer = 0.0
        self.lock_camera = self.config.lock_camera
        self.show_lidar = self.config.show_lidar
        self.show_racing_line = self.config.show_racing_line
        self.render_scale = _clip(self.config.render_scale, 0.55, 1.0)
        self.settings_visible = True
        self.settings_detached = False
        self.fullscreen = False
        self.selected_tab = "Race"
        self.driver_settings_open: int | None = None
        self.driver_name_edit_id: int | None = None
        self.driver_name_buffer = ""
        self.track_tab_scroll = 0
        self.drivers_scroll = 0
        self.active_car_collisions: set[tuple[int, int]] = set()
        self.trackside_anchor_vehicle: int | None = self.watching
        self.aerial_view = False

        self.window: pygame.Surface | None = None
        self.window_size = (self.config.window_width, self.config.window_height)
        self.saved_window_size = self.window_size
        self.controls_window = None
        self.controls_renderer = None
        self.controls_window_id: int | None = None
        self.controls_window_size = (460, self.config.window_height)
        self.font_small: pygame.font.Font | None = None
        self.font_body: pygame.font.Font | None = None
        self.font_micro: pygame.font.Font | None = None
        self.font_label: pygame.font.Font | None = None
        self.font_title: pygame.font.Font | None = None
        self.font_large: pygame.font.Font | None = None
        self.font_stat: pygame.font.Font | None = None
        self.preview_cache: dict[str, pygame.Surface] = {}
        self.preview_fit_cache: dict[tuple[str, int, int], pygame.Surface] = {}
        self.scene_surface_cache: pygame.Surface | None = None
        self.scene_cache_key: tuple | None = None
        self.standings_cache: list[VehicleRuntime] | None = None
        self.standings_cache_step = -1

        self.ui_actions: list[dict] = []
        self.controls_ui_actions: list[dict] = []
        self._ui_action_target = "main"
        self.active_slider: dict | None = None
        self.active_slider_window = "main"
        self.dragging_camera = False
        self.mouse_position = (0, 0)
        self.mouse_primary_down = False
        self.main_mouse_position = (0, 0)
        self.controls_mouse_position = (0, 0)
        self.controls_mouse_primary_down = False
        self.render_rect = pygame.Rect(0, 0, 1, 1)
        self.panel_rect: pygame.Rect | None = None
        self.camera_frame_cache: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None = None
        self.camera_projection_cache: tuple[float, float] | None = None

        self.palette = {
            "bg_top": (17, 21, 19),
            "bg_bottom": (9, 11, 13),
            "panel": (21, 24, 28),
            "panel_edge": (84, 88, 93),
            "card": (27, 30, 34),
            "card_alt": (32, 35, 40),
            "text": (236, 238, 240),
            "muted": (154, 158, 163),
            "soft": (108, 113, 119),
            "accent": (177, 42, 35),
            "accent_alt": (223, 177, 87),
            "success": (72, 145, 105),
            "warning": (210, 176, 92),
            "danger": (201, 92, 86),
            "surface": (14, 16, 19),
            "track_border": (96, 100, 106),
            "pill": (37, 40, 45),
        }

        self._stage(reset_progress=True)

    def close(self) -> None:
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
            self.renderer_size = None
        self._close_controls_window()
        self.data = None
        self.model = None
        self.vehicles = []
        if self.window is not None:
            self.window = None
        if pygame.get_init():
            pygame.quit()
        if self.session_dir is not None and self.session_dir.exists():
            session_dir = self.session_dir
            self.session_dir = None
            gc.collect()

            def _force_remove_readonly(func, path, _exc_info):
                os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
                func(path)

            for _ in range(3):
                try:
                    shutil.rmtree(session_dir, onerror=_force_remove_readonly)
                    break
                except OSError:
                    gc.collect()
                    time.sleep(0.05)

    def _resolve_path(self, value: str) -> Path:
        path = Path(value)
        if path.is_absolute():
            return path
        return (self.project_root / path).resolve()

    def _resolve_cars_file(self) -> Path | None:
        if self.config.cars_data is not None:
            return None
        candidate = self._resolve_path(self.config.cars_path)
        default_standard = (self.project_root / DEFAULT_CARS_PATH).resolve()
        default_advanced = (self.project_root / DEFAULT_ADVANCED_CARS_PATH).resolve()
        if (
            self._is_advanced_mode()
            and not self.config.cars_path_explicit
            and candidate.resolve() == default_standard
            and default_advanced.is_file()
        ):
            self.config.cars_path = DEFAULT_ADVANCED_CARS_PATH
            return default_advanced
        if candidate.is_file():
            return candidate
        fallback = self.project_root / "template" / "cars" / Path(self.config.cars_path).name
        return fallback.resolve()

    def _is_advanced_mode(self) -> bool:
        return self.config.world_mode == "advanced"

    def _advanced_track_spec(self, name: str) -> AdvancedTrackSpec | None:
        spec = self.advanced_track_specs.get(name)
        if spec is not None:
            return spec
        try:
            spec = load_advanced_track_spec(self.template_dir, name)
        except Exception:
            return None
        self.advanced_track_specs[name] = spec
        return spec

    def _default_track_settings(self, name: str) -> TrackSettings:
        if self._is_advanced_mode():
            spec = self._advanced_track_spec(name)
            if spec is not None:
                defaults = DEFAULT_TRACKS.get(spec.base_track, TrackSettings(name=spec.base_track)).copy()
                for key, value in spec.defaults.items():
                    if hasattr(defaults, key):
                        setattr(defaults, key, value)
                defaults.name = name
                return defaults
        defaults = DEFAULT_TRACKS.get(name, TrackSettings(name=name)).copy()
        defaults.name = name
        return defaults

    def _active_advanced_preview_path(self, name: str) -> Path | None:
        if not self._is_advanced_mode():
            return None
        spec = self._advanced_track_spec(name)
        return None if spec is None else spec.preview_path

    def _active_track_label(self, name: str) -> str:
        if not self._is_advanced_mode():
            return name
        spec = self._advanced_track_spec(name)
        return name if spec is None else spec.display_name

    def _status(self, message: str) -> None:
        print(f"[AIGPV2] {message}")

    def _absolute_track_progress(self, vehicle: VehicleRuntime) -> float:
        assert self.geometry is not None
        return (vehicle.spawn_progress + vehicle.raw_progress * self.geometry.total_length) % self.geometry.total_length

    def _arm_fresh_start(self) -> None:
        self.countdown_active = False
        self.countdown_remaining = 0.0
        self.awaiting_race_start = not self.config.headless
        self.paused = not self.config.headless
        self.stop_reason = None

    def _begin_start_sequence(self) -> None:
        if self.countdown_active or not self.awaiting_race_start:
            return
        if self.config.headless:
            self.awaiting_race_start = False
            self.paused = False
            return
        self.countdown_active = True
        self.countdown_remaining = float(START_LIGHT_COUNT)
        self.paused = True
        self.stop_reason = None

    def _update_start_sequence(self, frame_dt: float) -> None:
        if not self.countdown_active:
            return
        self.countdown_remaining = max(0.0, self.countdown_remaining - frame_dt)
        if self.countdown_remaining > 0.0:
            return
        self.countdown_active = False
        self.awaiting_race_start = False
        self.paused = False
        self.stop_reason = None

    def _toggle_pause_or_start(self) -> None:
        if self.countdown_active:
            return
        if self.awaiting_race_start:
            self._begin_start_sequence()
            return
        self.paused = not self.paused
        if not self.paused:
            self.stop_reason = None

    def _set_sim_speed(self, value: float) -> None:
        self.sim_speed = _clip(float(value), 0.25, 6.0)

    def _toggle_aerial_view(self) -> None:
        self.aerial_view = not self.aerial_view

    def _load_cars_raw(self) -> list[dict]:
        if self.config.cars_data is not None:
            raw = self.config.cars_data
        else:
            assert self.cars_file is not None
            with self.cars_file.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
        cars = []
        for index, entry in enumerate(raw):
            item = dict(entry)
            item.setdefault("name", f"car {index}")
            item.setdefault("icon", "white.png")
            item.setdefault("primary", "trinityred")
            item.setdefault("secondary", "white")
            item.setdefault("active", True)
            cars.append(item)
        return cars

    def _save_cars_raw(self) -> None:
        if self.config.cars_data is not None:
            self.config.cars_data = [dict(item) for item in self.cars_raw]
            return
        assert self.cars_file is not None
        self.cars_file.parent.mkdir(parents=True, exist_ok=True)
        self.cars_file.write_text(json.dumps(self.cars_raw, indent=2), encoding="utf-8")

    def _car_is_active(self, car: dict) -> bool:
        return bool(car.get("active", True))

    def _active_cars_for_stage(self) -> list[dict]:
        self.active_car_indices = [index for index, car in enumerate(self.cars_raw) if self._car_is_active(car)]
        self.vehicle_id_by_car_index = {car_index: vehicle_id for vehicle_id, car_index in enumerate(self.active_car_indices)}
        return [self.cars_raw[index] for index in self.active_car_indices]

    def _vehicle_for_car_index(self, car_index: int) -> VehicleRuntime | None:
        vehicle_id = self.vehicle_id_by_car_index.get(car_index)
        if vehicle_id is None or vehicle_id < 0 or vehicle_id >= len(self.vehicles):
            return None
        return self.vehicles[vehicle_id]

    def _normalize_vehicle_focus(self) -> None:
        if not self.vehicles:
            self.watching = None
            self.trackside_anchor_vehicle = None
            return
        if self.watching is None or self.watching < 0 or self.watching >= len(self.vehicles):
            self.watching = 0
        if self.trackside_anchor_vehicle is None or self.trackside_anchor_vehicle < 0 or self.trackside_anchor_vehicle >= len(self.vehicles):
            self.trackside_anchor_vehicle = self.watching

    def _resolve_driver_path(self, driver_ref: str) -> Path:
        if driver_ref.startswith("file://"):
            return Path(driver_ref[7:]).resolve()
        raw = Path(driver_ref)
        if raw.is_absolute() and raw.suffix == ".py":
            return raw.resolve()
        if raw.suffix == ".py":
            return (self.project_root / raw).resolve()
        existing = self.project_root / raw
        if existing.is_file():
            return existing.resolve()
        return (self.project_root / (driver_ref.replace(".", os.sep) + ".py")).resolve()

    def _driver_ref_from_path(self, path: Path) -> str:
        resolved = path.resolve()
        try:
            relative = resolved.relative_to(self.project_root)
        except ValueError:
            return f"file://{resolved}"
        parts = relative.with_suffix("").parts
        if any(part.startswith(".") or not part.replace("_", "").isalnum() for part in parts):
            return f"file://{resolved}"
        return ".".join(parts)

    def _driver_option_label(self, path: Path) -> str:
        resolved = path.resolve()
        try:
            return resolved.relative_to(self.drivers_dir.resolve()).as_posix()
        except ValueError:
            try:
                return resolved.relative_to(self.project_root).as_posix()
            except ValueError:
                return resolved.name

    def _available_driver_paths(self, vehicle_id: int | None = None) -> list[Path]:
        options: list[Path] = []
        seen: set[Path] = set()
        if self.drivers_dir.is_dir():
            for path in sorted(self.drivers_dir.rglob("*.py"), key=lambda item: item.as_posix().lower()):
                if "__pycache__" in path.parts:
                    continue
                if path.name in {"__init__.py", "template.py"}:
                    continue
                if path.name.startswith("_"):
                    continue
                resolved = path.resolve()
                if resolved in seen:
                    continue
                seen.add(resolved)
                options.append(resolved)
        if vehicle_id is not None and 0 <= vehicle_id < len(self.cars_raw):
            current_ref = str(self.cars_raw[vehicle_id].get("driver", ""))
            if current_ref:
                current_path = self._resolve_driver_path(current_ref)
                if current_path.is_file():
                    resolved = current_path.resolve()
                    if resolved not in seen:
                        options.insert(0, resolved)
        return options

    def _browse_python_file(self, initial_path: Path | None = None) -> Path | None:
        try:
            import tkinter as tk
            from tkinter import filedialog
        except Exception as exc:
            self._status(f"Python file dialog unavailable: {exc}")
            return None

        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes("-topmost", True)
        except Exception:
            pass
        start_dir = str((initial_path.parent if initial_path is not None else self.drivers_dir).resolve())
        selected = filedialog.askopenfilename(
            parent=root,
            title="Select Driver Python File",
            initialdir=start_dir,
            filetypes=(("Python files", "*.py"), ("All files", "*.*")),
        )
        root.destroy()
        if not selected:
            return None
        return Path(selected).resolve()

    def _browse_color(self, initial_rgb: tuple[int, int, int]) -> tuple[int, int, int] | None:
        try:
            import tkinter as tk
            from tkinter import colorchooser
        except Exception as exc:
            self._status(f"Colour picker unavailable: {exc}")
            return None

        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes("-topmost", True)
        except Exception:
            pass
        colour, _hex = colorchooser.askcolor(
            color=f"#{initial_rgb[0]:02X}{initial_rgb[1]:02X}{initial_rgb[2]:02X}",
            parent=root,
            title="Pick Driver Colour",
        )
        root.destroy()
        if colour is None:
            return None
        return tuple(int(_clip(round(channel), 0, 255)) for channel in colour[:3])

    def _default_driver_source(self, stem: str) -> str:
        template_path = self.drivers_dir / "template.py"
        if template_path.is_file():
            source = template_path.read_text(encoding="utf-8")
            if "class Driver" in source:
                return source
        return textwrap.dedent(
            f"""\
            class Driver:
                def process_lidar(self, ranges, state=None):
                    return 5.0, 0.0
            """
        )

    def _next_scaffold_driver_path(self) -> Path:
        for index in range(1, 1000):
            candidate = self.drivers_dir / f"driver_{index:02d}.py"
            if not candidate.exists():
                return candidate
        raise RuntimeError("No free driver scaffold slots available")

    def _add_driver(self) -> None:
        self.drivers_dir.mkdir(parents=True, exist_ok=True)
        driver_path = self._next_scaffold_driver_path()
        driver_path.write_text(self._default_driver_source(driver_path.stem), encoding="utf-8")
        primary, secondary = DEFAULT_LIVERIES[len(self.cars_raw) % len(DEFAULT_LIVERIES)]
        self.cars_raw.append(
            {
                "driver": self._driver_ref_from_path(driver_path),
                "name": _title_from_stem(driver_path.stem),
                "primary": primary,
                "secondary": secondary,
                "icon": "white.png",
                "active": True,
            }
        )
        car_index = len(self.cars_raw) - 1
        self._save_cars_raw()
        self._stage(reset_progress=True)
        vehicle = self._vehicle_for_car_index(car_index)
        self.watching = vehicle.id if vehicle is not None else self.watching
        self.trackside_anchor_vehicle = self.watching
        self.driver_settings_open = car_index
        self.driver_name_edit_id = self.driver_settings_open
        self.driver_name_buffer = self.cars_raw[self.driver_settings_open]["name"]

    def _remove_driver(self, vehicle_id: int) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        del self.cars_raw[vehicle_id]
        self._save_cars_raw()
        self.driver_settings_open = None
        self.driver_name_edit_id = None
        self.driver_name_buffer = ""
        self._stage(reset_progress=True)
        self._normalize_vehicle_focus()

    def _set_driver_active(self, vehicle_id: int, active: bool) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        next_active = bool(active)
        if bool(self.cars_raw[vehicle_id].get("active", True)) == next_active:
            return
        self.cars_raw[vehicle_id]["active"] = next_active
        self._save_cars_raw()
        self._stage(reset_progress=True)
        self.driver_settings_open = vehicle_id
        self.driver_name_edit_id = None
        self.driver_name_buffer = self.cars_raw[vehicle_id].get("name", f"car {vehicle_id}")
        if next_active:
            vehicle = self._vehicle_for_car_index(vehicle_id)
            if vehicle is not None:
                self.watching = vehicle.id
                self.trackside_anchor_vehicle = vehicle.id
        self._normalize_vehicle_focus()
        self._scroll_driver_card_into_view(vehicle_id)

    def _toggle_driver_settings(self, vehicle_id: int) -> None:
        if self.driver_settings_open == vehicle_id:
            self.driver_settings_open = None
            self.driver_name_edit_id = None
            self.driver_name_buffer = ""
            return
        self.driver_settings_open = vehicle_id
        self.driver_name_edit_id = None
        self.driver_name_buffer = self.cars_raw[vehicle_id].get("name", f"car {vehicle_id}")
        self._scroll_driver_card_into_view(vehicle_id)

    def _begin_driver_name_edit(self, vehicle_id: int) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        self.driver_settings_open = vehicle_id
        self.driver_name_edit_id = vehicle_id
        self.driver_name_buffer = self.cars_raw[vehicle_id].get("name", f"car {vehicle_id}")
        self._scroll_driver_card_into_view(vehicle_id)

    def _driver_card_height(self, vehicle_id: int) -> int:
        return self.DRIVER_CARD_EXPANDED_HEIGHT if self.driver_settings_open == vehicle_id else self.DRIVER_CARD_COLLAPSED_HEIGHT

    def _driver_card_bounds(self, vehicle_id: int) -> tuple[int, int] | None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return None
        y = 0
        for idx in range(len(self.cars_raw)):
            height = self._driver_card_height(idx)
            if idx == vehicle_id:
                return y, y + height
            y += height + self.DRIVER_CARD_GAP
        return None

    def _drivers_content_height(self) -> int:
        if not self.cars_raw:
            return 104 + 14 + self.DRIVER_ADD_BUTTON_HEIGHT
        height = 0
        for idx in range(len(self.cars_raw)):
            height += self._driver_card_height(idx)
            height += self.DRIVER_CARD_GAP
        height += self.DRIVER_ADD_BUTTON_HEIGHT
        return height

    def _drivers_visible_height(self) -> int:
        panel = self._settings_metrics_panel()
        if panel is None:
            return 0
        content_y = panel.y + 150
        return max(0, panel.bottom - 16 - content_y)

    def _track_content_height(self) -> int:
        row_gap = 6
        height = 112 + 8  # preview
        height += 38 + 8  # switch row
        height += 7 * (58 + row_gap)
        if self._is_advanced_mode():
            height += 38 + 8
            height += 6 * (58 + row_gap)
        height += 48
        return height

    def _track_visible_height(self) -> int:
        panel = self._settings_metrics_panel()
        if panel is None:
            return 0
        content_y = panel.y + 150
        return max(0, panel.bottom - 16 - content_y)

    def _settings_metrics_panel(self) -> pygame.Rect | None:
        if self.panel_rect is not None:
            return self.panel_rect
        if self.settings_detached and self.controls_window_size[0] > 0 and self.controls_window_size[1] > 0:
            return pygame.Rect(0, 0, self.controls_window_size[0], self.controls_window_size[1])
        return None

    def _max_track_scroll(self) -> int:
        return max(0, self._track_content_height() - self._track_visible_height())

    def _clamp_track_scroll(self) -> None:
        self.track_tab_scroll = int(_clip(self.track_tab_scroll, 0, self._max_track_scroll()))

    def _max_drivers_scroll(self) -> int:
        return max(0, self._drivers_content_height() - self._drivers_visible_height())

    def _clamp_drivers_scroll(self) -> None:
        self.drivers_scroll = int(_clip(self.drivers_scroll, 0, self._max_drivers_scroll()))

    def _scroll_driver_card_into_view(self, vehicle_id: int) -> None:
        bounds = self._driver_card_bounds(vehicle_id)
        if bounds is None:
            return
        visible_height = self._drivers_visible_height()
        if visible_height <= 0:
            self.drivers_scroll = bounds[0]
            return
        top, bottom = bounds
        visible_top = self.drivers_scroll
        visible_bottom = visible_top + visible_height
        if top < visible_top:
            self.drivers_scroll = top
        elif bottom > visible_bottom:
            self.drivers_scroll = bottom - visible_height
        self._clamp_drivers_scroll()

    def _handle_settings_scroll(self, button: int, position: tuple[int, int]) -> bool:
        panel = self._settings_metrics_panel()
        if not self.settings_visible or panel is None:
            return False
        if not panel.collidepoint(position):
            return False
        if self.selected_tab == "Track":
            previous = self.track_tab_scroll
            self.track_tab_scroll += -56 if button == 4 else 56
            self._clamp_track_scroll()
            return self.track_tab_scroll != previous
        if self.selected_tab != "Drivers":
            return False
        previous = self.drivers_scroll
        self.drivers_scroll += -56 if button == 4 else 56
        self._clamp_drivers_scroll()
        return self.drivers_scroll != previous

    def _commit_driver_name_edit(self) -> None:
        if self.driver_name_edit_id is None:
            return
        vehicle_id = self.driver_name_edit_id
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            self.driver_name_edit_id = None
            self.driver_name_buffer = ""
            return
        name = self.driver_name_buffer.strip()
        if name:
            self.cars_raw[vehicle_id]["name"] = name
            vehicle = self._vehicle_for_car_index(vehicle_id)
            if vehicle is not None:
                vehicle.name = name
            self._save_cars_raw()
        self.driver_name_edit_id = None

    def _cycle_driver_color(self, vehicle_id: int, field_name: str, direction: int) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        current_rgb = _color_rgb(self.cars_raw[vehicle_id].get(field_name, "white"))
        index = min(
            range(len(CAR_COLOR_NAMES)),
            key=lambda idx: sum((current_rgb[channel] - CAR_COLOR_VALUES[CAR_COLOR_NAMES[idx]][channel]) ** 2 for channel in range(3)),
        )
        next_name = CAR_COLOR_NAMES[(index + direction) % len(CAR_COLOR_NAMES)]
        self.cars_raw[vehicle_id][field_name] = next_name
        self._save_cars_raw()
        self._stage(reset_progress=True)
        self.driver_settings_open = min(vehicle_id, len(self.cars_raw) - 1) if self.cars_raw else None
        self.driver_name_edit_id = None
        self.driver_name_buffer = self.cars_raw[self.driver_settings_open]["name"] if self.driver_settings_open is not None else ""

    def _set_driver_source(self, vehicle_id: int, driver_path: Path) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        resolved = driver_path.resolve()
        next_ref = self._driver_ref_from_path(resolved)
        current_ref = str(self.cars_raw[vehicle_id].get("driver", ""))
        if next_ref == current_ref:
            return
        self.cars_raw[vehicle_id]["driver"] = next_ref
        self._save_cars_raw()
        self._stage(reset_progress=True)
        self.driver_settings_open = min(vehicle_id, len(self.cars_raw) - 1) if self.cars_raw else None
        self.driver_name_edit_id = None
        self.driver_name_buffer = self.cars_raw[self.driver_settings_open]["name"] if self.driver_settings_open is not None else ""
        self._scroll_driver_card_into_view(vehicle_id)
        self._status(f"Driver file set to {self._driver_option_label(resolved)}")

    def _cycle_driver_source(self, vehicle_id: int, direction: int) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        options = self._available_driver_paths(vehicle_id)
        if not options:
            return
        current_ref = str(self.cars_raw[vehicle_id].get("driver", ""))
        current_path = self._resolve_driver_path(current_ref).resolve()
        try:
            index = next(idx for idx, option in enumerate(options) if option == current_path)
        except StopIteration:
            options.insert(0, current_path)
            index = 0
        next_path = options[(index + direction) % len(options)]
        self._set_driver_source(vehicle_id, next_path)

    def _browse_driver_source(self, vehicle_id: int) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        current_path = self._resolve_driver_path(str(self.cars_raw[vehicle_id].get("driver", "")))
        chosen = self._browse_python_file(current_path)
        if chosen is None:
            return
        self._set_driver_source(vehicle_id, chosen)

    def _set_driver_color(self, vehicle_id: int, field_name: str, rgb: tuple[int, int, int]) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        stored = _serialize_car_color(rgb)
        if self.cars_raw[vehicle_id].get(field_name) == stored:
            return
        self.cars_raw[vehicle_id][field_name] = stored
        self._save_cars_raw()
        self._stage(reset_progress=True)
        self.driver_settings_open = min(vehicle_id, len(self.cars_raw) - 1) if self.cars_raw else None
        self.driver_name_edit_id = None
        self.driver_name_buffer = self.cars_raw[self.driver_settings_open]["name"] if self.driver_settings_open is not None else ""
        self._scroll_driver_card_into_view(vehicle_id)

    def _pick_driver_color(self, vehicle_id: int, field_name: str) -> None:
        if vehicle_id < 0 or vehicle_id >= len(self.cars_raw):
            return
        current_rgb = _color_rgb(self.cars_raw[vehicle_id].get(field_name, "white"))
        chosen = self._browse_color(current_rgb)
        if chosen is None:
            return
        self._set_driver_color(vehicle_id, field_name, chosen)

    def _handle_active_text_input(self, event: pygame.event.Event) -> bool:
        if self.driver_name_edit_id is None:
            return False
        if event.key == pygame.K_ESCAPE:
            self.driver_name_edit_id = None
            self.driver_name_buffer = ""
            return True
        if event.key == pygame.K_RETURN:
            self._commit_driver_name_edit()
            return True
        if event.key == pygame.K_BACKSPACE:
            self.driver_name_buffer = self.driver_name_buffer[:-1]
            return True
        if event.key == pygame.K_TAB:
            return True
        if event.unicode and event.unicode.isprintable() and not (event.mod & pygame.KMOD_CTRL):
            if len(self.driver_name_buffer) < 28:
                self.driver_name_buffer += event.unicode
            return True
        return False

    def _grid_slot(self, index: int) -> tuple[float, float]:
        row = index // 2
        stagger = 0.85 if index % 2 else 0.0
        progress = 2.1 + row * 3.0 + stagger
        lateral_offset = 0.34 if index % 2 == 0 else -0.34
        return progress, lateral_offset

    def _wall_segment_cell(self, x: float, y: float) -> tuple[int, int]:
        cell_size = max(0.5, float(self.wall_segment_cell_size))
        return int(math.floor(x / cell_size)), int(math.floor(y / cell_size))

    def _build_wall_segment_index(self) -> None:
        self.wall_segment_grid = {}
        self.wall_segment_query_radius = 0.0
        if self.geometry is None or not self.geometry.wall_segments:
            return

        self.wall_segment_cell_size = max(1.0, self.track_settings.panel_length * 1.8)
        grid: dict[tuple[int, int], list[int]] = {}
        max_reach = 0.0
        for index, segment in enumerate(self.geometry.wall_segments):
            center = np.asarray(segment.position[:2], dtype=np.float32)
            tangent = np.array([math.cos(segment.yaw), math.sin(segment.yaw)], dtype=np.float32)
            normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
            half_length = float(segment.size[0])
            half_width = float(segment.size[1])
            extent_x = abs(float(tangent[0])) * half_length + abs(float(normal[0])) * half_width
            extent_y = abs(float(tangent[1])) * half_length + abs(float(normal[1])) * half_width
            min_cell = self._wall_segment_cell(float(center[0] - extent_x), float(center[1] - extent_y))
            max_cell = self._wall_segment_cell(float(center[0] + extent_x), float(center[1] + extent_y))
            for cell_x in range(min_cell[0], max_cell[0] + 1):
                for cell_y in range(min_cell[1], max_cell[1] + 1):
                    grid.setdefault((cell_x, cell_y), []).append(index)
            max_reach = max(max_reach, math.hypot(float(segment.size[0]), float(segment.size[1])))
        self.wall_segment_grid = grid
        self.wall_segment_query_radius = self.config.car_radius + max_reach + 0.04

    def _nearby_wall_segments(self, position: np.ndarray, radius: float | None = None) -> list[SegmentStyle]:
        if self.geometry is None:
            return []
        if not self.wall_segment_grid:
            return self.geometry.wall_segments
        query_radius = self.wall_segment_query_radius if radius is None else max(float(radius), self.wall_segment_query_radius)
        min_cell = self._wall_segment_cell(float(position[0] - query_radius), float(position[1] - query_radius))
        max_cell = self._wall_segment_cell(float(position[0] + query_radius), float(position[1] + query_radius))
        segment_indices: list[int] = []
        seen: set[int] = set()
        for cell_x in range(min_cell[0], max_cell[0] + 1):
            for cell_y in range(min_cell[1], max_cell[1] + 1):
                for index in self.wall_segment_grid.get((cell_x, cell_y), ()):
                    if index in seen:
                        continue
                    seen.add(index)
                    segment_indices.append(index)
        return [self.geometry.wall_segments[index] for index in segment_indices]

    def _stage(self, *, reset_progress: bool) -> None:
        previous_session = self.session_dir
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
            self.renderer_size = None
        self.scene_surface_cache = None
        self.scene_cache_key = None
        self.standings_cache = None
        self.standings_cache_step = -1

        self.advanced_world = None
        self.active_advanced_track = None
        if self._is_advanced_mode():
            self.geometry, self.advanced_world = load_advanced_world(self.template_dir, self.track_settings)
            self.active_advanced_track = self.advanced_world.spec
        else:
            self.geometry = load_track_geometry(self.template_dir, self.track_settings)
        self._build_wall_segment_index()
        self.trackside_cameras = self._build_trackside_cameras()
        self.trackside_camera_index = min(self.trackside_camera_index, max(0, len(self.trackside_cameras) - 1))
        self.session_dir = Path(tempfile.mkdtemp(prefix="aigpv2_", dir=str(self.rendered_root)))
        active_cars = self._active_cars_for_stage()
        if self.advanced_world is not None:
            mjcf_path = build_advanced_mjcf(
                session_dir=self.session_dir,
                template_dir=self.template_dir,
                geometry=self.geometry,
                world=self.advanced_world,
                cars=active_cars,
                reduced_scene_complexity=self.config.reduced_scene_complexity,
            )
        else:
            mjcf_path = build_mjcf(
                session_dir=self.session_dir,
                template_dir=self.template_dir,
                geometry=self.geometry,
                cars=active_cars,
                rangefinders=self.config.rangefinders,
                reduced_scene_complexity=self.config.reduced_scene_complexity,
            )
        self.model = mujoco.MjModel.from_xml_path(str(mjcf_path))
        self.model.opt.timestep = 1.0 / self.config.physics_hz
        self.model.vis.global_.offwidth = 4096
        self.model.vis.global_.offheight = 2160
        self.data = mujoco.MjData(self.model)
        mujoco.mj_forward(self.model, self.data)

        self._build_vehicles(active_cars)
        self._position_vehicles(reset_progress=reset_progress)
        self._normalize_vehicle_focus()
        self.pending_track_rebuild = False
        self.stop_reason = None

        if previous_session is not None and previous_session.exists():
            shutil.rmtree(previous_session, ignore_errors=True)

    def _build_vehicles(self, active_cars: list[dict]) -> None:
        assert self.data is not None
        assert self.model is not None
        vehicles: list[VehicleRuntime] = []
        advanced_shape = (len(ADVANCED_LIDAR_RING_PITCHES), ADVANCED_LIDAR_RAYS)
        for index, car in enumerate(active_cars):
            car_index = self.active_car_indices[index] if index < len(self.active_car_indices) else index
            driver_ref = str(car.get("driver", ""))
            driver_path = self._resolve_driver_path(driver_ref)
            controller = DriverWrapper(driver_path)
            last_error = None
            error_count = 0
            try:
                controller.load()
            except Exception as exc:
                controller.driver = _NullDriver()
                controller.accepts_state = True
                controller.accepts_advanced = True
                controller.supports_lidar = True
                last_error = f"{type(exc).__name__}: {exc}"
                error_count = 1
                self._status(f"Driver load error for {car.get('name', index)}: {exc}")
            progress, lateral_offset = self._grid_slot(index)
            if self._is_advanced_mode():
                sensor_ids = np.array(
                    [
                        self.data.sensor(f"rangefinder_{index}_{ring}_{ray}").id
                        for ring in range(advanced_shape[0])
                        for ray in range(advanced_shape[1])
                    ],
                    dtype=np.int32,
                )
                sensor_shape = advanced_shape
                last_ranges = np.full(sensor_shape, self.config.lidar_max_distance, dtype=np.float32)
                last_legacy_ranges = np.full(sensor_shape[1], self.config.lidar_max_distance, dtype=np.float32)
            else:
                sensor_ids = np.array(
                    [self.data.sensor(f"rangefinder_{index}_{ray}").id for ray in range(self.config.rangefinders)],
                    dtype=np.int32,
                )
                sensor_shape = (self.config.rangefinders,)
                last_ranges = np.full(self.config.rangefinders, self.config.lidar_max_distance, dtype=np.float32)
                last_legacy_ranges = last_ranges.copy()
            joint_name = f"car_{index}"
            joint_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_name)
            qpos_addr = int(self.model.jnt_qposadr[joint_id]) if joint_id >= 0 else -1
            qvel_addr = int(self.model.jnt_dofadr[joint_id]) if joint_id >= 0 else -1
            vehicles.append(
                VehicleRuntime(
                    id=index,
                    name=str(car.get("name", f"car {index}")),
                    driver_ref=driver_ref,
                    driver_path=driver_path,
                    controller=controller,
                    joint_name=joint_name,
                    body_name=f"car_{index}",
                    qpos_addr=qpos_addr,
                    qvel_addr=qvel_addr,
                    sensor_ids=sensor_ids,
                    spawn_progress=progress,
                    spawn_lateral_offset=lateral_offset,
                    car_index=car_index,
                    sensor_shape=sensor_shape,
                    last_error=last_error,
                    error_count=error_count,
                    last_ranges=last_ranges,
                    last_legacy_ranges=last_legacy_ranges,
                )
            )
        self.vehicles = vehicles

    def _position_vehicles(self, *, reset_progress: bool) -> None:
        assert self.geometry is not None
        self.active_car_collisions.clear()
        self.countdown_active = False
        self.countdown_remaining = 0.0
        for vehicle in self.vehicles:
            point, tangent, _normal = self.geometry.point_at(vehicle.spawn_progress, lateral_offset=vehicle.spawn_lateral_offset)
            vehicle.position[:] = point
            vehicle.last_safe_position[:] = point
            vehicle.yaw = math.atan2(float(tangent[1]), float(tangent[0]))
            vehicle.velocity[:] = 0.0
            vehicle.speed = 0.0
            vehicle.pitch = 0.0
            vehicle.roll = 0.0
            vehicle.pitch_rate = 0.0
            vehicle.roll_rate = 0.0
            vehicle.surface_height = 0.0
            vehicle.surface_grade = 0.0
            vehicle.surface_bank = 0.0
            vehicle.surface_vertical_curvature = 0.0
            vehicle.surface_load = 1.0
            self._reset_vehicle_vertical_state(vehicle)
            vehicle.steer = 0.0
            vehicle.target_speed = 0.0
            vehicle.target_steer = 0.0
            vehicle.yaw_rate = 0.0
            vehicle.distance_from_center = abs(vehicle.spawn_lateral_offset)
            if reset_progress:
                vehicle.raw_progress = 0.0
                vehicle.unwrapped_progress = 0.0
                vehicle.laps = 0
                vehicle.completion = 0.0
                vehicle.absolute_completion = 0.0
                vehicle.good_start = True
                vehicle.finished = False
                vehicle.finish_time = None
                vehicle.lap_start_time = 0.0
                vehicle.lap_times.clear()
                vehicle.peak_speed = 0.0
                vehicle.wall_contacts = 0
                vehicle.wall_touching = False
                vehicle.car_contacts = 0
                vehicle.center_error_total = 0.0
                vehicle.center_error_samples = 0
            index, _center, _tangent, _signed_offset, _progress = self.geometry.project(point)
            vehicle.track_index_hint = index
            self._update_vehicle_surface_state(vehicle)
            self._sync_vehicle_pose(vehicle)
        mujoco.mj_forward(self.model, self.data)
        self._refresh_sensor_data()
        if reset_progress:
            self.sim_time = 0.0
            self.step_count = 0
            self.sim_accumulator = 0.0
            self._arm_fresh_start()
        for vehicle in self.vehicles:
            self._update_progress(vehicle, self.sim_time)
            self._record_safe_state(vehicle)

    def _sync_vehicle_pose(self, vehicle: VehicleRuntime) -> None:
        assert self.data is not None
        if vehicle.qpos_addr >= 0 and vehicle.qvel_addr >= 0:
            qpos = self.data.qpos[vehicle.qpos_addr: vehicle.qpos_addr + 7]
            qvel = self.data.qvel[vehicle.qvel_addr: vehicle.qvel_addr + 6]
        else:
            joint = self.data.joint(vehicle.joint_name)
            qpos = joint.qpos
            qvel = joint.qvel
        qpos[:2] = vehicle.position
        qpos[2] = self._vehicle_body_height(vehicle)
        qpos[3:7] = _euler_to_quaternion(vehicle.roll, _render_pitch(vehicle.pitch), vehicle.yaw)
        qvel[:] = 0.0
        qvel[0] = vehicle.velocity[0]
        qvel[1] = vehicle.velocity[1]
        qvel[2] = vehicle.vertical_velocity if self.advanced_world is not None else 0.0
        qvel[3] = vehicle.roll_rate
        qvel[4] = vehicle.pitch_rate
        qvel[5] = vehicle.yaw_rate

    def _vehicle_body_height(self, vehicle: VehicleRuntime) -> float:
        if self.advanced_world is not None:
            return float(
                vehicle.surface_height
                + vehicle.ride_height
                + _advanced_body_surface_offset(vehicle.roll, _render_pitch(vehicle.pitch))
            )
        return float(vehicle.surface_height + 0.08)

    def _vehicle_tag_anchor(self, vehicle: VehicleRuntime) -> np.ndarray:
        body_center = np.array(
            [vehicle.position[0], vehicle.position[1], self._vehicle_body_height(vehicle)],
            dtype=np.float64,
        )
        rotation = _euler_to_matrix(vehicle.roll, _render_pitch(vehicle.pitch), vehicle.yaw)
        up_axis = rotation[:, 2].astype(np.float64, copy=False)
        up_norm = float(np.linalg.norm(up_axis))
        if up_norm <= 1e-6:
            up_axis = np.array([0.0, 0.0, 1.0], dtype=np.float64)
        else:
            up_axis = up_axis / up_norm
        return body_center + up_axis * 0.26

    def _reset_vehicle_vertical_state(self, vehicle: VehicleRuntime) -> None:
        vehicle.grounded = True
        vehicle.ride_height = 0.0
        vehicle.vertical_velocity = 0.0
        vehicle.airborne_time = 0.0
        vehicle.light_contact_time = 0.0
        vehicle.contact_scrub_time = 0.0
        vehicle.velocity[2] = 0.0
        vehicle.jump_armed = True
        vehicle.jump_cooldown_time = 0.0

    def _update_vehicle_surface_state(self, vehicle: VehicleRuntime, *, dt: float | None = None) -> None:
        previous_pitch = vehicle.pitch
        previous_roll = vehicle.roll
        previous_grounded = vehicle.grounded
        if self.advanced_world is None:
            vehicle.surface_height = 0.0
            vehicle.pitch = 0.0
            vehicle.roll = 0.0
            vehicle.surface_grade = 0.0
            vehicle.surface_bank = 0.0
            vehicle.surface_vertical_curvature = 0.0
            vehicle.surface_load = 1.0
            self._reset_vehicle_vertical_state(vehicle)
            vehicle.pitch_rate = 0.0
            vehicle.roll_rate = 0.0
            return
        previous_surface_height = vehicle.surface_height
        sample = self.advanced_world.sample_surface(
            vehicle.position,
            hint_progress=self._track_projection_hint(vehicle),
        )
        vehicle.surface_height = sample.height
        vehicle.pitch = sample.pitch
        vehicle.roll = sample.roll
        vehicle.surface_grade = sample.grade
        vehicle.surface_bank = sample.bank
        vehicle.surface_vertical_curvature = sample.vertical_curvature
        forward_speed = self._vehicle_body_velocity(vehicle)[0]
        vehicle.surface_load = vertical_load_factor(forward_speed, sample.vertical_curvature)
        if dt is not None and dt > 1e-6 and not previous_grounded:
            vehicle.ride_height += previous_surface_height - sample.height
        if dt is not None and dt > 1e-6:
            vehicle.jump_cooldown_time = max(0.0, vehicle.jump_cooldown_time - dt)
        launch_load = vehicle.surface_load < ADVANCED_LAUNCH_LOAD
        launch_speed = abs(forward_speed) >= ADVANCED_MIN_LAUNCH_SPEED
        launch_curve = sample.vertical_curvature < ADVANCED_LAUNCH_CURVATURE
        can_jump = vehicle.jump_armed and vehicle.jump_cooldown_time <= 1e-6
        should_launch = bool(sample.grounded and previous_grounded and can_jump and launch_load and launch_speed and launch_curve)
        if dt is None or dt <= 1e-6:
            vehicle.pitch_rate = 0.0
            vehicle.roll_rate = 0.0
        else:
            vehicle.pitch_rate = (vehicle.pitch - previous_pitch) / dt
            vehicle.roll_rate = (vehicle.roll - previous_roll) / dt
            if should_launch:
                launch_strength = _clip((ADVANCED_LAUNCH_LOAD - vehicle.surface_load) / max(1e-6, ADVANCED_LAUNCH_LOAD - 0.72), 0.0, 1.0)
                vehicle.grounded = False
                vehicle.jump_armed = False
                vehicle.jump_cooldown_time = 2.25
                vehicle.ride_height = max(vehicle.ride_height, 0.012)
                vehicle.vertical_velocity = max(
                    vehicle.vertical_velocity,
                    0.65 + 6.0 * launch_strength + 0.09 * max(0.0, abs(forward_speed) - ADVANCED_MIN_LAUNCH_SPEED),
                )
                vehicle.light_contact_time += dt
                vehicle.airborne_time += dt
            elif not previous_grounded:
                if vehicle.ride_height <= 0.0 and vehicle.vertical_velocity <= 0.0 and sample.grounded:
                    impact_speed = max(0.0, -vehicle.vertical_velocity)
                    vehicle.grounded = True
                    vehicle.ride_height = 0.0
                    vehicle.vertical_velocity = 0.0
                    vehicle.contact_scrub_time = max(
                        vehicle.contact_scrub_time,
                        min(0.58, 0.08 + vehicle.airborne_time * 0.55 + impact_speed * 0.055),
                    )
                    vehicle.light_contact_time = 0.0
                    vehicle.airborne_time = 0.0
                else:
                    vehicle.grounded = False
                    vehicle.ride_height = _clip(vehicle.ride_height, 0.0, ADVANCED_MAX_RIDE_HEIGHT)
                    vehicle.airborne_time += dt
            else:
                vehicle.grounded = bool(sample.grounded)
                if not (launch_load and launch_curve):
                    vehicle.jump_armed = True
                vehicle.ride_height = 0.0
                vehicle.vertical_velocity = 0.0
                vehicle.airborne_time = 0.0

            if vehicle.grounded:
                if not previous_grounded and vehicle.light_contact_time > 1e-4:
                    vehicle.contact_scrub_time = max(
                        vehicle.contact_scrub_time,
                        min(0.42, 0.06 + vehicle.light_contact_time * 0.72),
                    )
                vehicle.light_contact_time = max(0.0, vehicle.light_contact_time - dt * 3.0)
            elif vehicle.surface_load < ADVANCED_LIGHT_LOAD:
                vehicle.light_contact_time += dt
        vehicle.velocity[2] = float(vehicle.vertical_velocity)

    def _vehicle_snapshot(self, vehicle: VehicleRuntime) -> VehicleStateSnapshot:
        return VehicleStateSnapshot(
            laps=vehicle.laps,
            velocity=vehicle.velocity.tolist(),
            yaw=vehicle.yaw,
            pitch=vehicle.pitch,
            roll=vehicle.roll,
            lap_completion=vehicle.signed_completion(),
            absolute_completion=vehicle.absolute_completion,
            time=self.sim_time,
        )

    def _read_vehicle_ranges(self, vehicle: VehicleRuntime) -> np.ndarray:
        assert self.data is not None
        max_distance = float(self.config.lidar_max_distance)
        clipped = self.data.sensordata[vehicle.sensor_ids].astype(np.float32, copy=True)
        np.nan_to_num(clipped, copy=False, nan=max_distance, posinf=max_distance, neginf=max_distance)
        clipped[clipped <= 0.0] = max_distance
        np.clip(clipped, 0.0, max_distance, out=clipped)
        if self._is_advanced_mode() and len(vehicle.sensor_shape) == 2:
            return reshape_advanced_ranges(clipped)
        return clipped

    def _refresh_sensor_data(self) -> None:
        for vehicle in self.vehicles:
            vehicle.last_ranges = self._read_vehicle_ranges(vehicle)
            vehicle.last_legacy_ranges = flatten_legacy_lidar(vehicle.last_ranges)

    def _advanced_observation(self, vehicle: VehicleRuntime) -> AdvancedObservation:
        forward_speed, lateral_speed = self._vehicle_body_velocity(vehicle)
        return AdvancedObservation(
            lidar=np.array(vehicle.last_ranges, dtype=np.float32, copy=True),
            lidar_ring_pitches=ADVANCED_LIDAR_RING_PITCHES,
            yaw=vehicle.yaw,
            pitch=vehicle.pitch,
            roll=vehicle.roll,
            yaw_rate=vehicle.yaw_rate,
            pitch_rate=vehicle.pitch_rate,
            roll_rate=vehicle.roll_rate,
            body_velocity=(forward_speed, lateral_speed, vehicle.vertical_velocity),
            ride_height=vehicle.ride_height,
            vertical_velocity=vehicle.vertical_velocity,
            airborne_time=vehicle.airborne_time,
            grounded=vehicle.grounded,
            surface_load=vehicle.surface_load,
            vertical_curvature=vehicle.surface_vertical_curvature,
            slope=vehicle.surface_grade,
            bank=vehicle.surface_bank,
            lap_completion=vehicle.signed_completion(),
            absolute_completion=vehicle.absolute_completion,
            time=self.sim_time,
        )

    def _call_driver(self, vehicle: VehicleRuntime, snapshot: VehicleStateSnapshot | None) -> tuple[float, float]:
        start = time.perf_counter()
        try:
            if self.advanced_world is not None and vehicle.controller.accepts_advanced:
                output = vehicle.controller.driver.process_advanced(self._advanced_observation(vehicle))
            elif vehicle.controller.supports_lidar:
                ranges = vehicle.last_legacy_ranges if self.advanced_world is not None else vehicle.last_ranges
                if vehicle.controller.accepts_state:
                    assert snapshot is not None
                    output = vehicle.controller.driver.process_lidar(ranges, snapshot)
                else:
                    output = vehicle.controller.driver.process_lidar(ranges)
            else:
                raise ValueError("Driver does not support the current world mode")
            if not isinstance(output, (tuple, list)) or len(output) < 2:
                raise ValueError("Driver must return (speed, steering)")
            vehicle.last_error = None
            elapsed = time.perf_counter() - start
            vehicle.driver_call_count += 1
            vehicle.driver_total_time += elapsed
            vehicle.driver_max_time = max(vehicle.driver_max_time, elapsed)
            return float(output[0]), float(output[1])
        except Exception as exc:
            elapsed = time.perf_counter() - start
            vehicle.driver_call_count += 1
            vehicle.driver_total_time += elapsed
            vehicle.driver_max_time = max(vehicle.driver_max_time, elapsed)
            vehicle.last_error = f"{type(exc).__name__}: {exc}"
            vehicle.error_count += 1
            traceback.print_exc()
            return 0.0, 0.0

    def _reload_changed_drivers(self) -> None:
        if not self.config.auto_reload:
            return
        now = time.perf_counter()
        if now - self.last_reload_check < 0.5:
            return
        self.last_reload_check = now
        for vehicle in self.vehicles:
            try:
                if vehicle.controller.maybe_reload():
                    vehicle.last_error = None
                    self._status(f"Auto-reloaded {vehicle.name}")
            except Exception as exc:
                vehicle.last_error = f"{type(exc).__name__}: {exc}"
                vehicle.error_count += 1
                self._status(f"Auto-reload failed for {vehicle.name}: {exc}")

    def reload_all_drivers(self) -> None:
        for vehicle in self.vehicles:
            try:
                vehicle.controller.load()
                vehicle.last_error = None
            except Exception as exc:
                vehicle.last_error = f"{type(exc).__name__}: {exc}"
                vehicle.error_count += 1
                self._status(f"Reload failed for {vehicle.name}: {exc}")

    def _track_projection_hint(self, vehicle: VehicleRuntime) -> float | None:
        if self.geometry is None:
            return None
        if 0 <= vehicle.track_index_hint < len(self.geometry.cumulative_lengths):
            return float(self.geometry.cumulative_lengths[vehicle.track_index_hint])
        return self._absolute_track_progress(vehicle)

    def _vehicle_axes(self, yaw: float) -> tuple[np.ndarray, np.ndarray]:
        forward = np.array([math.cos(yaw), math.sin(yaw)], dtype=np.float32)
        lateral = np.array([-forward[1], forward[0]], dtype=np.float32)
        return forward, lateral

    def _vehicle_half_extents(self) -> np.ndarray:
        return np.array([self.config.car_half_length, self.config.car_half_width], dtype=np.float32)

    def _vehicle_box_state(
        self,
        vehicle: VehicleRuntime,
        *,
        position: np.ndarray | None = None,
        yaw: float | None = None,
    ) -> tuple[np.ndarray, tuple[np.ndarray, np.ndarray], np.ndarray]:
        center = vehicle.position.astype(np.float32) if position is None else position.astype(np.float32)
        box_yaw = vehicle.yaw if yaw is None else float(yaw)
        forward, lateral = self._vehicle_axes(box_yaw)
        return center, (forward, lateral), self._vehicle_half_extents()

    def _vehicle_corners(
        self,
        vehicle: VehicleRuntime,
        *,
        position: np.ndarray | None = None,
        yaw: float | None = None,
    ) -> list[np.ndarray]:
        center, axes, extents = self._vehicle_box_state(vehicle, position=position, yaw=yaw)
        forward, lateral = axes
        half_length, half_width = float(extents[0]), float(extents[1])
        return [
            center + forward * sx * half_length + lateral * sy * half_width
            for sx in (-1.0, 1.0)
            for sy in (-1.0, 1.0)
        ]

    def _obb_overlap_resolution(
        self,
        center_a: np.ndarray,
        axes_a: tuple[np.ndarray, np.ndarray],
        extents_a: np.ndarray,
        center_b: np.ndarray,
        axes_b: tuple[np.ndarray, np.ndarray],
        extents_b: np.ndarray,
        *,
        preferred_push: np.ndarray | None = None,
    ) -> tuple[np.ndarray, float] | None:
        delta = center_b - center_a
        best_push: np.ndarray | None = None
        best_overlap = float("inf")
        best_alignment = -float("inf")
        for axis in (*axes_a, *axes_b):
            projection_a = sum(float(extents_a[i]) * abs(float(np.dot(axis, axes_a[i]))) for i in range(2))
            projection_b = sum(float(extents_b[i]) * abs(float(np.dot(axis, axes_b[i]))) for i in range(2))
            signed_distance = float(np.dot(delta, axis))
            overlap = projection_a + projection_b - abs(signed_distance)
            if overlap <= 0.0:
                return None
            push = -axis if signed_distance >= 0.0 else axis
            alignment = 0.0 if preferred_push is None else float(np.dot(push, preferred_push))
            if overlap < best_overlap - 1e-6 or (abs(overlap - best_overlap) <= 1e-6 and alignment > best_alignment):
                best_overlap = overlap
                best_push = push
                best_alignment = alignment
        if best_push is None:
            return None
        return best_push.astype(np.float32), float(best_overlap)

    def _vehicle_support_along(
        self,
        vehicle: VehicleRuntime,
        axis: np.ndarray,
        *,
        yaw: float | None = None,
    ) -> float:
        forward, lateral = self._vehicle_axes(vehicle.yaw if yaw is None else float(yaw))
        return (
            abs(float(np.dot(axis, forward))) * self.config.car_half_length
            + abs(float(np.dot(axis, lateral))) * self.config.car_half_width
        )

    def _vehicle_lateral_support(
        self,
        vehicle: VehicleRuntime,
        tangent: np.ndarray,
        *,
        yaw: float | None = None,
    ) -> float:
        normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        return self._vehicle_support_along(vehicle, normal, yaw=yaw)

    def _vehicle_body_velocity(
        self,
        vehicle: VehicleRuntime,
        *,
        yaw: float | None = None,
    ) -> tuple[float, float]:
        heading = vehicle.yaw if yaw is None else float(yaw)
        forward, lateral = self._vehicle_axes(heading)
        planar = vehicle.velocity[:2].astype(np.float32)
        forward_speed = float(np.dot(planar, forward))
        lateral_speed = float(np.dot(planar, lateral))
        if abs(forward_speed) < 1e-5 and abs(lateral_speed) < 1e-5 and abs(vehicle.speed) > 1e-5:
            forward_speed = float(vehicle.speed)
        return forward_speed, lateral_speed

    def _set_vehicle_planar_velocity(
        self,
        vehicle: VehicleRuntime,
        *,
        forward_speed: float,
        lateral_speed: float = 0.0,
        yaw: float | None = None,
    ) -> None:
        heading = vehicle.yaw if yaw is None else float(yaw)
        forward_axis, lateral_axis = self._vehicle_axes(heading)
        planar = forward_axis * float(forward_speed) + lateral_axis * float(lateral_speed)
        vehicle.speed = float(forward_speed)
        vehicle.velocity[0] = float(planar[0])
        vehicle.velocity[1] = float(planar[1])
        vehicle.velocity[2] = float(vehicle.vertical_velocity if self.advanced_world is not None else 0.0)

    def _set_vehicle_world_velocity(
        self,
        vehicle: VehicleRuntime,
        planar_velocity: np.ndarray,
    ) -> None:
        planar = np.asarray(planar_velocity, dtype=np.float32)
        vehicle.velocity[0] = float(planar[0])
        vehicle.velocity[1] = float(planar[1])
        vehicle.velocity[2] = float(vehicle.vertical_velocity if self.advanced_world is not None else 0.0)
        vehicle.speed = self._vehicle_body_velocity(vehicle)[0]

    def _surface_dynamics(
        self,
        vehicle: VehicleRuntime,
        *,
        position: np.ndarray | None = None,
        yaw: float | None = None,
        hint_progress: float | None = None,
    ) -> tuple[float, float, object | None, AdvancedDynamicsFactors | None]:
        assert self.geometry is not None
        probe = vehicle.position.astype(np.float32) if position is None else position.astype(np.float32)
        projection_hint = self._track_projection_hint(vehicle) if hint_progress is None else hint_progress
        index, _center, tangent, signed_offset, progress = self.geometry.project(
            probe,
            hint_progress=projection_hint,
        )
        lateral_support = self._vehicle_lateral_support(vehicle, tangent, yaw=yaw)
        track_limit = max(0.0, self.geometry.settings.half_width - lateral_support)
        barrier_limit = max(track_limit, self.geometry.barrier_inner_face_offset - lateral_support)
        offset = abs(signed_offset)
        if track_limit <= 1e-5:
            return 0.58, 1.85, None, None

        grip_scale = 1.0
        drag_multiplier = 1.0
        if offset > track_limit and barrier_limit > track_limit + 1e-5:
            curb_ratio = _clip((offset - track_limit) / (barrier_limit - track_limit), 0.0, 1.0)
            grip_scale = 0.84 - 0.22 * curb_ratio
            drag_multiplier += 0.55 + 0.65 * curb_ratio
        advanced_sample = None
        if self.advanced_world is not None:
            advanced_sample = self.advanced_world.sample_surface_at_progress(
                progress,
                lateral_offset=signed_offset,
                xy=probe,
                index_hint=index,
            )
        return max(0.42, grip_scale), drag_multiplier, advanced_sample, None

    def _apply_wall_impact_response(
        self,
        vehicle: VehicleRuntime,
        *,
        tangent: np.ndarray,
        damping: float,
    ) -> None:
        tangent_norm = float(np.linalg.norm(tangent))
        if tangent_norm <= 1e-6:
            tangent = np.array([1.0, 0.0], dtype=np.float32)
        else:
            tangent = (tangent / tangent_norm).astype(np.float32)
        planar_velocity = vehicle.velocity[:2].astype(np.float32)
        if float(np.dot(planar_velocity, planar_velocity)) <= 1e-8:
            forward, _lateral = self._vehicle_axes(vehicle.yaw)
            planar_velocity = forward * float(vehicle.speed)
        tangential_velocity = tangent * float(np.dot(planar_velocity, tangent)) * damping
        forward_speed, lateral_speed = self._vehicle_body_velocity(vehicle)
        retained_forward = float(np.dot(tangential_velocity, self._vehicle_axes(vehicle.yaw)[0]))
        retained_lateral = float(np.dot(tangential_velocity, self._vehicle_axes(vehicle.yaw)[1]))
        if abs(retained_forward) < 0.02:
            retained_forward = 0.0
        if abs(retained_lateral) < 0.02:
            retained_lateral = 0.0
        if abs(retained_forward) > abs(forward_speed):
            retained_forward = forward_speed * damping
        if abs(retained_lateral) > abs(lateral_speed):
            retained_lateral = lateral_speed * damping
        self._set_vehicle_planar_velocity(vehicle, forward_speed=retained_forward, lateral_speed=retained_lateral)
        vehicle.yaw_rate = 0.0

    def _requires_emergency_restore(self, vehicle: VehicleRuntime) -> bool:
        assert self.geometry is not None
        if not np.all(np.isfinite(vehicle.position)):
            return True
        hint_progress = self._track_projection_hint(vehicle)
        index, _center, tangent, signed_offset, _progress = self.geometry.project(vehicle.position, hint_progress=hint_progress)
        vehicle.track_index_hint = index
        lateral_support = self._vehicle_lateral_support(vehicle, tangent)
        emergency_limit = (
            self.geometry.barrier_inner_face_offset
            + self.geometry.settings.wall_thickness
            + lateral_support
            + 0.75
        )
        return abs(signed_offset) > emergency_limit

    def _wall_segment_overlap(
        self,
        vehicle: VehicleRuntime,
        segment: SegmentStyle,
        *,
        position: np.ndarray | None = None,
        yaw: float | None = None,
        previous_position: np.ndarray | None = None,
    ) -> tuple[np.ndarray, float, np.ndarray] | None:
        center_a, axes_a, extents_a = self._vehicle_box_state(vehicle, position=position, yaw=yaw)
        tangent = np.array([math.cos(segment.yaw), math.sin(segment.yaw)], dtype=np.float32)
        normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        center_b = np.asarray(segment.position[:2], dtype=np.float32)
        axes_b = (tangent, normal)
        extents_b = np.array([float(segment.size[0]), float(segment.size[1])], dtype=np.float32)
        preferred_push = None
        if previous_position is not None:
            motion = center_a - previous_position.astype(np.float32)
            motion_norm = float(np.linalg.norm(motion))
            if motion_norm > 1e-6:
                preferred_push = (-motion / motion_norm).astype(np.float32)
        overlap = self._obb_overlap_resolution(
            center_a,
            axes_a,
            extents_a,
            center_b,
            axes_b,
            extents_b,
            preferred_push=preferred_push,
        )
        if overlap is None:
            return None
        push, penetration = overlap
        return push, penetration, tangent

    def _vehicle_pair_overlap(
        self,
        a: VehicleRuntime,
        b: VehicleRuntime,
        *,
        position_a: np.ndarray | None = None,
        position_b: np.ndarray | None = None,
    ) -> tuple[np.ndarray, float] | None:
        center_a, axes_a, extents_a = self._vehicle_box_state(a, position=position_a)
        center_b, axes_b, extents_b = self._vehicle_box_state(b, position=position_b)
        delta = center_b - center_a
        preferred_push = None
        norm = float(np.linalg.norm(delta))
        if norm > 1e-6:
            preferred_push = (-delta / norm).astype(np.float32)
        return self._obb_overlap_resolution(
            center_a,
            axes_a,
            extents_a,
            center_b,
            axes_b,
            extents_b,
            preferred_push=preferred_push,
        )

    def _vehicle_is_on_track(
        self,
        vehicle: VehicleRuntime,
        *,
        position: np.ndarray | None = None,
        yaw: float | None = None,
        hint_progress: float | None = None,
        search_radius: int = 12,
    ) -> bool:
        assert self.geometry is not None
        probe = vehicle.position.astype(np.float32) if position is None else position.astype(np.float32)
        if hint_progress is None:
            search_radius = len(self.geometry.centerline)
        _index, _center, tangent, signed_offset, _progress = self.geometry.project(
            probe,
            hint_progress=hint_progress,
            search_radius=search_radius,
        )
        barrier_limit = max(0.0, self.geometry.barrier_inner_face_offset - self._vehicle_lateral_support(vehicle, tangent, yaw=yaw))
        if abs(signed_offset) > barrier_limit + 1e-4:
            return False
        radius = self.config.car_radius
        for segment in self._nearby_wall_segments(probe, radius):
            center = np.asarray(segment.position[:2], dtype=np.float32)
            max_distance = radius + math.hypot(float(segment.size[0]), float(segment.size[1])) + 0.04
            delta = probe - center
            if float(np.dot(delta, delta)) > max_distance * max_distance:
                continue
            if self._wall_segment_overlap(vehicle, segment, position=probe, yaw=yaw) is not None:
                return False
        return True

    def _resolve_wall_penetration(self, vehicle: VehicleRuntime, previous_position: np.ndarray) -> bool:
        assert self.geometry is not None
        assert self.model is not None
        hint_progress = self._track_projection_hint(vehicle)
        _prev_index, _prev_center, prev_tangent, previous_offset, _prev_progress = self.geometry.project(
            previous_position,
            hint_progress=hint_progress,
        )
        curr_index, current_center, current_tangent, current_offset, _curr_progress = self.geometry.project(
            vehicle.position,
            hint_progress=hint_progress,
        )
        vehicle.track_index_hint = curr_index
        previous_limit = max(0.0, self.geometry.barrier_inner_face_offset - self._vehicle_lateral_support(vehicle, prev_tangent) - 0.02)
        current_limit = max(0.0, self.geometry.barrier_inner_face_offset - self._vehicle_lateral_support(vehicle, current_tangent) - 0.02)
        safe_margin = max(0.10, abs(vehicle.speed) * self.model.opt.timestep * 1.5)
        if abs(previous_offset) < previous_limit - safe_margin and abs(current_offset) < current_limit - safe_margin:
            return False

        hit = self.geometry.first_wall_hit(
            previous_position,
            vehicle.position,
            hint_progress=hint_progress,
            search_radius=20,
        )
        if hit is None:
            if abs(current_offset) <= current_limit + 1e-4:
                return False
            center = current_center
            tangent = current_tangent
            signed_offset = current_offset
            barrier_limit = current_limit
        else:
            _t, hit_point = hit
            _index, center, tangent, signed_offset, _progress = self.geometry.project(hit_point, hint_progress=hint_progress)
            barrier_limit = max(0.0, self.geometry.barrier_inner_face_offset - self._vehicle_lateral_support(vehicle, tangent) - 0.02)
        normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        safe_sign = 1.0 if signed_offset >= 0.0 else -1.0
        if abs(signed_offset) <= 1e-5:
            previous_offset = float(np.dot(previous_position - center, normal))
            safe_sign = 1.0 if previous_offset >= 0.0 else -1.0
        vehicle.position[:] = center + normal * (barrier_limit * safe_sign)
        vehicle.distance_from_center = min(abs(signed_offset), barrier_limit)
        self._apply_wall_impact_response(vehicle, tangent=tangent, damping=0.42)
        if not vehicle.wall_touching:
            vehicle.wall_contacts += 1
        vehicle.wall_touching = True
        return True

    def _resolve_wall_segment_overlap(self, vehicle: VehicleRuntime, previous_position: np.ndarray) -> bool:
        assert self.geometry is not None
        resolved = False
        last_tangent: np.ndarray | None = None
        for _ in range(6):
            best_overlap: tuple[np.ndarray, float, np.ndarray] | None = None
            best_penetration = 0.0
            position = vehicle.position.astype(np.float32)
            for segment in self._nearby_wall_segments(position):
                center = np.asarray(segment.position[:2], dtype=np.float32)
                max_distance = self.config.car_radius + math.hypot(float(segment.size[0]), float(segment.size[1])) + 0.04
                delta = position - center
                if float(np.dot(delta, delta)) > max_distance * max_distance:
                    continue
                overlap = self._wall_segment_overlap(
                    vehicle,
                    segment,
                    position=position,
                    previous_position=previous_position,
                )
                if overlap is None:
                    continue
                if overlap[1] > best_penetration:
                    best_overlap = overlap
                    best_penetration = overlap[1]
            if best_overlap is None:
                break
            push, penetration, tangent = best_overlap
            vehicle.position[:] = vehicle.position + push * (penetration + 1e-3)
            resolved = True
            last_tangent = tangent

        if not resolved:
            return False

        hint_progress = self._track_projection_hint(vehicle)
        index, _center, fallback_tangent, signed_offset, _progress = self.geometry.project(
            vehicle.position,
            hint_progress=hint_progress,
        )
        vehicle.track_index_hint = index
        vehicle.distance_from_center = abs(signed_offset)
        tangent = fallback_tangent if last_tangent is None else last_tangent
        self._apply_wall_impact_response(vehicle, tangent=tangent, damping=0.36)
        if not vehicle.wall_touching:
            vehicle.wall_contacts += 1
        vehicle.wall_touching = True
        return True

    def _stabilize_vehicle_after_motion(self, vehicle: VehicleRuntime, previous_position: np.ndarray) -> None:
        assert self.geometry is not None
        wall_hit = self._resolve_wall_penetration(vehicle, previous_position)
        panel_hit = False if self.advanced_world is not None else self._resolve_wall_segment_overlap(vehicle, previous_position)
        if wall_hit or panel_hit:
            return
        self._constrain_to_track(vehicle)

    def _recover_to_track_corridor(self, vehicle: VehicleRuntime, previous_position: np.ndarray) -> bool:
        assert self.geometry is not None
        hint_progress = self._track_projection_hint(vehicle)
        if self._vehicle_is_on_track(vehicle, hint_progress=hint_progress):
            return False

        current = vehicle.position.copy()
        safe_point = previous_position.copy()
        recovered_from_valid_previous = self._vehicle_is_on_track(vehicle, position=previous_position, hint_progress=hint_progress)
        if recovered_from_valid_previous:
            low = 0.0
            high = 1.0
            for _ in range(18):
                mid = 0.5 * (low + high)
                probe = previous_position + (current - previous_position) * mid
                if self._vehicle_is_on_track(vehicle, position=probe, hint_progress=hint_progress):
                    safe_point = probe
                    low = mid
                else:
                    high = mid
            backoff = max(0.0, low - 0.02)
            safe_point = previous_position + (current - previous_position) * backoff
            if not self._vehicle_is_on_track(vehicle, position=safe_point, hint_progress=hint_progress):
                safe_point = previous_position.copy()
        else:
            index, center, tangent, signed_offset, progress = self.geometry.project(current, hint_progress=hint_progress)
            vehicle.track_index_hint = index
            normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
            barrier_limit = max(0.0, self.geometry.barrier_inner_face_offset - self._vehicle_lateral_support(vehicle, tangent) - 0.06)
            clamped_offset = _clip(signed_offset, -barrier_limit, barrier_limit)
            safe_point = center + normal * clamped_offset
            if not self._vehicle_is_on_track(vehicle, position=safe_point, hint_progress=progress):
                safe_point = center.copy()

        vehicle.position[:] = safe_point
        if not self._vehicle_is_on_track(vehicle, hint_progress=hint_progress):
            vehicle.position[:] = vehicle.last_safe_position
        self._reset_vehicle_vertical_state(vehicle)
        if recovered_from_valid_previous:
            hint_progress = self._track_projection_hint(vehicle)
            index, _center, _tangent, signed_offset, _progress = self.geometry.project(vehicle.position, hint_progress=hint_progress)
            vehicle.track_index_hint = index
            vehicle.distance_from_center = abs(signed_offset)
        else:
            self._constrain_to_track(vehicle)
        vehicle.speed *= 0.10
        vehicle.velocity[:] = 0.0
        if not vehicle.wall_touching:
            vehicle.wall_contacts += 1
        vehicle.wall_touching = True
        return True

    def _constrain_to_track(self, vehicle: VehicleRuntime) -> None:
        assert self.geometry is not None
        hint_progress = self._track_projection_hint(vehicle)
        index, center, tangent, signed_offset, _progress = self.geometry.project(vehicle.position, hint_progress=hint_progress)
        vehicle.track_index_hint = index
        vehicle.distance_from_center = abs(signed_offset)

        lateral_support = self._vehicle_lateral_support(vehicle, tangent)
        track_limit = max(0.0, self.geometry.settings.half_width - lateral_support)
        off_track = max(0.0, abs(signed_offset) - track_limit)
        if off_track > 0.0:
            scrub = max(0.50, 1.0 - off_track * 0.42)
            vehicle.speed *= scrub
            vehicle.velocity[0] *= scrub
            vehicle.velocity[1] *= scrub

        barrier_limit = max(0.0, self.geometry.barrier_inner_face_offset - lateral_support)
        if abs(signed_offset) <= barrier_limit:
            vehicle.wall_touching = False

    def _advance_vehicle(self, vehicle: VehicleRuntime, dt: float) -> None:
        assert self.geometry is not None
        previous_position = vehicle.position.copy()
        desired_speed = _clip(vehicle.target_speed, -self.config.max_speed_command, self.config.max_speed_command)
        desired_steer = _clip(vehicle.target_steer, -self.config.max_steer_command, self.config.max_steer_command)
        if vehicle.finished:
            desired_speed = 0.0
            desired_steer = 0.0

        steer_delta = desired_steer - vehicle.steer
        steer_step = _clip(steer_delta, -self.config.steering_rate * dt, self.config.steering_rate * dt)
        vehicle.steer = _clip(vehicle.steer + steer_step, -1.0, 1.0)

        speed_delta = desired_speed - vehicle.speed
        if abs(desired_speed) >= abs(vehicle.speed) and desired_speed * vehicle.speed >= 0.0:
            limit = self.config.accel_rate
        else:
            limit = self.config.brake_rate
        base_grip_scale, base_surface_drag, advanced_sample, _advanced_factors = self._surface_dynamics(vehicle, position=previous_position)
        advanced_factors = None
        grip_scale = base_grip_scale
        surface_drag = base_surface_drag
        contact_grip_multiplier = 1.0
        drive_authority = 1.0
        yaw_authority = 1.0
        contact_scrub_intensity = 0.0
        if advanced_sample is not None:
            advanced_factors = combine_surface_dynamics(
                base_grip=max(0.55, base_grip_scale),
                base_drag=base_surface_drag,
                bank_radians=advanced_sample.bank,
                terrain_mix=advanced_sample.terrain_mix,
                roughness=advanced_sample.roughness,
                grade=advanced_sample.grade,
                speed=vehicle.speed,
                vertical_curvature=advanced_sample.vertical_curvature,
            )
            grip_scale = advanced_factors.grip_scale
            surface_drag = advanced_factors.drag_multiplier
            load_factor = advanced_factors.load_factor
            if not vehicle.grounded:
                contact_authority = 0.12
                contact_grip_multiplier *= contact_authority
                surface_drag += 1.15
                drive_authority = min(drive_authority, 0.18)
                yaw_authority = min(yaw_authority, 0.10)
            elif load_factor < ADVANCED_PARTIAL_CONTACT_LOAD:
                contact_authority = _clip(
                    (load_factor - 0.32) / max(1e-6, ADVANCED_PARTIAL_CONTACT_LOAD - 0.32),
                    0.14,
                    0.66,
                )
                contact_grip_multiplier *= contact_authority
                surface_drag += 0.90 * (1.0 - contact_authority)
                drive_authority = min(drive_authority, max(0.28, contact_authority))
                yaw_authority = min(yaw_authority, max(0.18, contact_authority))
            elif load_factor < ADVANCED_LIGHT_LOAD:
                lightness = _clip((ADVANCED_LIGHT_LOAD - load_factor) / 0.30, 0.0, 1.0)
                contact_grip_multiplier *= 1.0 - 0.16 * lightness
                surface_drag += 0.18 * lightness
                drive_authority = min(drive_authority, 1.0 - 0.08 * lightness)
                yaw_authority = min(yaw_authority, 1.0 - 0.12 * lightness)
            if vehicle.contact_scrub_time > 0.0:
                contact_scrub_intensity = _clip(vehicle.contact_scrub_time / 0.42, 0.0, 1.0)
                contact_grip_multiplier *= 1.0 - 0.18 * contact_scrub_intensity
                surface_drag += 0.70 * contact_scrub_intensity
            grip_scale *= contact_grip_multiplier
        current_forward_speed = vehicle.speed + _clip(
            speed_delta,
            -limit * dt * grip_scale * drive_authority,
            limit * dt * grip_scale * drive_authority,
        )
        current_lateral_speed = self._vehicle_body_velocity(vehicle)[1]
        if advanced_sample is not None and advanced_factors is not None:
            slope_authority = 0.0 if not vehicle.grounded else max(0.35, drive_authority)
            current_forward_speed += advanced_factors.slope_acceleration * dt * slope_authority
        drag = 1.0 / (
            1.0
            + self.config.drag_coefficient
            * dt
            * (
                1.0
                + 0.75 * abs(vehicle.steer)
                + 0.22 * abs(current_lateral_speed)
                + max(0.0, surface_drag - 1.0)
            )
        )
        current_forward_speed *= drag
        current_forward_speed = _clip(current_forward_speed, -self.config.max_reverse_speed, self.config.max_vehicle_speed)
        if contact_scrub_intensity > 0.0:
            current_forward_speed *= 1.0 / (1.0 + dt * (2.0 + 4.5 * contact_scrub_intensity))
            current_lateral_speed *= 1.0 / (1.0 + dt * (1.6 + 3.4 * contact_scrub_intensity))
            vehicle.contact_scrub_time = max(0.0, vehicle.contact_scrub_time - dt)

        steer_angle = vehicle.steer * self.config.max_steer_angle
        requested_yaw_rate = 0.0 if abs(steer_angle) < 1e-4 or abs(current_forward_speed) < 1e-4 else current_forward_speed / self.config.wheelbase * math.tan(steer_angle)
        requested_yaw_rate *= yaw_authority
        requested_lateral_accel = abs(current_forward_speed * requested_yaw_rate)
        lateral_grip_scale = grip_scale
        if advanced_sample is not None:
            turn_direction = 0.0 if abs(requested_yaw_rate) < 1e-5 else math.copysign(1.0, requested_yaw_rate)
            turn_intensity = _clip(requested_lateral_accel / 11.5, 0.0, 1.0)
            corner_factors = combine_surface_dynamics(
                base_grip=max(0.55, base_grip_scale),
                base_drag=base_surface_drag,
                bank_radians=advanced_sample.bank,
                terrain_mix=advanced_sample.terrain_mix,
                roughness=advanced_sample.roughness,
                grade=advanced_sample.grade,
                speed=current_forward_speed,
                vertical_curvature=advanced_sample.vertical_curvature,
                turn_direction=turn_direction,
                turn_intensity=turn_intensity,
            )
            lateral_grip_scale = corner_factors.grip_scale * contact_grip_multiplier

        if abs(steer_angle) < 1e-4 or abs(current_forward_speed) < 1e-4:
            vehicle.yaw_rate *= max(0.0, 1.0 - dt * 10.0)
            current_lateral_speed *= 1.0 / (1.0 + dt * 12.0 * lateral_grip_scale)
        else:
            available_lateral_accel = max(4.8, 14.5 * lateral_grip_scale)
            if requested_lateral_accel <= available_lateral_accel + 1e-4:
                yaw_response = min(1.0, dt * (8.8 - 1.6 * (1.0 - lateral_grip_scale)))
                vehicle.yaw_rate = _lerp(vehicle.yaw_rate, requested_yaw_rate, yaw_response)
                current_lateral_speed *= 1.0 / (1.0 + dt * (12.5 * lateral_grip_scale + 1.0))
            else:
                slip_ratio = requested_lateral_accel / available_lateral_accel - 1.0
                limited_yaw_rate = math.copysign(
                    available_lateral_accel / max(abs(current_forward_speed), 1.35),
                    requested_yaw_rate,
                )
                vehicle.yaw_rate = _lerp(vehicle.yaw_rate, limited_yaw_rate, min(1.0, dt * 5.2))
                slide_sign = -1.0 if requested_yaw_rate >= 0.0 else 1.0
                target_lateral_speed = slide_sign * min(
                    abs(current_forward_speed) * 0.65,
                    abs(current_forward_speed) * (0.08 + 0.24 * min(2.0, slip_ratio)),
                )
                current_lateral_speed = _lerp(
                    current_lateral_speed,
                    target_lateral_speed,
                    min(1.0, dt * (2.6 + 1.4 * min(2.5, slip_ratio))),
                )
                current_lateral_speed *= 1.0 / (1.0 + dt * (1.5 + 1.1 * lateral_grip_scale))
                load_penalty = 1.0
                if advanced_factors is not None:
                    load_penalty += 0.45 * max(0.0, 1.0 - advanced_factors.load_factor)
                current_forward_speed *= 1.0 / (1.0 + dt * (0.75 + 1.45 * min(2.0, slip_ratio)) * load_penalty)
        vehicle.yaw += vehicle.yaw_rate * dt
        self._set_vehicle_planar_velocity(
            vehicle,
            forward_speed=current_forward_speed,
            lateral_speed=current_lateral_speed,
        )
        if self.advanced_world is not None:
            if vehicle.grounded:
                vehicle.ride_height = 0.0
                vehicle.vertical_velocity = 0.0
            else:
                vehicle.vertical_velocity -= ADVANCED_GRAVITY * dt
                vehicle.ride_height += vehicle.vertical_velocity * dt
                if vehicle.ride_height > ADVANCED_MAX_RIDE_HEIGHT:
                    vehicle.ride_height = ADVANCED_MAX_RIDE_HEIGHT
                    vehicle.vertical_velocity = min(0.0, vehicle.vertical_velocity)
            vehicle.velocity[2] = float(vehicle.vertical_velocity)
        vehicle.position[:] = vehicle.position + vehicle.velocity[:2] * dt
        self._stabilize_vehicle_after_motion(vehicle, previous_position)
        vehicle.center_error_total += vehicle.distance_from_center
        vehicle.center_error_samples += 1
        vehicle.speed = self._vehicle_body_velocity(vehicle)[0]
        vehicle.peak_speed = max(vehicle.peak_speed, float(np.linalg.norm(vehicle.velocity[:2])))

    def _resolve_vehicle_collisions(self) -> None:
        current_collisions: set[tuple[int, int]] = set()
        for i in range(len(self.vehicles)):
            for j in range(i + 1, len(self.vehicles)):
                a = self.vehicles[i]
                b = self.vehicles[j]
                delta = b.position - a.position
                broadphase = self.config.car_radius * 2.0
                if float(np.dot(delta, delta)) >= broadphase * broadphase:
                    continue
                overlap = self._vehicle_pair_overlap(a, b)
                if overlap is None:
                    continue
                pair = (a.id, b.id)
                current_collisions.add(pair)
                if pair not in self.active_car_collisions:
                    a.car_contacts += 1
                    b.car_contacts += 1
                previous_a = a.position.copy()
                previous_b = b.position.copy()
                push, penetration = overlap
                correction = push * (penetration * 0.5 + 1e-3)
                a.position[:] = a.position + correction
                b.position[:] = b.position - correction
                normal = -push.astype(np.float32)
                norm = float(np.linalg.norm(normal))
                if norm <= 1e-6:
                    delta = b.position - a.position
                    norm = float(np.linalg.norm(delta))
                    normal = (delta / max(norm, 1e-6)).astype(np.float32) if norm > 1e-6 else np.array([1.0, 0.0], dtype=np.float32)
                else:
                    normal = (normal / norm).astype(np.float32)
                tangent = np.array([-normal[1], normal[0]], dtype=np.float32)

                velocity_a = a.velocity[:2].astype(np.float32)
                velocity_b = b.velocity[:2].astype(np.float32)
                relative_velocity = velocity_b - velocity_a
                normal_speed = float(np.dot(relative_velocity, normal))

                if normal_speed < -1e-5:
                    inv_mass_a = 1.0 / 3.0
                    inv_mass_b = 1.0 / 3.0
                    restitution = 0.18
                    impulse_mag = -(1.0 + restitution) * normal_speed / (inv_mass_a + inv_mass_b)
                    impulse = normal * impulse_mag
                    velocity_a = velocity_a - impulse * inv_mass_a
                    velocity_b = velocity_b + impulse * inv_mass_b

                    tangential_speed = float(np.dot(relative_velocity, tangent))
                    friction_impulse_mag = -tangential_speed / (inv_mass_a + inv_mass_b)
                    max_friction = impulse_mag * 0.42
                    friction_impulse_mag = _clip(friction_impulse_mag, -max_friction, max_friction)
                    friction_impulse = tangent * friction_impulse_mag
                    velocity_a = velocity_a - friction_impulse * inv_mass_a
                    velocity_b = velocity_b + friction_impulse * inv_mass_b
                else:
                    velocity_a *= 0.995
                    velocity_b *= 0.995

                self._set_vehicle_world_velocity(a, velocity_a)
                self._set_vehicle_world_velocity(b, velocity_b)
                a.yaw_rate *= 0.76
                b.yaw_rate *= 0.76
                self._stabilize_vehicle_after_motion(a, previous_a)
                self._stabilize_vehicle_after_motion(b, previous_b)
        self.active_car_collisions = current_collisions

    def _update_progress(self, vehicle: VehicleRuntime, current_time: float) -> None:
        assert self.geometry is not None
        hint_progress = self._track_projection_hint(vehicle)
        index, _point, _tangent, _offset, progress = self.geometry.project(vehicle.position, hint_progress=hint_progress)
        vehicle.track_index_hint = index
        raw_progress = ((progress - vehicle.spawn_progress) % self.geometry.total_length) / self.geometry.total_length
        delta = ((raw_progress - vehicle.raw_progress + 0.5) % 1.0) - 0.5
        previous = vehicle.unwrapped_progress
        vehicle.unwrapped_progress += delta
        vehicle.raw_progress = raw_progress
        vehicle.laps = max(0, int(math.floor(vehicle.unwrapped_progress + 1e-9)))
        completion = ((vehicle.unwrapped_progress % 1.0) + 1.0) % 1.0
        vehicle.completion = completion * 100.0
        vehicle.good_start = vehicle.unwrapped_progress >= 0.0
        vehicle.absolute_completion = vehicle.unwrapped_progress * 100.0

        previous_laps = max(0, int(math.floor(previous + 1e-9)))
        if vehicle.laps > previous_laps:
            vehicle.lap_times.append(current_time - vehicle.lap_start_time)
            vehicle.lap_start_time = current_time
        elif vehicle.laps < previous_laps and vehicle.lap_times:
            vehicle.lap_times.pop()
            vehicle.lap_start_time = current_time

        if not vehicle.finished and vehicle.unwrapped_progress >= self.config.lap_target:
            vehicle.finished = True
            vehicle.finish_time = current_time
            vehicle.target_speed = 0.0
            vehicle.target_steer = 0.0

    def _record_safe_state(self, vehicle: VehicleRuntime) -> None:
        if self.geometry is None:
            return
        if vehicle.wall_touching or not np.all(np.isfinite(vehicle.position)):
            return
        if vehicle.distance_from_center > self.geometry.barrier_inner_face_offset + self.geometry.settings.wall_thickness + 0.1:
            return
        vehicle.last_safe_position[:] = vehicle.position

    def _restore_last_safe_state(self, vehicle: VehicleRuntime) -> None:
        if not self._requires_emergency_restore(vehicle):
            return
        vehicle.position[:] = vehicle.last_safe_position
        vehicle.velocity[:] = 0.0
        vehicle.speed = 0.0
        vehicle.yaw_rate = 0.0
        vehicle.target_speed = 0.0
        vehicle.target_steer = 0.0
        self._reset_vehicle_vertical_state(vehicle)
        self._constrain_to_track(vehicle)
        if not vehicle.wall_touching:
            vehicle.wall_contacts += 1
        vehicle.wall_touching = True

    def _step(self) -> None:
        dt = 1.0 / self.config.physics_hz
        self._reload_changed_drivers()
        control_tick = (self.step_count % self.sensor_stride) == 0

        for vehicle in self.vehicles:
            if control_tick:
                snapshot = self._vehicle_snapshot(vehicle) if vehicle.controller.accepts_state else None
                speed, steer = self._call_driver(vehicle, snapshot)
                vehicle.target_speed = _clip(speed, -self.config.max_speed_command, self.config.max_speed_command)
                vehicle.target_steer = _clip(steer, -self.config.max_steer_command, self.config.max_steer_command)
            if self.manual_control and self.watching == vehicle.id:
                speed, steer = self.manual_speed, self.manual_steer
                vehicle.target_speed = _clip(speed, -self.config.max_speed_command, self.config.max_speed_command)
                vehicle.target_steer = _clip(steer, -self.config.max_steer_command, self.config.max_steer_command)

        for vehicle in self.vehicles:
            self._advance_vehicle(vehicle, dt)

        self._resolve_vehicle_collisions()
        for vehicle in self.vehicles:
            self._restore_last_safe_state(vehicle)

        for vehicle in self.vehicles:
            self._update_vehicle_surface_state(vehicle, dt=dt)
            self._sync_vehicle_pose(vehicle)
        next_step_count = self.step_count + 1
        if next_step_count % self.sensor_stride == 0:
            mujoco.mj_forward(self.model, self.data)
            self._refresh_sensor_data()
        else:
            mujoco.mj_forwardSkip(self.model, self.data, mujoco.mjtStage.mjSTAGE_NONE, 1)

        self.sim_time += dt
        self.step_count = next_step_count
        for vehicle in self.vehicles:
            self._update_progress(vehicle, self.sim_time)
            self._record_safe_state(vehicle)

    def _race_mode_label(self) -> str:
        return RACE_MODE_INFO.get(self.config.race_mode, RACE_MODE_INFO["grand_prix"])["label"]

    def _best_lap_time(self, vehicle: VehicleRuntime) -> float | None:
        if not vehicle.lap_times:
            return None
        return float(min(vehicle.lap_times))

    def _total_contacts(self, vehicle: VehicleRuntime) -> int:
        return int(vehicle.wall_contacts + vehicle.car_contacts)

    def _mean_center_error(self, vehicle: VehicleRuntime) -> float | None:
        if vehicle.center_error_samples <= 0:
            return None
        return float(vehicle.center_error_total / max(1, vehicle.center_error_samples))

    def _consistency_spread(self, vehicle: VehicleRuntime) -> float | None:
        if len(vehicle.lap_times) < 2:
            return None
        return float(np.std(np.array(vehicle.lap_times, dtype=np.float32)))

    def _standings_key(self, vehicle: VehicleRuntime) -> tuple:
        mode = self.config.race_mode
        if mode == "qualifying":
            best_lap = self._best_lap_time(vehicle)
            return (0 if best_lap is not None else 1, best_lap or float("inf"), -vehicle.unwrapped_progress, self._total_contacts(vehicle))
        if mode == "clean_race":
            return (self._total_contacts(vehicle), 0 if vehicle.finished else 1, vehicle.finish_time or float("inf"), -vehicle.unwrapped_progress)
        if mode == "precision":
            mean_error = self._mean_center_error(vehicle)
            return (0 if mean_error is not None else 1, mean_error or float("inf"), self._total_contacts(vehicle), -vehicle.unwrapped_progress)
        if mode == "consistency":
            spread = self._consistency_spread(vehicle)
            best_lap = self._best_lap_time(vehicle)
            return (0 if spread is not None else 1, spread or float("inf"), best_lap or float("inf"), -vehicle.unwrapped_progress)
        return (0 if vehicle.finished else 1, vehicle.finish_time or float("inf"), -vehicle.unwrapped_progress)

    def _standings(self) -> list[VehicleRuntime]:
        if self.standings_cache is None or self.standings_cache_step != self.step_count:
            self.standings_cache = sorted(self.vehicles, key=self._standings_key)
            self.standings_cache_step = self.step_count
        return self.standings_cache

    def _build_trackside_cameras(self) -> list[TracksideCamera]:
        if self.geometry is None:
            return []
        headings = np.arctan2(self.geometry.tangents[:, 1], self.geometry.tangents[:, 0])
        candidates: list[tuple[float, int]] = []
        for index in range(len(self.geometry.centerline)):
            turn = abs((headings[(index + 1) % len(headings)] - headings[index - 1] + math.pi) % (2.0 * math.pi) - math.pi)
            if turn >= 0.10:
                candidates.append((turn, index))
        candidates.sort(reverse=True)

        selected: list[int] = []
        selected_progress: list[float] = []
        minimum_gap = max(6.5, self.geometry.total_length / 11.0)
        for strength, index in candidates:
            progress = float(self.geometry.cumulative_lengths[index])
            if all(min(abs(progress - current), self.geometry.total_length - abs(progress - current)) >= minimum_gap for current in selected_progress):
                selected.append(index)
                selected_progress.append(progress)
            if len(selected) >= 10:
                break

        desired_count = max(6, min(10, len(self.geometry.centerline) // 36))
        if len(selected) < desired_count:
            fallback = np.linspace(0, len(self.geometry.centerline), desired_count, endpoint=False, dtype=np.int32)
            for index in fallback.tolist():
                if index not in selected:
                    selected.append(index)

        selected = sorted(set(selected), key=lambda item: float(self.geometry.cumulative_lengths[item]))
        cameras: list[TracksideCamera] = []
        for index in selected:
            point = self.geometry.centerline[index]
            tangent = self.geometry.tangents[index]
            normal = self.geometry.normals[index]
            turn = _cross_2d(self.geometry.tangents[index - 1], self.geometry.tangents[(index + 1) % len(self.geometry.tangents)])
            side = -1.0 if turn > 0.0 else 1.0
            if abs(turn) <= 1e-4:
                side = 1.0 if index % 2 == 0 else -1.0
            base_distance = self.geometry.settings.half_width + 5.8
            lookat = np.array([point[0], point[1], 0.18], dtype=np.float64)
            eye_xy = point + normal * (side * base_distance) - tangent * 2.6
            direction = lookat[:2] - eye_xy
            azimuth = math.degrees(math.atan2(float(direction[1]), float(direction[0]))) - 90.0
            distance = _clip(float(np.linalg.norm(direction)) + 1.4, 6.8, 14.5)
            elevation = -18.0 if abs(turn) > 0.16 else -15.0
            lookat_z = 0.18
            if self.advanced_world is not None:
                surface = self.advanced_world.sample_surface_at_progress(float(self.geometry.cumulative_lengths[index]))
                lookat_z = surface.height + 0.22
            cameras.append(
                TracksideCamera(
                    progress=float(self.geometry.cumulative_lengths[index] / max(1e-6, self.geometry.total_length)),
                    lookat=np.array([point[0], point[1], lookat_z], dtype=np.float64),
                    azimuth=azimuth,
                    elevation=elevation,
                    distance=distance,
                )
            )
        return cameras

    def _nearest_trackside_camera_index(
        self,
        progress: float,
        direction: int = 1,
        *,
        allow_current: bool = False,
    ) -> int:
        if not self.trackside_cameras:
            return 0
        best_index = 0
        best_delta = float("inf")
        for index, camera in enumerate(self.trackside_cameras):
            delta = _progress_arc_distance(progress, camera.progress, direction)
            if not allow_current and delta <= 1e-5:
                continue
            if delta < best_delta:
                best_index = index
                best_delta = delta
        return best_index

    def _nearest_upcoming_trackside_camera_index(self) -> int:
        vehicle = self._focused_vehicle()
        if vehicle is None:
            return self.trackside_camera_index % max(1, len(self.trackside_cameras))
        return self._nearest_trackside_camera_index(vehicle.raw_progress % 1.0, 1)

    def _step_trackside_relative(self, direction: int) -> None:
        if not self.trackside_cameras:
            self.camera_mode = "overview"
            return
        direction = 1 if direction >= 0 else -1
        focused = self._focused_vehicle()
        if self.camera_mode != "trackside":
            if focused is None:
                self.camera_mode = "overview"
                return
            self.aerial_view = False
            self.trackside_anchor_vehicle = focused.id
            self.trackside_camera_index = self._nearest_trackside_camera_index(focused.raw_progress % 1.0, direction)
            self.camera_mode = "trackside"
            return

        next_index = (self.trackside_camera_index + direction) % len(self.trackside_cameras)
        anchor_id = self.trackside_anchor_vehicle
        if anchor_id is not None and 0 <= anchor_id < len(self.vehicles):
            driver_progress = self.vehicles[anchor_id].raw_progress % 1.0
            current_progress = self.trackside_cameras[self.trackside_camera_index].progress
            next_progress = self.trackside_cameras[next_index].progress
            to_driver = _progress_arc_distance(current_progress, driver_progress, direction)
            to_next = _progress_arc_distance(current_progress, next_progress, direction)
            if 1e-5 < to_driver <= to_next + 1e-5:
                self._set_driver_focus(anchor_id)
                return
        self.aerial_view = False
        self.trackside_camera_index = next_index
        self.camera_mode = "trackside"

    def _cycle_trackside_view(self) -> None:
        if not self.trackside_cameras:
            self.camera_mode = "overview"
            return
        focused = self._focused_vehicle()
        if self.camera_mode != "trackside":
            if focused is not None:
                self.trackside_anchor_vehicle = focused.id
                self.trackside_camera_index = self._nearest_trackside_camera_index(focused.raw_progress % 1.0, 1)
            self.aerial_view = False
            self.camera_mode = "trackside"
            return
        self.aerial_view = False
        self.trackside_camera_index = (self.trackside_camera_index + 1) % len(self.trackside_cameras)

    def _watch_vehicle(self, vehicle_id: int) -> None:
        if not self.vehicles:
            self.watching = None
            return
        self.watching = vehicle_id % len(self.vehicles)
        self.trackside_anchor_vehicle = self.watching
        self.camera_mode = "follow"
        self.lock_camera = True
        self.camera_yaw_offset = 0.0
        self.camera_pitch_offset = 0.0
        self.camera_distance = _clip(self.camera_distance, 6.8, 8.5)

    def build_results(self) -> dict:
        rows = []
        for place, vehicle in enumerate(self._standings(), start=1):
            rows.append(
                {
                    "place": place,
                    "name": vehicle.name,
                    "driver_path": str(vehicle.driver_path),
                    "finished": vehicle.finished,
                    "finish_time": None if vehicle.finish_time is None else round(vehicle.finish_time, 4),
                    "laps": vehicle.laps,
                    "lap_times": [round(value, 4) for value in vehicle.lap_times],
                    "best_lap_time": None if self._best_lap_time(vehicle) is None else round(self._best_lap_time(vehicle), 4),
                    "completion_percent": round(vehicle.completion, 4),
                    "absolute_completion_percent": round(vehicle.absolute_completion, 4),
                    "peak_speed": round(vehicle.peak_speed, 4),
                    "wall_contacts": vehicle.wall_contacts,
                    "car_contacts": vehicle.car_contacts,
                    "total_contacts": self._total_contacts(vehicle),
                    "mean_center_error": None if self._mean_center_error(vehicle) is None else round(self._mean_center_error(vehicle), 4),
                    "consistency_spread": None if self._consistency_spread(vehicle) is None else round(self._consistency_spread(vehicle), 4),
                    "driver_calls": vehicle.driver_call_count,
                    "mean_driver_ms": round(1000.0 * vehicle.driver_total_time / max(1, vehicle.driver_call_count), 4),
                    "max_driver_ms": round(vehicle.driver_max_time * 1000.0, 4),
                    "error_count": vehicle.error_count,
                    "last_error": vehicle.last_error,
                }
            )
        return {
            "runtime": "AIGPV2",
            "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "track": self.track_settings.name,
            "world_mode": self.config.world_mode,
            "cars_path": "<inline>" if self.config.cars_data is not None else self.config.cars_path,
            "race_mode": self.config.race_mode,
            "sim_time": round(self.sim_time, 4),
            "steps": self.step_count,
            "lap_target": self.config.lap_target,
            "physics_hz": self.config.physics_hz,
            "standings": rows,
        }

    def save_results(self, *, json_path: str | None = None, csv_path: str | None = None) -> None:
        results = self.build_results()
        if json_path:
            path = Path(json_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(results, indent=2), encoding="utf-8")
        if csv_path:
            path = Path(csv_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(
                    handle,
                    fieldnames=[
                        "place",
                        "name",
                        "driver_path",
                        "finished",
                        "finish_time",
                        "laps",
                        "best_lap_time",
                        "completion_percent",
                        "absolute_completion_percent",
                        "peak_speed",
                        "wall_contacts",
                        "car_contacts",
                        "total_contacts",
                        "mean_center_error",
                        "consistency_spread",
                        "driver_calls",
                        "mean_driver_ms",
                        "max_driver_ms",
                        "error_count",
                        "last_error",
                    ],
                )
                writer.writeheader()
                for row in results["standings"]:
                    writer.writerow({key: row.get(key) for key in writer.fieldnames})

    def _focused_vehicle(self) -> VehicleRuntime | None:
        if self.watching is None or not self.vehicles:
            return None
        return self.vehicles[self.watching % len(self.vehicles)]

    def _set_driver_focus(self, vehicle_id: int) -> None:
        self.aerial_view = False
        self._watch_vehicle(vehicle_id)

    def _stop_condition(self) -> str | None:
        if not self.vehicles:
            return "no vehicles loaded"
        if self.config.max_steps and self.step_count >= self.config.max_steps:
            return "step limit reached"
        if self.config.max_time and self.sim_time >= self.config.max_time:
            return "time limit reached"
        if self.vehicles and all(vehicle.finished for vehicle in self.vehicles):
            return "race finished"
        return None

    def _focus_next(self, direction: int = 1) -> None:
        if not self.vehicles:
            self.watching = None
            return
        if self.watching is None:
            self._set_driver_focus(0)
        else:
            self._set_driver_focus((self.watching + direction) % len(self.vehicles))

    def _toggle_fullscreen(self) -> None:
        assert self.window is not None
        if not self.fullscreen:
            self.saved_window_size = self.window.get_size()
            self.window = pygame.display.set_mode((0, 0), pygame.FULLSCREEN | pygame.DOUBLEBUF)
            self.fullscreen = True
            if not self.settings_detached:
                self.settings_visible = False
        else:
            self.window = pygame.display.set_mode(self.saved_window_size, pygame.RESIZABLE | pygame.DOUBLEBUF)
            self.fullscreen = False
        self.window_size = self.window.get_size()
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
            self.renderer_size = None

    def _set_settings_visible(self, visible: bool) -> None:
        if not visible and self.settings_detached:
            self.settings_detached = False
            self._close_controls_window()
        self.settings_visible = visible
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
            self.renderer_size = None

    def _set_settings_detached(self, detached: bool) -> None:
        if detached:
            if not self._open_controls_window():
                return
            self.settings_detached = True
            self.settings_visible = True
            self.panel_rect = None
        else:
            self.settings_detached = False
            self._close_controls_window()
            self.settings_visible = True
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
            self.renderer_size = None

    def _open_controls_window(self) -> bool:
        if SDLWindow is None or SDLRenderer is None or SDLTexture is None:
            self._status("Detached controls require pygame SDL2 window support.")
            return False
        if self.controls_window is not None and self.controls_renderer is not None:
            return True
        try:
            height = int(_clip(self.window_size[1], 640, 1000))
            self.controls_window_size = (460, height)
            self.controls_window = SDLWindow("Formula Trinity GP Controls", size=self.controls_window_size, resizable=True)
            self.controls_renderer = SDLRenderer(self.controls_window)
            self.controls_window_id = int(self.controls_window.id)
        except Exception as exc:
            self.controls_window = None
            self.controls_renderer = None
            self.controls_window_id = None
            self._status(f"Detached controls unavailable: {exc}")
            return False
        return True

    def _close_controls_window(self) -> None:
        self.controls_renderer = None
        if self.controls_window is not None:
            try:
                self.controls_window.destroy()
            except Exception:
                pass
        self.controls_window = None
        self.controls_window_id = None
        self.controls_ui_actions.clear()

    def _cycle_track(self, direction: int) -> None:
        if not self.available_tracks:
            return
        current = self.edit_track_settings.name
        try:
            index = self.available_tracks.index(current)
        except ValueError:
            index = 0
        next_name = self.available_tracks[(index + direction) % len(self.available_tracks)]
        self.edit_track_settings = self._default_track_settings(next_name)
        self.pending_track_rebuild = True

    def _apply_track_changes(self) -> None:
        self.track_settings = self.edit_track_settings.copy()
        self.config.track = self.track_settings.name
        self._stage(reset_progress=True)

    def _reset_track_defaults(self) -> None:
        self.edit_track_settings = self._default_track_settings(self.edit_track_settings.name)
        self.pending_track_rebuild = True

    def _reset_camera_pose(self) -> None:
        self.camera_distance = 18.0
        self.camera_azimuth = 36.0
        self.camera_elevation = -28.0
        self.camera_yaw_offset = 0.0
        self.camera_pitch_offset = 0.0
        self.aerial_view = False

    def _register_button(self, rect: pygame.Rect, action: Callable[[], None]) -> None:
        actions = self.controls_ui_actions if self._ui_action_target == "controls" else self.ui_actions
        actions.append({"type": "button", "rect": rect.copy(), "action": action})

    def _register_slider(self, rect: pygame.Rect, setter: Callable[[float], None], minimum: float, maximum: float) -> None:
        actions = self.controls_ui_actions if self._ui_action_target == "controls" else self.ui_actions
        actions.append(
            {
                "type": "slider",
                "rect": rect.copy(),
                "setter": setter,
                "minimum": minimum,
                "maximum": maximum,
            }
        )

    def _dispatch_click(self, position: tuple[int, int], *, target: str = "main") -> bool:
        actions = self.controls_ui_actions if target == "controls" else self.ui_actions
        for item in reversed(actions):
            rect: pygame.Rect = item["rect"]
            if not rect.collidepoint(position):
                continue
            if item["type"] == "button":
                item["action"]()
                return True
            if item["type"] == "slider":
                self.active_slider = item
                self.active_slider_window = target
                self._update_slider(position[0], item)
                return True
        return False

    def _update_slider(self, mouse_x: int, slider: dict) -> None:
        rect: pygame.Rect = slider["rect"]
        t = _clip((mouse_x - rect.left) / max(1, rect.width), 0.0, 1.0)
        value = slider["minimum"] + (slider["maximum"] - slider["minimum"]) * t
        slider["setter"](value)

    def _ensure_pygame(self) -> None:
        pygame.init()
        _TEXT_CACHE.clear()
        _ALPHA_SURFACE_CACHE.clear()
        pygame.display.set_caption(APP_TITLE)
        self.window = pygame.display.set_mode(self.window_size, pygame.RESIZABLE | pygame.DOUBLEBUF)
        self.window_size = self.window.get_size()
        self.font_small = pygame.font.SysFont("Segoe UI", 14)
        self.font_body = pygame.font.SysFont("Segoe UI", 18)
        self.font_micro = pygame.font.SysFont("Segoe UI", 12)
        self.font_label = pygame.font.SysFont("Segoe UI Semibold", 18)
        self.font_title = pygame.font.SysFont("Segoe UI Semibold", 28)
        self.font_large = pygame.font.SysFont("Segoe UI Semibold", 46)
        self.font_stat = pygame.font.SysFont("Segoe UI Semibold", 28)

    def _get_track_preview(self, name: str) -> pygame.Surface | None:
        if name in self.preview_cache:
            return self.preview_cache[name]
        path = self._active_advanced_preview_path(name) if self._is_advanced_mode() else None
        if path is None or not path.is_file():
            if self._is_advanced_mode():
                spec = self._advanced_track_spec(name)
                path = self.template_dir / f"{spec.base_track}.png" if spec is not None else None

        if path is None or not path.is_file():
            path = self.template_dir / f"{name}.png"
        if not path.is_file():
            return None
        try:
            surface = pygame.image.load(str(path)).convert()
        except Exception:
            return None
        try:
            array = pygame.surfarray.array3d(surface)
            mask = np.any(array > 8, axis=2)
            coords = np.argwhere(mask)
            if coords.size:
                x0, y0 = coords.min(axis=0)
                x1, y1 = coords.max(axis=0)
                crop = pygame.Rect(int(x0), int(y0), int(x1 - x0 + 1), int(y1 - y0 + 1))
                crop.inflate_ip(24, 24)
                crop.clamp_ip(surface.get_rect())
                surface = surface.subsurface(crop).copy()
        except Exception:
            pass
        self.preview_cache[name] = surface
        return surface

    def _get_fitted_track_preview(self, name: str, size: tuple[int, int]) -> pygame.Surface | None:
        preview = self._get_track_preview(name)
        if preview is None:
            return None
        key = (name, int(size[0]), int(size[1]))
        fitted = self.preview_fit_cache.get(key)
        if fitted is None:
            fitted = pygame.transform.smoothscale(preview, size)
            self.preview_fit_cache[key] = fitted
        return fitted

    def _handle_key(self, key: int) -> None:
        if key == pygame.K_SPACE:
            self._toggle_pause_or_start()
        elif key == pygame.K_r:
            self.reload_all_drivers()
        elif key == pygame.K_e:
            self._position_vehicles(reset_progress=True)
        elif key == pygame.K_n:
            self._focus_next(-1)
        elif key == pygame.K_p:
            self._focus_next(1)
        elif key == pygame.K_LEFT:
            if not self.manual_control:
                self._focus_next(-1)
        elif key == pygame.K_RIGHT:
            if not self.manual_control:
                self._focus_next(1)
        elif key == pygame.K_UP:
            if not self.manual_control:
                self._step_trackside_relative(1)
        elif key == pygame.K_DOWN:
            if not self.manual_control:
                self._step_trackside_relative(-1)
        elif key == pygame.K_l:
            self.aerial_view = False
            self.camera_mode = "overview"
            self.watching = None if self.watching is not None else 0
        elif key == pygame.K_c:
            self.lock_camera = not self.lock_camera
        elif key == pygame.K_m:
            self.manual_control = not self.manual_control
        elif key == pygame.K_RETURN:
            self._toggle_aerial_view()
        elif key == pygame.K_TAB:
            self._set_settings_visible(not self.settings_visible)
        elif key == pygame.K_F11:
            self._toggle_fullscreen()
        elif key == pygame.K_g:
            self.show_lidar = not self.show_lidar
        elif key == pygame.K_v:
            self._cycle_trackside_view()
        elif key == pygame.K_f:
            self._toggle_fullscreen()

    def _event_window_id(self, event: pygame.event.Event) -> int | None:
        window_id = getattr(event, "window", None)
        if hasattr(window_id, "id"):
            return int(window_id.id)
        if isinstance(window_id, int):
            return window_id
        legacy_id = getattr(event, "windowID", None)
        if isinstance(legacy_id, int):
            return legacy_id
        return None

    def _is_controls_event(self, event: pygame.event.Event) -> bool:
        return (
            self.settings_detached
            and self.controls_window_id is not None
            and self._event_window_id(event) == self.controls_window_id
        )

    def _handle_controls_event(self, event: pygame.event.Event) -> bool:
        if not self._is_controls_event(event):
            return False
        if event.type == pygame.WINDOWCLOSE:
            self._set_settings_detached(False)
            return True
        if event.type in {pygame.WINDOWRESIZED, pygame.WINDOWSIZECHANGED}:
            if self.controls_window is not None:
                try:
                    self.controls_window_size = tuple(int(value) for value in self.controls_window.size)
                except Exception:
                    self.controls_window_size = (max(360, int(getattr(event, "x", 460))), max(520, int(getattr(event, "y", 720))))
            return True
        if event.type == pygame.KEYDOWN:
            if self._handle_active_text_input(event):
                return True
            self._handle_key(event.key)
            return True
        if event.type == pygame.MOUSEBUTTONDOWN:
            position = tuple(int(value) for value in event.pos)
            self.controls_mouse_position = position
            if event.button == 1:
                self.controls_mouse_primary_down = True
                self._dispatch_click(position, target="controls")
                return True
            if event.button in {4, 5}:
                self._handle_settings_scroll(event.button, position)
                return True
        if event.type == pygame.MOUSEBUTTONUP:
            position = tuple(int(value) for value in event.pos)
            self.controls_mouse_position = position
            if event.button == 1:
                self.controls_mouse_primary_down = False
                if self.active_slider_window == "controls":
                    self.active_slider = None
                return True
        if event.type == pygame.MOUSEMOTION:
            position = tuple(int(value) for value in event.pos)
            self.controls_mouse_position = position
            if self.active_slider is not None and self.active_slider_window == "controls":
                self._update_slider(position[0], self.active_slider)
            return True
        if event.type == pygame.MOUSEWHEEL:
            button = 4 if event.y > 0 else 5
            self._handle_settings_scroll(button, self.controls_mouse_position)
            return True
        return True

    def _handle_events(self) -> None:
        assert self.window is not None
        for event in pygame.event.get():
            if self._handle_controls_event(event):
                continue
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.VIDEORESIZE and not self.fullscreen:
                self.window = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE | pygame.DOUBLEBUF)
                self.window_size = self.window.get_size()
                if self.renderer is not None:
                    self.renderer.close()
                    self.renderer = None
                    self.renderer_size = None
            elif event.type == pygame.KEYDOWN:
                if self._handle_active_text_input(event):
                    continue
                self._handle_key(event.key)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                self.main_mouse_position = tuple(int(value) for value in event.pos)
                if event.button == 1:
                    self.mouse_primary_down = True
                    if self._dispatch_click(event.pos, target="main"):
                        continue
                    if self.render_rect.collidepoint(event.pos):
                        self.dragging_camera = True
                elif event.button in {4, 5}:
                    if self._handle_settings_scroll(event.button, event.pos):
                        continue
                    if self.render_rect.collidepoint(event.pos):
                        delta = -0.6 if event.button == 4 else 0.6
                        self.camera_distance = _clip(self.camera_distance + delta, 2.0, 60.0)
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse_primary_down = False
                    if self.active_slider_window == "main":
                        self.active_slider = None
                    self.dragging_camera = False
            elif event.type == pygame.MOUSEMOTION:
                self.main_mouse_position = tuple(int(value) for value in event.pos)
                if self.active_slider is not None and self.active_slider_window == "main":
                    self._update_slider(event.pos[0], self.active_slider)
                elif self.dragging_camera and self.render_rect.collidepoint(event.pos):
                    dx, dy = event.rel
                    if self.camera_mode in {"follow", "chase"}:
                        self.camera_yaw_offset -= dx * 0.26
                        self.camera_pitch_offset = _clip(self.camera_pitch_offset - dy * 0.18, -28.0, 28.0)
                    else:
                        self.camera_azimuth -= dx * 0.26
                        self.camera_elevation = _clip(self.camera_elevation - dy * 0.18, -82.0, -8.0)
            elif event.type == pygame.MOUSEWHEEL:
                mouse_pos = pygame.mouse.get_pos()
                if self.render_rect.collidepoint(mouse_pos):
                    self.camera_distance = _clip(self.camera_distance - event.y * 0.5, 2.0, 60.0)

    def _update_manual_controls(self, dt: float) -> None:
        if not self.manual_control:
            self.manual_speed *= max(0.0, 1.0 - 6.0 * dt)
            self.manual_steer *= max(0.0, 1.0 - 8.0 * dt)
            return
        keys = pygame.key.get_pressed()
        target_speed = 0.0
        target_steer = 0.0
        if keys[pygame.K_w]:
            target_speed += self.config.manual_control_speed
        if keys[pygame.K_s]:
            target_speed -= self.config.manual_control_speed * 0.6
        if keys[pygame.K_a]:
            target_steer += 1.0
        if keys[pygame.K_d]:
            target_steer -= 1.0
        self.manual_speed = _lerp(self.manual_speed, target_speed, min(1.0, dt * 10.0))
        self.manual_steer = _lerp(self.manual_steer, target_steer, min(1.0, dt * 12.0))

    def _update_camera(self) -> None:
        assert self.geometry is not None
        vehicle = self._focused_vehicle()
        self.camera.type = mujoco.mjtCamera.mjCAMERA_FREE
        if self.aerial_view:
            bounds = np.vstack([self.geometry.track_inner, self.geometry.track_outer])
            center = self.geometry.center.astype(np.float64)
            relative = bounds.astype(np.float64) - center[None, :]
            yaw = math.radians(self.camera_azimuth)
            rot_x = relative[:, 0] * math.cos(yaw) + relative[:, 1] * math.sin(yaw)
            rot_y = -relative[:, 0] * math.sin(yaw) + relative[:, 1] * math.cos(yaw)
            half_width = max(8.0, float(np.max(np.abs(rot_x))) + 2.2)
            half_height = max(8.0, float(np.max(np.abs(rot_y))) + 2.2)
            aspect = self.render_rect.width / max(1, self.render_rect.height)
            fovy = math.radians(float(max(12.0, self.model.vis.global_.fovy)))
            tan_half = max(1e-5, math.tan(fovy * 0.5))
            distance = max(half_height / tan_half, half_width / max(1e-5, aspect * tan_half)) * 1.12
            center_z = 0.0
            if self.advanced_world is not None:
                center_z = float(np.mean(self.advanced_world.road_centerline_3d[:, 2]))
            self.camera.lookat[:] = np.array([self.geometry.center[0], self.geometry.center[1], center_z], dtype=np.float64)
            self.camera.azimuth = self.camera_azimuth
            self.camera.elevation = -89.0
            self.camera.distance = max(distance, 24.0)
            return
        if self.camera_mode == "trackside" and self.trackside_cameras:
            trackside = self.trackside_cameras[self.trackside_camera_index % len(self.trackside_cameras)]
            self.camera.lookat[:] = trackside.lookat
            self.camera.azimuth = trackside.azimuth
            self.camera.elevation = trackside.elevation
            self.camera.distance = trackside.distance
            return
        if vehicle is None or self.camera_mode == "overview":
            center_z = 0.0
            if self.advanced_world is not None:
                center_z = float(np.mean(self.advanced_world.road_centerline_3d[:, 2]))
            self.camera.lookat[:] = np.array([self.geometry.center[0], self.geometry.center[1], center_z], dtype=np.float64)
            self.camera.azimuth = self.camera_azimuth
            self.camera.elevation = self.camera_elevation
            self.camera.distance = max(self.camera_distance, 10.0)
            return

        forward = np.array([math.cos(vehicle.yaw), math.sin(vehicle.yaw), 0.0], dtype=np.float64)
        if self.camera_mode == "chase":
            self.camera.lookat[:] = np.array([vehicle.position[0], vehicle.position[1], vehicle.surface_height + 0.24], dtype=np.float64) + forward * 0.85
            self.camera.azimuth = math.degrees(vehicle.yaw) - 90.0 + self.camera_yaw_offset
            self.camera.elevation = _clip(-16.0 + self.camera_pitch_offset, -34.0, 4.0)
            self.camera.distance = _clip(max(5.2, self.camera_distance * 0.82), 4.8, 16.0)
            return

        self.camera.lookat[:] = np.array([vehicle.position[0], vehicle.position[1], vehicle.surface_height + 0.18], dtype=np.float64) + forward * 0.20
        if self.lock_camera:
            self.camera.azimuth = math.degrees(vehicle.yaw) - 90.0 + self.camera_yaw_offset
        else:
            self.camera.azimuth = self.camera_azimuth + self.camera_yaw_offset
        self.camera.elevation = _clip(self.camera_elevation + self.camera_pitch_offset, -62.0, -8.0)
        self.camera.distance = self.camera_distance

    def _inject_scene_lines(self) -> None:
        assert self.renderer is not None and self.geometry is not None
        scene = self.renderer.scene
        rgba_line = np.array([0.45, 0.72, 1.0, 0.95], dtype=np.float32)
        rgba_lidar = np.array([1.0, 0.98, 0.62, 0.95], dtype=np.float32)

        if self.show_racing_line:
            step = max(1, len(self.geometry.centerline) // 120)
            for index in range(0, len(self.geometry.centerline), step):
                if scene.ngeom >= scene.maxgeom:
                    break
                a = self.geometry.centerline[index]
                b = self.geometry.centerline[(index + step) % len(self.geometry.centerline)]
                a_z = 0.055
                b_z = 0.055
                if self.advanced_world is not None:
                    a_z = float(self.advanced_world.road_centerline_3d[index, 2]) + 0.055
                    b_z = float(self.advanced_world.road_centerline_3d[(index + step) % len(self.geometry.centerline), 2]) + 0.055
                geom = scene.geoms[scene.ngeom]
                mujoco.mjv_initGeom(geom, mujoco.mjtGeom.mjGEOM_LINE, self.zero3, self.zero3, self.identity_mat, rgba_line)
                mujoco.mjv_connector(
                    geom,
                    mujoco.mjtGeom.mjGEOM_LINE,
                    1.0,
                    np.array([a[0], a[1], a_z], dtype=np.float64),
                    np.array([b[0], b[1], b_z], dtype=np.float64),
                )
                geom.dataid = -1
                scene.ngeom += 1

        vehicle = self._focused_vehicle()
        if not self.show_lidar or vehicle is None:
            return
        origin = np.array(
            [
                vehicle.position[0] + math.cos(vehicle.yaw) * 0.02,
                vehicle.position[1] + math.sin(vehicle.yaw) * 0.02,
                vehicle.surface_height + 0.14,
            ],
            dtype=np.float64,
        )
        display_ranges = vehicle.last_legacy_ranges if self.advanced_world is not None else vehicle.last_ranges
        count = len(display_ranges)
        if count == 0:
            return
        for index, distance in enumerate(display_ranges):
            if scene.ngeom >= scene.maxgeom:
                break
            local_angle = (index / count) * (2.0 * math.pi) - math.pi
            angle = vehicle.yaw + local_angle
            reach = float(_clip(float(distance), 0.0, self.config.lidar_max_distance))
            end = np.array(
                [
                    origin[0] + math.cos(angle) * reach,
                    origin[1] + math.sin(angle) * reach,
                    origin[2],
                ],
                dtype=np.float64,
            )
            geom = scene.geoms[scene.ngeom]
            mujoco.mjv_initGeom(geom, mujoco.mjtGeom.mjGEOM_LINE, self.zero3, self.zero3, self.identity_mat, rgba_lidar)
            mujoco.mjv_connector(geom, mujoco.mjtGeom.mjGEOM_LINE, 1.0, origin, end)
            geom.dataid = -1
            scene.ngeom += 1

    def _ensure_renderer(self, size: tuple[int, int]) -> None:
        max_width = int(max(1024, self.model.vis.global_.offwidth))
        max_height = int(max(768, self.model.vis.global_.offheight))
        width = min(max_width - 8, max(320, int(size[0] * self.render_scale)))
        height = min(max_height - 8, max(240, int(size[1] * self.render_scale)))
        if self.renderer is not None and self.renderer_size == (width, height):
            return
        if self.renderer is not None:
            self.renderer.close()
        self.renderer = mujoco.Renderer(self.model, width=width, height=height)
        self.renderer_size = (width, height)
        self.scene_surface_cache = None
        self.scene_cache_key = None

    def _scene_draw_key(self, rect: pygame.Rect) -> tuple:
        return (
            rect.size,
            round(self.render_scale, 3),
            self.step_count,
            self.camera_mode,
            bool(self.aerial_view),
            self.watching,
            self.trackside_camera_index,
            bool(self.show_lidar),
            bool(self.show_racing_line),
            bool(self.lock_camera),
            round(self.camera_distance, 3),
            round(self.camera_azimuth, 3),
            round(self.camera_elevation, 3),
            round(self.camera_yaw_offset, 3),
            round(self.camera_pitch_offset, 3),
        )

    def _render_scene(self, target: pygame.Surface, rect: pygame.Rect) -> None:
        self._ensure_renderer((rect.width, rect.height))
        cache_key = self._scene_draw_key(rect)
        if self.scene_surface_cache is not None and self.scene_cache_key == cache_key:
            target.blit(self.scene_surface_cache, rect)
            _rounded(target, rect, self.palette["track_border"], radius=26, width=2)
            return
        self._update_camera()
        self._refresh_camera_cache()
        assert self.renderer is not None
        self.renderer.update_scene(self.data, self.camera, self.scene_option)
        self._inject_scene_lines()
        frame = self.renderer.render()
        if not frame.flags["C_CONTIGUOUS"]:
            frame = np.ascontiguousarray(frame)
        surface = pygame.image.frombuffer(frame, (frame.shape[1], frame.shape[0]), "RGB")
        if surface.get_size() != rect.size:
            surface = pygame.transform.scale(surface, rect.size)
        if self.paused or self.stop_reason is not None or self.awaiting_race_start:
            cached_surface = surface.copy()
            self.scene_surface_cache = cached_surface
            self.scene_cache_key = cache_key
            target.blit(cached_surface, rect)
        else:
            self.scene_surface_cache = None
            self.scene_cache_key = None
            target.blit(surface, rect)
        _rounded(target, rect, self.palette["track_border"], radius=26, width=2)

    def _draw_text(self, surface: pygame.Surface, font: pygame.font.Font, text: str, position: tuple[int, int], color: tuple[int, int, int]) -> None:
        surface.blit(_text_surface(font, text, color), position)

    def _draw_fitted_text(
        self,
        surface: pygame.Surface,
        font: pygame.font.Font,
        text: str,
        rect: pygame.Rect,
        color: tuple[int, int, int],
        *,
        align: str = "left",
    ) -> None:
        shown = _fit_text(font, text, rect.width)
        if not shown:
            return
        label_surface = _text_surface(font, shown, color)
        if align == "center":
            x = rect.centerx - label_surface.get_width() // 2
        elif align == "right":
            x = rect.right - label_surface.get_width()
        else:
            x = rect.x
        surface.blit(label_surface, (x, rect.y))

    def _draw_wrapped_text(
        self,
        surface: pygame.Surface,
        font: pygame.font.Font,
        text: str,
        rect: pygame.Rect,
        color: tuple[int, int, int],
        *,
        max_lines: int | None = None,
        line_height: int | None = None,
        align: str = "left",
    ) -> int:
        lines = _wrap_text_lines(font, text, rect.width, max_lines=max_lines)
        if not lines:
            return rect.y
        y = rect.y
        spacing = font.get_linesize() if line_height is None else line_height
        for line in lines:
            self._draw_fitted_text(
                surface,
                font,
                line,
                pygame.Rect(rect.x, y, rect.width, spacing),
                color,
                align=align,
            )
            y += spacing
        return y

    def _draw_scaled_text(
        self,
        surface: pygame.Surface,
        fonts: list[pygame.font.Font] | tuple[pygame.font.Font, ...],
        text: str,
        rect: pygame.Rect,
        color: tuple[int, int, int],
        *,
        align: str = "left",
    ) -> None:
        font, shown = _select_fitting_font(fonts, text, rect.width)
        if not shown:
            return
        label_surface = _text_surface(font, shown, color)
        if align == "center":
            x = rect.centerx - label_surface.get_width() // 2
        elif align == "right":
            x = rect.right - label_surface.get_width()
        else:
            x = rect.x
        y = rect.y + (rect.height - label_surface.get_height()) // 2
        surface.blit(label_surface, (x, y))

    def _interactive_state(self, rect: pygame.Rect) -> tuple[bool, bool]:
        hovered = rect.collidepoint(self.mouse_position)
        pressed = hovered and self.mouse_primary_down
        return hovered, pressed

    def _interactive_fill(self, rect: pygame.Rect, base: tuple[int, int, int]) -> tuple[int, int, int]:
        hovered, pressed = self._interactive_state(rect)
        if pressed:
            return _mix_color(base, (0, 0, 0), 0.24)
        if hovered:
            return _mix_color(base, (0, 0, 0), 0.12)
        return base

    def _interactive_outline(self, rect: pygame.Rect, base: tuple[int, int, int]) -> tuple[int, int, int]:
        hovered, pressed = self._interactive_state(rect)
        if pressed:
            return _mix_color(base, (255, 255, 255), 0.14)
        if hovered:
            return _mix_color(base, self.palette["accent_alt"], 0.16)
        return base

    def _draw_chevron(self, surface: pygame.Surface, rect: pygame.Rect, direction: int, color: tuple[int, int, int]) -> None:
        mid_x = rect.centerx + (2 if direction > 0 else -2)
        points = [
            (mid_x - 6 * direction, rect.centery - 8),
            (mid_x + 2 * direction, rect.centery),
            (mid_x - 6 * direction, rect.centery + 8),
        ]
        pygame.draw.lines(surface, color, False, points, width=3)

    def _settings_handle_rect(self) -> pygame.Rect:
        width = 30
        height = 60
        y = self.render_rect.y + 18
        if self.settings_visible and self.panel_rect is not None:
            # Keep the handle fully visible outside the open panel edge.
            x = self.panel_rect.x - width + 1
        else:
            anchor_x = self.panel_rect.x if self.panel_rect is not None else self.render_rect.right
            x = anchor_x - 16
        return pygame.Rect(x, y, width, height)

    def _draw_settings_handle(self, surface: pygame.Surface) -> None:
        handle_rect = self._settings_handle_rect()
        fill_base = self.palette["panel"] if self.settings_visible else self.palette["card"]
        fill = self._interactive_fill(handle_rect, fill_base)
        outline = self._interactive_outline(handle_rect, self.palette["panel_edge"])
        _rounded(surface, handle_rect, fill, radius=14)
        _rounded(surface, handle_rect, outline, radius=14, width=1)
        line_color = self.palette["text"] if self.settings_visible else self.palette["muted"]
        for offset in (-10, 0, 10):
            y = handle_rect.centery + offset
            pygame.draw.line(surface, line_color, (handle_rect.x + 8, y), (handle_rect.right - 8, y), width=2)
        self._register_button(handle_rect, lambda: self._set_settings_visible(not self.settings_visible))

    def _draw_fullscreen_icon(self, surface: pygame.Surface, rect: pygame.Rect, color: tuple[int, int, int]) -> None:
        pad = 9
        short = 7
        pygame.draw.line(surface, color, (rect.x + pad, rect.y + pad + short), (rect.x + pad, rect.y + pad), width=2)
        pygame.draw.line(surface, color, (rect.x + pad, rect.y + pad), (rect.x + pad + short, rect.y + pad), width=2)
        pygame.draw.line(surface, color, (rect.right - pad - short, rect.y + pad), (rect.right - pad, rect.y + pad), width=2)
        pygame.draw.line(surface, color, (rect.right - pad, rect.y + pad), (rect.right - pad, rect.y + pad + short), width=2)
        pygame.draw.line(surface, color, (rect.x + pad, rect.bottom - pad - short), (rect.x + pad, rect.bottom - pad), width=2)
        pygame.draw.line(surface, color, (rect.x + pad, rect.bottom - pad), (rect.x + pad + short, rect.bottom - pad), width=2)
        pygame.draw.line(surface, color, (rect.right - pad - short, rect.bottom - pad), (rect.right - pad, rect.bottom - pad), width=2)
        pygame.draw.line(surface, color, (rect.right - pad, rect.bottom - pad - short), (rect.right - pad, rect.bottom - pad), width=2)

    def _standings_rect(self) -> pygame.Rect:
        return pygame.Rect(self.render_rect.right - 270, self.render_rect.bottom - 182, 252, 164)

    def _draw_fullscreen_button(self, surface: pygame.Surface) -> None:
        standings_rect = self._standings_rect()
        rect = pygame.Rect(standings_rect.right - 42, standings_rect.y - 52, 38, 38)
        _rounded(surface, rect, self._interactive_fill(rect, self.palette["surface"]), radius=16)
        _rounded(surface, rect, self._interactive_outline(rect, self.palette["panel_edge"]), radius=16, width=1)
        self._draw_fullscreen_icon(surface, rect, self.palette["text"])
        self._register_button(rect, self._toggle_fullscreen)

    def _refresh_camera_cache(self) -> None:
        self.camera_frame_cache = None
        self.camera_projection_cache = None
        if self.data is None:
            return
        head = np.zeros(3, dtype=np.float64)
        forward = np.zeros(3, dtype=np.float64)
        up = np.zeros(3, dtype=np.float64)
        right = np.zeros(3, dtype=np.float64)
        mujoco.mjv_cameraFrame(head, forward, up, right, self.data, self.camera)
        self.camera_frame_cache = (head, forward, up, right)
        if self.model is None or self.render_rect.height <= 0:
            return
        aspect = self.render_rect.width / max(1, self.render_rect.height)
        fovy = math.radians(float(max(12.0, self.model.vis.global_.fovy)))
        self.camera_projection_cache = (aspect, math.tan(fovy * 0.5))

    def _camera_frame(self) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
        return self.camera_frame_cache

    def _project_world_point(self, point: np.ndarray) -> tuple[int, int] | None:
        if self.model is None or self.render_rect.width <= 0 or self.render_rect.height <= 0:
            return None
        frame = self._camera_frame()
        if frame is None or self.camera_projection_cache is None:
            return None
        head, forward, up, right = frame
        aspect, tan_half = self.camera_projection_cache

        relative = point.astype(np.float64) - head
        cam_x = float(np.dot(relative, right))
        cam_y = float(np.dot(relative, up))
        cam_z = float(np.dot(relative, forward))
        if cam_z <= 0.05:
            return None

        ndc_x = cam_x / max(1e-6, cam_z * tan_half * aspect)
        ndc_y = cam_y / max(1e-6, cam_z * tan_half)
        if abs(ndc_x) > 1.15 or abs(ndc_y) > 1.15:
            return None
        screen_x = int(self.render_rect.centerx + ndc_x * self.render_rect.width * 0.5)
        screen_y = int(self.render_rect.centery - ndc_y * self.render_rect.height * 0.5)
        return screen_x, screen_y

    def _vehicle_visible_for_tag(self, vehicle: VehicleRuntime) -> bool:
        if self.geometry is None:
            return False
        if self.aerial_view:
            return True
        frame = self._camera_frame()
        if frame is None:
            return False
        head, _forward, _up, _right = frame
        hit = self.geometry.first_wall_hit(
            head[:2].astype(np.float32),
            vehicle.position.astype(np.float32),
            hint_progress=self._absolute_track_progress(vehicle),
            search_radius=28,
        )
        if hit is None:
            return True
        hit_t, _point = hit
        anchor = self._vehicle_tag_anchor(vehicle)
        line_height = float(head[2] + (anchor[2] - head[2]) * hit_t)
        return line_height >= self.geometry.settings.wall_height + 0.05 or hit_t >= 0.97

    def _draw_driver_name_tags(self, surface: pygame.Surface) -> None:
        if not self.vehicles:
            return
        if not (self.aerial_view or self.camera_mode in {"overview", "trackside"} or self.camera.distance >= 11.0):
            return
        visible_rect = self.render_rect.inflate(-12, -12)
        halo_surface_focus = None
        halo_surface_other = None
        if self.aerial_view:
            halo_surface_focus = pygame.Surface((40, 40), pygame.SRCALPHA)
            halo_surface_other = pygame.Surface((40, 40), pygame.SRCALPHA)
            pygame.draw.circle(halo_surface_focus, (*self.palette["accent"], 110), (20, 20), 14)
            pygame.draw.circle(halo_surface_other, (255, 255, 255, 60), (20, 20), 14)
        for vehicle in self.vehicles:
            anchor = self._vehicle_tag_anchor(vehicle)
            projected = self._project_world_point(anchor)
            if projected is None:
                continue
            if not visible_rect.collidepoint(projected):
                continue
            if not self._vehicle_visible_for_tag(vehicle):
                continue
            if self.aerial_view:
                halo_surface = halo_surface_focus if self.watching == vehicle.id else halo_surface_other
                surface.blit(halo_surface, (projected[0] - 20, projected[1] - 20))
            shown = _fit_text(self.font_small, vehicle.name, 168)
            label = _text_surface(self.font_small, shown, self.palette["text"])
            label_rect = label.get_rect(midbottom=(projected[0], projected[1] - 8))
            backdrop = label_rect.inflate(14, 8)
            fill = (*self.palette["accent"], 134) if self.watching == vehicle.id else (10, 12, 15, 108)
            surface.blit(_alpha_surface(backdrop.size, fill), backdrop)
            pygame.draw.rect(surface, self.palette["panel_edge"], backdrop, width=1, border_radius=4)
            surface.blit(label, label_rect)

    def _draw_countdown_overlay(self, surface: pygame.Surface) -> None:
        if not self.countdown_active:
            return
        surface.blit(_alpha_surface(self.render_rect.size, (6, 8, 10, 38)), self.render_rect)

        elapsed = START_LIGHT_COUNT - self.countdown_remaining
        active_lights = max(1, min(START_LIGHT_COUNT, int(math.floor(elapsed + 1e-6)) + 1))
        light_radius = 16
        spacing = 18
        total_width = START_LIGHT_COUNT * light_radius * 2 + (START_LIGHT_COUNT - 1) * spacing
        start_x = self.render_rect.centerx - total_width // 2
        y = self.render_rect.y + 86
        for index in range(START_LIGHT_COUNT):
            color = (198, 38, 34) if index < active_lights else (54, 28, 28)
            center = (start_x + light_radius + index * (light_radius * 2 + spacing), y)
            pygame.draw.circle(surface, color, center, light_radius)
            pygame.draw.circle(surface, self.palette["panel_edge"], center, light_radius, width=2)

        title = "Race Start"
        subtitle = "Lights out on zero"
        self._draw_text(surface, self.font_label, title, (self.render_rect.centerx - 48, y + 34), self.palette["text"])
        self._draw_text(surface, self.font_body, subtitle, (self.render_rect.centerx - 68, y + 58), self.palette["muted"])

    def _draw_button(
        self,
        surface: pygame.Surface,
        rect: pygame.Rect,
        label: str,
        *,
        action: Callable[[], None],
        fill: tuple[int, int, int] | None = None,
        outline: tuple[int, int, int] | None = None,
        text_color: tuple[int, int, int] | None = None,
        radius: int = 16,
    ) -> None:
        fill = self._interactive_fill(rect, fill or self.palette["pill"])
        outline = self._interactive_outline(rect, outline or self.palette["panel_edge"])
        text_color = text_color or self.palette["text"]
        _rounded(surface, rect, fill, radius=radius)
        _rounded(surface, rect, outline, radius=radius, width=1)
        self._draw_scaled_text(
            surface,
            [self.font_body, self.font_small, self.font_micro],
            label,
            pygame.Rect(rect.x + 10, rect.y + 6, rect.width - 20, rect.height - 12),
            text_color,
            align="center",
        )
        self._register_button(rect, action)

    def _draw_toggle(
        self,
        surface: pygame.Surface,
        rect: pygame.Rect,
        label: str,
        *,
        value: bool,
        action: Callable[[], None],
    ) -> None:
        fill = self.palette["accent"] if value else self.palette["card"]
        outline = self.palette["accent_alt"] if value else self.palette["panel_edge"]
        self._draw_button(surface, rect, label, action=action, fill=fill, outline=outline)

    def _draw_slider(
        self,
        surface: pygame.Surface,
        rect: pygame.Rect,
        label: str,
        value: float,
        minimum: float,
        maximum: float,
        *,
        setter: Callable[[float], None],
        formatter: str = "{:.2f}",
    ) -> None:
        _rounded(surface, rect, self.palette["card"], radius=20)
        pygame.draw.rect(surface, self.palette["panel_edge"], rect, width=1, border_radius=4)
        self._draw_fitted_text(
            surface,
            self.font_small,
            label,
            pygame.Rect(rect.x + 16, rect.y + 12, rect.width - 132, self.font_small.get_height()),
            self.palette["muted"],
        )
        self._draw_fitted_text(
            surface,
            self.font_label,
            formatter.format(value),
            pygame.Rect(rect.right - 96, rect.y + 10, 80, self.font_label.get_height()),
            self.palette["text"],
            align="right",
        )
        track_rect = pygame.Rect(rect.x + 16, rect.y + rect.height - 20, rect.width - 32, 8)
        _rounded(surface, track_rect, self.palette["surface"], radius=8)
        t = 0.0 if maximum <= minimum else (value - minimum) / (maximum - minimum)
        fill_rect = pygame.Rect(track_rect.x, track_rect.y, max(10, int(track_rect.width * t)), track_rect.height)
        _rounded(surface, fill_rect, self.palette["accent"], radius=8)
        knob_x = track_rect.x + int(track_rect.width * t)
        knob = pygame.Rect(knob_x - 8, track_rect.centery - 8, 16, 16)
        _rounded(surface, knob, self.palette["text"], radius=8)
        self._register_slider(track_rect.inflate(0, 14), setter, minimum, maximum)

    def _draw_stat_card(
        self,
        surface: pygame.Surface,
        rect: pygame.Rect,
        title: str,
        value: str,
        *,
        accent: tuple[int, int, int] | None = None,
    ) -> None:
        accent = accent or self.palette["accent"]
        _rounded(surface, rect, self.palette["card_alt"], radius=20)
        pygame.draw.rect(surface, self.palette["panel_edge"], rect, width=1, border_radius=4)
        pygame.draw.rect(surface, accent, pygame.Rect(rect.x + 14, rect.y + 14, 8, rect.height - 28), border_radius=2)
        self._draw_fitted_text(
            surface,
            self.font_small,
            title,
            pygame.Rect(rect.x + 34, rect.y + 14, rect.width - 48, self.font_small.get_height()),
            self.palette["muted"],
        )
        self._draw_fitted_text(
            surface,
            self.font_label,
            value,
            pygame.Rect(rect.x + 34, rect.y + 34, rect.width - 48, self.font_label.get_height()),
            self.palette["text"],
        )

    def _draw_tabs(self, surface: pygame.Surface, rect: pygame.Rect) -> None:
        gap = 8
        tab_width = (rect.width - gap * (len(self.SETTINGS_TABS) - 1)) // len(self.SETTINGS_TABS)
        x = rect.x
        for tab in self.SETTINGS_TABS:
            tab_rect = pygame.Rect(x, rect.y, tab_width, rect.height)
            selected = self.selected_tab == tab
            fill = self.palette["accent"] if selected else self.palette["card"]
            outline = self.palette["accent_alt"] if selected else self.palette["panel_edge"]
            self._draw_button(surface, tab_rect, tab, action=lambda name=tab: setattr(self, "selected_tab", name), fill=fill, outline=outline)
            x += tab_width + gap

    def _draw_overlay_buttons(self, surface: pygame.Surface) -> None:
        self._draw_settings_handle(surface)
        self._draw_fullscreen_button(surface)

    def _gap_to_leader(self, leader: VehicleRuntime, vehicle: VehicleRuntime) -> str:
        mode = self.config.race_mode
        if mode == "qualifying":
            leader_best = self._best_lap_time(leader)
            vehicle_best = self._best_lap_time(vehicle)
            if leader.id == vehicle.id:
                return _format_seconds(leader_best) if leader_best is not None else "No lap"
            if leader_best is None or vehicle_best is None:
                return "No lap"
            return f"+{max(0.0, vehicle_best - leader_best):.2f}s"
        if mode == "clean_race":
            if leader.id == vehicle.id:
                return f"{self._total_contacts(vehicle)} hits"
            return f"+{max(0, self._total_contacts(vehicle) - self._total_contacts(leader))} hits"
        if mode == "precision":
            leader_error = self._mean_center_error(leader)
            vehicle_error = self._mean_center_error(vehicle)
            if leader_error is None or vehicle_error is None:
                return "--"
            if leader.id == vehicle.id:
                return f"{leader_error:.2f} m"
            return f"+{max(0.0, vehicle_error - leader_error):.2f} m"
        if mode == "consistency":
            leader_spread = self._consistency_spread(leader)
            vehicle_spread = self._consistency_spread(vehicle)
            if leader.id == vehicle.id:
                return "Best spread" if leader_spread is None else f"sigma {leader_spread:.2f}s"
            if leader_spread is None or vehicle_spread is None:
                return "--"
            return f"+{max(0.0, vehicle_spread - leader_spread):.2f}s"
        if leader.id == vehicle.id:
            return "Leader"
        if leader.finish_time is not None and vehicle.finish_time is not None:
            return f"+{max(0.0, vehicle.finish_time - leader.finish_time):.1f}s"
        if self.geometry is None:
            return "--"
        distance_gap = max(0.0, (leader.unwrapped_progress - vehicle.unwrapped_progress) * self.geometry.total_length)
        leader_distance = max(0.1, leader.unwrapped_progress * self.geometry.total_length)
        average_pace = leader_distance / max(self.sim_time, 0.1)
        reference_speed = max(1.0, abs(leader.speed), average_pace)
        return f"+{distance_gap / reference_speed:.1f}s"

    def _draw_hud(self, surface: pygame.Surface) -> None:
        info_rect = pygame.Rect(self.render_rect.x + 18, self.render_rect.y + 18, 402, 132)
        surface.blit(_alpha_surface(info_rect.size, (10, 12, 15, 188)), info_rect)
        pygame.draw.rect(surface, self.palette["panel_edge"], info_rect, width=1, border_radius=4)
        self._draw_fitted_text(
            surface,
            self.font_title,
            APP_TITLE,
            pygame.Rect(info_rect.x + 18, info_rect.y + 12, info_rect.width - 36, self.font_title.get_height()),
            self.palette["text"],
        )
        self._draw_fitted_text(
            surface,
            self.font_small,
            f"Track: {self._active_track_label(self.track_settings.name)}",
            pygame.Rect(info_rect.x + 18, info_rect.y + 54, 182, self.font_small.get_height()),
            self.palette["muted"],
        )
        self._draw_fitted_text(
            surface,
            self.font_small,
            f"Mode: {self._race_mode_label()}",
            pygame.Rect(info_rect.x + 220, info_rect.y + 54, 164, self.font_small.get_height()),
            self.palette["muted"],
        )
        self._draw_text(surface, self.font_small, f"Sim: {self.sim_time:6.2f}s", (info_rect.x + 18, info_rect.y + 74), self.palette["muted"])
        self._draw_text(surface, self.font_small, f"Laps: {self.config.lap_target}", (info_rect.x + 220, info_rect.y + 74), self.palette["muted"])
        status = "Paused" if self.paused else "Live"
        if self.awaiting_race_start and not self.countdown_active:
            status = "Ready"
        if self.countdown_active:
            status = "Starting"
        if self.stop_reason:
            status = self.stop_reason.title()
        self._draw_text(surface, self.font_label, status, (info_rect.x + 18, info_rect.y + 96), self.palette["accent_alt"])

        focus = self._focused_vehicle()
        if focus is not None:
            vehicle_rect = pygame.Rect(self.render_rect.x + 18, info_rect.bottom + 12, 320, 118)
            surface.blit(_alpha_surface(vehicle_rect.size, (10, 12, 15, 188)), vehicle_rect)
            pygame.draw.rect(surface, self.palette["panel_edge"], vehicle_rect, width=1, border_radius=4)
            self._draw_fitted_text(
                surface,
                self.font_label,
                focus.name,
                pygame.Rect(vehicle_rect.x + 18, vehicle_rect.y + 14, vehicle_rect.width - 36, self.font_label.get_height()),
                self.palette["text"],
            )
            self._draw_text(surface, self.font_small, f"Speed {abs(focus.speed):.2f} m/s", (vehicle_rect.x + 18, vehicle_rect.y + 44), self.palette["muted"])
            self._draw_text(surface, self.font_small, f"Lap {focus.laps}/{self.config.lap_target}", (vehicle_rect.x + 18, vehicle_rect.y + 64), self.palette["muted"])
            self._draw_text(surface, self.font_small, f"Completion {focus.signed_completion():.2f}%", (vehicle_rect.x + 18, vehicle_rect.y + 84), self.palette["muted"])
            if focus.last_error:
                self._draw_text(surface, self.font_small, "Driver error active", (vehicle_rect.x + 176, vehicle_rect.y + 84), self.palette["danger"])

        standings = self._standings()[:5]
        standings_rect = self._standings_rect()
        surface.blit(_alpha_surface(standings_rect.size, (10, 12, 15, 192)), standings_rect)
        pygame.draw.rect(surface, self.palette["panel_edge"], standings_rect, width=1, border_radius=4)
        self._draw_text(surface, self.font_label, "Standings", (standings_rect.x + 18, standings_rect.y + 12), self.palette["text"])
        self._draw_text(surface, self.font_small, self._race_mode_label(), (standings_rect.x + 18, standings_rect.y + 32), self.palette["muted"])
        y = standings_rect.y + 54
        leader = standings[0] if standings else None
        for place, vehicle in enumerate(standings, start=1):
            color = self.palette["warning"] if place == 1 else self.palette["muted"]
            metric = self._gap_to_leader(leader, vehicle) if leader is not None else "--"
            self._draw_fitted_text(
                surface,
                self.font_small,
                f"{place}. {vehicle.name}",
                pygame.Rect(standings_rect.x + 18, y, standings_rect.width - 116, self.font_small.get_height()),
                color,
            )
            self._draw_fitted_text(
                surface,
                self.font_small,
                metric,
                pygame.Rect(standings_rect.right - 92, y, 72, self.font_small.get_height()),
                self.palette["text"],
                align="right",
            )
            y += 22

    def _draw_race_tab(self, surface: pygame.Surface, panel: pygame.Rect, y: int) -> None:
        card_w = panel.width - 48
        row_gap = 14
        top_row = pygame.Rect(panel.x + 24, y, card_w, 48)
        left = pygame.Rect(top_row.x, top_row.y, (card_w - 10) // 2, top_row.height)
        right = pygame.Rect(left.right + 10, top_row.y, (card_w - 10) // 2, top_row.height)
        if self.countdown_active:
            primary_label = "Starting..."
        elif self.awaiting_race_start:
            primary_label = "Start Race"
        else:
            primary_label = "Resume" if self.paused else "Pause"
        self._draw_button(surface, left, primary_label, action=self._toggle_pause_or_start, fill=self.palette["accent"])
        self._draw_button(surface, right, "Reset Grid", action=lambda: self._position_vehicles(reset_progress=True), fill=self.palette["card"])
        y = top_row.bottom + row_gap

        row = pygame.Rect(panel.x + 24, y, card_w, 48)
        left = pygame.Rect(row.x, row.y, (card_w - 10) // 2, row.height)
        right = pygame.Rect(left.right + 10, row.y, (card_w - 10) // 2, row.height)
        self._draw_button(surface, left, "Reload Drivers", action=self.reload_all_drivers)
        self._draw_toggle(surface, right, "Manual Control", value=self.manual_control, action=lambda: setattr(self, "manual_control", not self.manual_control))
        y = row.bottom + row_gap

        focus_vehicle = self._focused_vehicle()
        stats = [
            ("Race time", _format_seconds(self.sim_time), self.palette["accent"]),
            ("Sim speed", f"{self.sim_speed:.2f}x", self.palette["warning"]),
            ("Physics rate", f"{self.config.physics_hz} Hz", self.palette["success"]),
            ("Focused", focus_vehicle.name if focus_vehicle is not None else "Free camera", self.palette["accent_alt"]),
        ]
        for index, (title, value, accent) in enumerate(stats):
            col = index % 2
            row_idx = index // 2
            rect = pygame.Rect(panel.x + 24 + col * ((card_w + 12) // 2), y + row_idx * 92, (card_w - 12) // 2, 78)
            self._draw_stat_card(surface, rect, title, value, accent=accent)
        y += 184

        lap_rect = pygame.Rect(panel.x + 24, y, card_w, 74)
        _rounded(surface, lap_rect, self.palette["card"], radius=20)
        pygame.draw.rect(surface, self.palette["panel_edge"], lap_rect, width=1, border_radius=4)
        self._draw_text(surface, self.font_small, "Lap target", (lap_rect.x + 16, lap_rect.y + 12), self.palette["muted"])
        self._draw_text(surface, self.font_stat, str(self.config.lap_target), (lap_rect.x + 18, lap_rect.y + 26), self.palette["text"])
        minus = pygame.Rect(lap_rect.right - 108, lap_rect.y + 16, 42, 42)
        plus = pygame.Rect(lap_rect.right - 56, lap_rect.y + 16, 42, 42)
        self._draw_button(surface, minus, "-", action=lambda: setattr(self.config, "lap_target", max(1, self.config.lap_target - 1)), fill=self.palette["surface"])
        self._draw_button(surface, plus, "+", action=lambda: setattr(self.config, "lap_target", min(200, self.config.lap_target + 1)), fill=self.palette["surface"])
        y = lap_rect.bottom + row_gap

        speed_rect = pygame.Rect(panel.x + 24, y, card_w, 76)
        self._draw_slider(surface, speed_rect, "Sim speed", self.sim_speed, 0.25, 6.0, setter=self._set_sim_speed, formatter="{:.2f}x")
        y = speed_rect.bottom + row_gap

        auto_reload_rect = pygame.Rect(panel.x + 24, y, card_w, 48)
        self._draw_toggle(surface, auto_reload_rect, "Auto reload drivers", value=self.config.auto_reload, action=lambda: setattr(self.config, "auto_reload", not self.config.auto_reload))

    def _set_track_value(self, name: str, value: float) -> None:
        setattr(self.edit_track_settings, name, float(value))
        self.pending_track_rebuild = True

    def _set_race_mode(self, mode: str) -> None:
        if mode not in RACE_MODE_INFO:
            return
        self.config.race_mode = mode

    def _draw_track_tab(self, surface: pygame.Surface, panel: pygame.Rect, y: int) -> None:
        card_w = panel.width - 48
        preview_rect = pygame.Rect(panel.x + 24, y, card_w, 112)
        _rounded(surface, preview_rect, self.palette["card_alt"], radius=22)
        pygame.draw.rect(surface, self.palette["panel_edge"], preview_rect, width=1, border_radius=4)
        preview = self._get_fitted_track_preview(self.edit_track_settings.name, (preview_rect.width - 24, preview_rect.height - 46))
        if preview is not None:
            surface.blit(preview, (preview_rect.x + 12, preview_rect.y + 42))
        self._draw_text(surface, self.font_small, "Track preview", (preview_rect.x + 14, preview_rect.y + 12), self.palette["muted"])
        world_badge = pygame.Rect(preview_rect.right - 142, preview_rect.y + 12, 126, 28)
        _rounded(surface, world_badge, self.palette["pill"], radius=14)
        pygame.draw.rect(surface, self.palette["panel_edge"], world_badge, width=1, border_radius=4)
        self._draw_fitted_text(
            surface,
            self.font_label,
            self._active_track_label(self.edit_track_settings.name),
            pygame.Rect(preview_rect.x + 14, preview_rect.y + 24, world_badge.x - preview_rect.x - 22, self.font_label.get_height()),
            self.palette["text"],
        )
        self._draw_scaled_text(
            surface,
            [self.font_small, self.font_micro],
            f"World: {self.config.world_mode.title()}",
            world_badge.inflate(-12, -6),
            self.palette["accent_alt"] if self._is_advanced_mode() else self.palette["text"],
            align="center",
        )
        y = preview_rect.bottom + 8

        switch_row = pygame.Rect(panel.x + 24, y, card_w, 38)
        prev_rect = pygame.Rect(switch_row.x, switch_row.y, 52, switch_row.height)
        next_rect = pygame.Rect(switch_row.right - 52, switch_row.y, 52, switch_row.height)
        center_rect = pygame.Rect(prev_rect.right + 10, switch_row.y, switch_row.width - 124, switch_row.height)
        self._draw_button(surface, prev_rect, "<", action=lambda: self._cycle_track(-1), fill=self.palette["surface"])
        self._draw_button(surface, next_rect, ">", action=lambda: self._cycle_track(1), fill=self.palette["surface"])
        _rounded(surface, center_rect, self.palette["card"], radius=18)
        pygame.draw.rect(surface, self.palette["panel_edge"], center_rect, width=1, border_radius=4)
        label = _text_surface(self.font_body, self._active_track_label(self.edit_track_settings.name), self.palette["text"])
        surface.blit(label, label.get_rect(center=center_rect.center))
        y = switch_row.bottom + 8

        mode_note = (
            "Advanced mode active: Track list shows sidecar-authored 3D tracks only."
            if self._is_advanced_mode()
            else 'Standard mode active: use --advanced or world_mode = "advanced" before launch for hill/bank tracks.'
        )
        mode_rect = pygame.Rect(panel.x + 24, y, card_w, 54)
        _rounded(surface, mode_rect, self.palette["card"], radius=18)
        pygame.draw.rect(surface, self.palette["panel_edge"], mode_rect, width=1, border_radius=4)
        self._draw_wrapped_text(
            surface,
            self.font_small,
            mode_note,
            pygame.Rect(mode_rect.x + 14, mode_rect.y + 10, mode_rect.width - 28, mode_rect.height - 18),
            self.palette["soft"],
            max_lines=2,
            line_height=16,
        )
        y = mode_rect.bottom + 8

        sliders = [
            ("Track scale", self.edit_track_settings.track_scale * 100.0, 35.0, 140.0, lambda value: self._set_track_value("track_scale", value / 100.0), "{:.0f}%"),
            ("Track width", self.edit_track_settings.half_width * 2.0, 2.4, 4.8, lambda value: self._set_track_value("half_width", value * 0.5), "{:.2f} m"),
            ("Curb width", self.edit_track_settings.curb_width, 0.10, 0.40, lambda value: self._set_track_value("curb_width", value), "{:.2f} m"),
            ("Wall gap", self.edit_track_settings.wall_gap, 0.10, 0.60, lambda value: self._set_track_value("wall_gap", value), "{:.2f} m"),
            ("Wall height", self.edit_track_settings.wall_height, 0.45, 1.20, lambda value: self._set_track_value("wall_height", value), "{:.2f} m"),
            ("Wall thickness", self.edit_track_settings.wall_thickness, 0.08, 0.30, lambda value: self._set_track_value("wall_thickness", value), "{:.2f} m"),
            ("Wall panel length", self.edit_track_settings.panel_length, 0.60, 2.40, lambda value: self._set_track_value("panel_length", value), "{:.2f} m"),
        ]
        for title, value, minimum, maximum, setter, fmt in sliders:
            rect = pygame.Rect(panel.x + 24, y, card_w, 58)
            self._draw_slider(surface, rect, title, value, minimum, maximum, setter=setter, formatter=fmt)
            y = rect.bottom + 6

        if self._is_advanced_mode():
            section_rect = pygame.Rect(panel.x + 24, y, card_w, 38)
            _rounded(surface, section_rect, self.palette["card_alt"], radius=18)
            pygame.draw.rect(surface, self.palette["panel_edge"], section_rect, width=1, border_radius=4)
            self._draw_text(surface, self.font_small, "Advanced surface", (section_rect.x + 14, section_rect.y + 10), self.palette["muted"])
            y = section_rect.bottom + 8

            advanced_sliders = [
                ("Elevation scale", self.edit_track_settings.elevation_scale * 100.0, 25.0, 220.0, lambda value: self._set_track_value("elevation_scale", value / 100.0), "{:.0f}%"),
                ("Bank scale", self.edit_track_settings.bank_scale * 100.0, 25.0, 220.0, lambda value: self._set_track_value("bank_scale", value / 100.0), "{:.0f}%"),
                ("Terrain height", self.edit_track_settings.terrain_height_scale * 100.0, 25.0, 220.0, lambda value: self._set_track_value("terrain_height_scale", value / 100.0), "{:.0f}%"),
                ("Terrain blend", self.edit_track_settings.terrain_blend_radius, 1.0, 14.0, lambda value: self._set_track_value("terrain_blend_radius", value), "{:.1f} m"),
                ("Road smoothing", self.edit_track_settings.road_height_smoothing, 0.0, 1.0, lambda value: self._set_track_value("road_height_smoothing", value), "{:.2f}"),
                ("Bank smoothing", self.edit_track_settings.bank_smoothing, 0.0, 1.0, lambda value: self._set_track_value("bank_smoothing", value), "{:.2f}"),
            ]
            for title, value, minimum, maximum, setter, fmt in advanced_sliders:
                rect = pygame.Rect(panel.x + 24, y, card_w, 58)
                self._draw_slider(surface, rect, title, value, minimum, maximum, setter=setter, formatter=fmt)
                y = rect.bottom + 6

        row = pygame.Rect(panel.x + 24, y, card_w, 48)
        left = pygame.Rect(row.x, row.y, (card_w - 10) // 2, row.height)
        right = pygame.Rect(left.right + 10, row.y, (card_w - 10) // 2, row.height)
        self._draw_button(surface, left, "Reset Defaults", action=self._reset_track_defaults, fill=self.palette["card"])
        fill = self.palette["accent"] if self.pending_track_rebuild else self.palette["pill"]
        label = "Apply Track" if self.pending_track_rebuild else "Track Up To Date"
        self._draw_button(surface, right, label, action=self._apply_track_changes, fill=fill)

    def _cycle_camera_mode(self) -> None:
        self.aerial_view = False
        current = self.CAMERA_MODES.index(self.camera_mode)
        next_mode = self.CAMERA_MODES[(current + 1) % len(self.CAMERA_MODES)]
        if next_mode == "trackside":
            self._cycle_trackside_view()
            return
        if next_mode in {"follow", "chase"} and self._focused_vehicle() is None:
            next_mode = "overview"
        self.camera_mode = next_mode

    def _set_render_scale(self, value: float) -> None:
        self.render_scale = float(value)
        if self.renderer is not None:
            self.renderer.close()
            self.renderer = None
            self.renderer_size = None

    def _cycle_scene_render_hz(self, direction: int = 1) -> None:
        options = self.SCENE_RENDER_HZ_OPTIONS
        current = int(self.config.scene_render_hz)
        try:
            index = options.index(current)
        except ValueError:
            index = min(range(len(options)), key=lambda idx: abs(options[idx] - current))
        self.config.scene_render_hz = options[(index + (1 if direction >= 0 else -1)) % len(options)]

    def _draw_view_tab(self, surface: pygame.Surface, panel: pygame.Rect, y: int) -> None:
        card_w = panel.width - 48
        row = pygame.Rect(panel.x + 24, y, card_w, 48)
        left = pygame.Rect(row.x, row.y, (card_w - 10) // 2, row.height)
        right = pygame.Rect(left.right + 10, row.y, (card_w - 10) // 2, row.height)
        self._draw_button(surface, left, "Windowed" if self.fullscreen else "Fullscreen", action=self._toggle_fullscreen, fill=self.palette["accent"])
        self._draw_button(surface, right, "Reset Camera", action=self._reset_camera_pose, fill=self.palette["card"])
        y = row.bottom + 14

        popout_row = pygame.Rect(panel.x + 24, y, card_w, 48)
        self._draw_toggle(
            surface,
            popout_row,
            "Pop Out Controls",
            value=self.settings_detached,
            action=lambda: self._set_settings_detached(not self.settings_detached),
        )
        y = popout_row.bottom + 14

        row = pygame.Rect(panel.x + 24, y, card_w, 48)
        left = pygame.Rect(row.x, row.y, (card_w - 10) // 2, row.height)
        right = pygame.Rect(left.right + 10, row.y, (card_w - 10) // 2, row.height)
        self._draw_toggle(surface, left, "Show Lidar", value=self.show_lidar, action=lambda: setattr(self, "show_lidar", not self.show_lidar))
        self._draw_toggle(surface, right, "Show Racing Line", value=self.show_racing_line, action=lambda: setattr(self, "show_racing_line", not self.show_racing_line))
        y = row.bottom + 14

        row = pygame.Rect(panel.x + 24, y, card_w, 48)
        left = pygame.Rect(row.x, row.y, (card_w - 10) // 2, row.height)
        right = pygame.Rect(left.right + 10, row.y, (card_w - 10) // 2, row.height)
        self._draw_toggle(surface, left, "Lock Camera", value=self.lock_camera, action=lambda: setattr(self, "lock_camera", not self.lock_camera))
        self._draw_button(surface, right, f"Camera: {self.camera_mode.title()}", action=self._cycle_camera_mode)
        y = row.bottom + 14

        aerial_row = pygame.Rect(panel.x + 24, y, card_w, 48)
        self._draw_toggle(surface, aerial_row, "Aerial Overview", value=self.aerial_view, action=self._toggle_aerial_view)
        y = aerial_row.bottom + 14

        camera_distance_rect = pygame.Rect(panel.x + 24, y, card_w, 76)
        self._draw_slider(surface, camera_distance_rect, "Camera distance", self.camera_distance, 2.0, 60.0, setter=lambda value: setattr(self, "camera_distance", value), formatter="{:.1f}")
        y = camera_distance_rect.bottom + 10

        fps_row = pygame.Rect(panel.x + 24, y, card_w, 40)
        prev_rect = pygame.Rect(fps_row.x, fps_row.y, 52, fps_row.height)
        next_rect = pygame.Rect(fps_row.right - 52, fps_row.y, 52, fps_row.height)
        center_rect = pygame.Rect(prev_rect.right + 10, fps_row.y, fps_row.width - 124, fps_row.height)
        self._draw_button(surface, prev_rect, "<", action=lambda: self._cycle_scene_render_hz(-1), fill=self.palette["surface"])
        self._draw_button(surface, next_rect, ">", action=lambda: self._cycle_scene_render_hz(1), fill=self.palette["surface"])
        _rounded(surface, center_rect, self.palette["card"], radius=18)
        pygame.draw.rect(surface, self.palette["panel_edge"], center_rect, width=1, border_radius=4)
        self._draw_fitted_text(
            surface,
            self.font_body,
            f"Scene FPS {self.config.scene_render_hz} Hz",
            pygame.Rect(center_rect.x + 16, center_rect.y + 10, center_rect.width - 32, self.font_body.get_height()),
            self.palette["text"],
        )
        y = fps_row.bottom + 10

        render_scale_rect = pygame.Rect(panel.x + 24, y, card_w, 76)
        self._draw_slider(surface, render_scale_rect, "Render scale", self.render_scale, 0.55, 1.0, setter=self._set_render_scale, formatter="{:.2f}")
        y = render_scale_rect.bottom + 10

        scene_rect = pygame.Rect(panel.x + 24, y, card_w, 78)
        _rounded(surface, scene_rect, self.palette["card"], radius=20)
        pygame.draw.rect(surface, self.palette["panel_edge"], scene_rect, width=1, border_radius=4)
        scene_mode = "Reduced" if self.config.reduced_scene_complexity else "Full"
        self._draw_fitted_text(
            surface,
            self.font_small,
            "Boot scene complexity",
            pygame.Rect(scene_rect.x + 16, scene_rect.y + 12, scene_rect.width - 140, self.font_small.get_height()),
            self.palette["muted"],
        )
        badge_rect = pygame.Rect(scene_rect.right - 104, scene_rect.y + 12, 88, 28)
        _rounded(surface, badge_rect, self.palette["card_alt"], radius=14)
        pygame.draw.rect(surface, self.palette["panel_edge"], badge_rect, width=1, border_radius=4)
        self._draw_scaled_text(
            surface,
            [self.font_small, self.font_micro],
            scene_mode,
            badge_rect.inflate(-12, -6),
            self.palette["text"],
            align="center",
        )
        self._draw_wrapped_text(
            surface,
            self.font_small,
            "Edit aigp.runtime.toml before launch to change this boot-only setting.",
            pygame.Rect(scene_rect.x + 16, scene_rect.y + 42, scene_rect.width - 32, 24),
            self.palette["soft"],
            max_lines=2,
            line_height=16,
        )
        y = scene_rect.bottom + 10

        cam_rect = pygame.Rect(panel.x + 24, y, card_w, 124)
        _rounded(surface, cam_rect, self.palette["card_alt"], radius=20)
        pygame.draw.rect(surface, self.palette["panel_edge"], cam_rect, width=1, border_radius=4)
        self._draw_text(surface, self.font_small, "Camera controls", (cam_rect.x + 16, cam_rect.y + 12), self.palette["muted"])
        camera_lines = [
            "Drag in the track view to orbit the active camera.",
            "Left/Right or P/N switches the watched driver.",
            "Up/Down or V cycles the trackside viewpoints.",
            "Enter toggles aerial view. F11 toggles fullscreen.",
        ]
        line_y = cam_rect.y + 38
        for index, line in enumerate(camera_lines):
            color = self.palette["soft"] if index == 0 else self.palette["text"]
            self._draw_scaled_text(
                surface,
                [self.font_small, self.font_micro],
                line,
                pygame.Rect(cam_rect.x + 16, line_y, cam_rect.width - 32, 18),
                color,
            )
            line_y += 19
        y = cam_rect.bottom + 10

        note_rect = pygame.Rect(panel.x + 24, y, card_w, 108)
        _rounded(surface, note_rect, self.palette["card"], radius=20)
        pygame.draw.rect(surface, self.palette["panel_edge"], note_rect, width=1, border_radius=4)
        self._draw_text(surface, self.font_small, "Quick shortcuts", (note_rect.x + 16, note_rect.y + 12), self.palette["muted"])
        shortcut_lines = [
            ("Space start or pause. R reload. E reset.", self.palette["text"]),
            ("Left/Right drivers. Up/Down track views.", self.palette["text"]),
            ("Enter aerial view. Tab settings. F11 fullscreen.", self.palette["text"]),
            ("World/scene complexity are boot-only in aigp.runtime.toml.", self.palette["soft"]),
        ]
        line_y = note_rect.y + 38
        for line, color in shortcut_lines:
            self._draw_scaled_text(
                surface,
                [self.font_small, self.font_micro],
                line,
                pygame.Rect(note_rect.x + 16, line_y, note_rect.width - 32, 18),
                color,
            )
            line_y += 18

    def _draw_modes_tab(self, surface: pygame.Surface, panel: pygame.Rect, y: int) -> None:
        card_w = panel.width - 48
        for mode, meta in RACE_MODE_INFO.items():
            rect = pygame.Rect(panel.x + 24, y, card_w, 88)
            selected = self.config.race_mode == mode
            fill = self.palette["card_alt"] if selected else self.palette["card"]
            outline = self.palette["accent_alt"] if selected else self.palette["panel_edge"]
            _rounded(surface, rect, fill, radius=20)
            pygame.draw.rect(surface, outline, rect, width=1, border_radius=4)
            self._draw_text(surface, self.font_label, meta["label"], (rect.x + 16, rect.y + 12), self.palette["text"])
            for line_index, line in enumerate(textwrap.wrap(meta["summary"], width=40)[:2]):
                self._draw_text(surface, self.font_small, line, (rect.x + 16, rect.y + 36 + line_index * 16), self.palette["muted"])
            button_rect = pygame.Rect(rect.right - 92, rect.y + 18, 76, 40)
            label = "Selected" if selected else "Use"
            fill_color = self.palette["accent"] if selected else self.palette["surface"]
            self._draw_button(surface, button_rect, label, action=lambda name=mode: self._set_race_mode(name), fill=fill_color, radius=14)
            y = rect.bottom + 10

    def _reload_single_driver(self, vehicle: VehicleRuntime) -> None:
        try:
            vehicle.controller.load()
            vehicle.last_error = None
        except Exception as exc:
            vehicle.last_error = f"{type(exc).__name__}: {exc}"
            vehicle.error_count += 1
            self._status(f"Reload failed for {vehicle.name}: {exc}")

    def _draw_text_input(
        self,
        surface: pygame.Surface,
        rect: pygame.Rect,
        label: str,
        value: str,
        *,
        active: bool,
        action: Callable[[], None],
    ) -> None:
        fill = self._interactive_fill(rect, self.palette["card_alt"])
        _rounded(surface, rect, fill, radius=20)
        border = self.palette["accent_alt"] if active else self._interactive_outline(rect, self.palette["panel_edge"])
        pygame.draw.rect(surface, border, rect, width=1, border_radius=4)
        self._draw_text(surface, self.font_small, label, (rect.x + 14, rect.y + 10), self.palette["muted"])
        shown = value if value else "Click to rename"
        text_color = self.palette["text"] if value else self.palette["soft"]
        self._draw_fitted_text(
            surface,
            self.font_body,
            shown,
            pygame.Rect(rect.x + 14, rect.y + 28, rect.width - 28, self.font_body.get_height()),
            text_color,
        )
        self._register_button(rect, action)

    def _draw_color_selector(self, surface: pygame.Surface, rect: pygame.Rect, label: str, value, *, vehicle_id: int, field_name: str) -> None:
        rgb = _color_rgb(value)
        _rounded(surface, rect, self._interactive_fill(rect, self.palette["card_alt"]), radius=20)
        pygame.draw.rect(surface, self._interactive_outline(rect, self.palette["panel_edge"]), rect, width=1, border_radius=4)
        self._draw_fitted_text(
            surface,
            self.font_small,
            label,
            pygame.Rect(rect.x + 14, rect.y + 10, rect.width - 112, self.font_small.get_height()),
            self.palette["muted"],
        )
        swatch_rect = pygame.Rect(rect.x + 14, rect.y + 29, 26, 18)
        _rounded(surface, swatch_rect, rgb, radius=8)
        pygame.draw.rect(surface, self.palette["surface"], swatch_rect, width=1, border_radius=4)
        self._draw_scaled_text(
            surface,
            [self.font_small, self.font_micro],
            _color_label(value),
            pygame.Rect(rect.x + 48, rect.y + 27, rect.width - 144, 22),
            self.palette["text"],
        )
        pick_rect = pygame.Rect(rect.right - 90, rect.y + 12, 74, 32)
        self._draw_button(surface, pick_rect, "Pick", action=lambda: self._pick_driver_color(vehicle_id, field_name), fill=self.palette["surface"], radius=14)
        self._register_button(rect, lambda: self._pick_driver_color(vehicle_id, field_name))

    def _draw_driver_source_selector(self, surface: pygame.Surface, rect: pygame.Rect, vehicle_id: int, driver_ref: str) -> None:
        current_path = self._resolve_driver_path(driver_ref)
        label = self._driver_option_label(current_path)

        _rounded(surface, rect, self._interactive_fill(rect, self.palette["card_alt"]), radius=20)
        pygame.draw.rect(surface, self._interactive_outline(rect, self.palette["panel_edge"]), rect, width=1, border_radius=4)
        self._draw_fitted_text(
            surface,
            self.font_small,
            "Driver file",
            pygame.Rect(rect.x + 14, rect.y + 10, rect.width - 112, self.font_small.get_height()),
            self.palette["muted"],
        )
        self._draw_scaled_text(
            surface,
            [self.font_body, self.font_small, self.font_micro],
            label,
            pygame.Rect(rect.x + 14, rect.y + 27, rect.width - 120, 22),
            self.palette["text"],
        )
        browse_rect = pygame.Rect(rect.right - 98, rect.y + 12, 82, 32)
        self._draw_button(surface, browse_rect, "Browse", action=lambda: self._browse_driver_source(vehicle_id), fill=self.palette["surface"], radius=14)
        self._register_button(rect, lambda: self._browse_driver_source(vehicle_id))

    def _draw_drivers_tab(self, surface: pygame.Surface, panel: pygame.Rect, y: int) -> None:
        card_w = panel.width - 48
        standings_map = {vehicle.id: place for place, vehicle in enumerate(self._standings(), start=1)}
        if not self.cars_raw:
            empty_rect = pygame.Rect(panel.x + 24, y, card_w, 104)
            _rounded(surface, empty_rect, self.palette["card"], radius=20)
            pygame.draw.rect(surface, self.palette["panel_edge"], empty_rect, width=1, border_radius=4)
            self._draw_fitted_text(
                surface,
                self.font_label,
                "No drivers in the grid",
                pygame.Rect(empty_rect.x + 18, empty_rect.y + 18, empty_rect.width - 36, self.font_label.get_height()),
                self.palette["text"],
            )
            self._draw_wrapped_text(
                surface,
                self.font_small,
                "Use Add Driver to scaffold a new car in the local drivers folder.",
                pygame.Rect(empty_rect.x + 18, empty_rect.y + 50, empty_rect.width - 36, 36),
                self.palette["muted"],
                max_lines=2,
                line_height=16,
            )
            add_rect = pygame.Rect(panel.x + 24, empty_rect.bottom + 14, card_w, 48)
            self._draw_button(surface, add_rect, "Add Driver", action=self._add_driver, fill=self.palette["accent"])
            return

        for vehicle_id, car in enumerate(self.cars_raw):
            is_active = self._car_is_active(car)
            vehicle = self._vehicle_for_car_index(vehicle_id)
            expanded = self.driver_settings_open == vehicle_id
            rect_height = self._driver_card_height(vehicle_id)
            rect = pygame.Rect(panel.x + 24, y, card_w, rect_height)
            _rounded(surface, rect, self.palette["card"], radius=20)
            pygame.draw.rect(surface, self.palette["panel_edge"], rect, width=1, border_radius=4)
            title = str(car.get("name", f"car {vehicle_id}"))
            place = standings_map.get(vehicle.id) if vehicle is not None else None
            place_prefix = f"P{place}" if place is not None else "Off"
            header_gap = 8
            active_width = 82
            watch_width = 68
            settings_width = 88
            settings_rect = pygame.Rect(rect.right - 16 - settings_width, rect.y + 16, settings_width, 32)
            watch_rect = pygame.Rect(settings_rect.x - header_gap - watch_width, rect.y + 16, watch_width, 32)
            active_rect = pygame.Rect(watch_rect.x - header_gap - active_width, rect.y + 16, active_width, 32)
            header_text_width = max(104, active_rect.x - rect.x - 28)
            self._draw_fitted_text(
                surface,
                self.font_label,
                f"{place_prefix}  {title}",
                pygame.Rect(rect.x + 16, rect.y + 14, header_text_width, self.font_label.get_height()),
                self.palette["text"] if is_active else self.palette["muted"],
            )
            driver_ref = str(car.get("driver", "driver"))
            module_name = Path(driver_ref[7:]).stem if driver_ref.startswith("file://") else driver_ref.split(".")[-1]
            self._draw_fitted_text(
                surface,
                self.font_small,
                _title_from_stem(module_name),
                pygame.Rect(rect.x + 16, rect.y + 40, header_text_width, self.font_small.get_height()),
                self.palette["accent_alt"] if is_active else self.palette["soft"],
            )
            if vehicle is not None:
                avg_driver = 1000.0 * vehicle.driver_total_time / max(1, vehicle.driver_call_count)
                metric_width = max(120, min(header_text_width, rect.width - 196))
                left_metric = pygame.Rect(rect.x + 16, rect.y + 62, metric_width // 2 - 6, self.font_small.get_height())
                right_metric = pygame.Rect(left_metric.right + 12, rect.y + 62, metric_width - left_metric.width - 12, self.font_small.get_height())
                self._draw_fitted_text(surface, self.font_small, f"Peak {vehicle.peak_speed:.2f} m/s", left_metric, self.palette["muted"])
                self._draw_fitted_text(surface, self.font_small, f"Driver {avg_driver:.3f} ms", right_metric, self.palette["muted"])
                status_text = vehicle.last_error if vehicle.last_error else "Driver healthy"
                status_color = self.palette["danger"] if vehicle.last_error else self.palette["success"]
                self._draw_fitted_text(
                    surface,
                    self.font_small,
                    status_text,
                    pygame.Rect(rect.x + 16, rect.y + 84, rect.width - 32, self.font_small.get_height()),
                    status_color,
                )
            else:
                self._draw_fitted_text(
                    surface,
                    self.font_small,
                    "Inactive: not staged, simulated, sensed, or scored",
                    pygame.Rect(rect.x + 16, rect.y + 62, rect.width - 32, self.font_small.get_height()),
                    self.palette["soft"],
                )

            self._draw_button(
                surface,
                active_rect,
                "Active" if is_active else "Inactive",
                action=lambda idx=vehicle_id, value=not is_active: self._set_driver_active(idx, value),
                fill=self.palette["accent"] if is_active else self.palette["card_alt"],
                outline=self.palette["accent_alt"] if is_active else self.palette["panel_edge"],
                radius=14,
            )
            if vehicle is not None:
                self._draw_button(surface, watch_rect, "Watch", action=lambda idx=vehicle.id: self._set_driver_focus(idx), fill=self.palette["surface"], radius=14)
            else:
                self._draw_button(surface, watch_rect, "Off", action=lambda: None, fill=self.palette["card_alt"], outline=self.palette["panel_edge"], text_color=self.palette["muted"], radius=14)
            self._draw_button(surface, settings_rect, "Settings", action=lambda idx=vehicle_id: self._toggle_driver_settings(idx), fill=self.palette["surface"], radius=14)

            if expanded:
                divider_y = rect.y + 118
                pygame.draw.line(surface, self.palette["panel_edge"], (rect.x + 16, divider_y), (rect.right - 16, divider_y))

                name_rect = pygame.Rect(rect.x + 16, divider_y + 14, rect.width - 122, 56)
                save_rect = pygame.Rect(rect.right - 94, divider_y + 14, 78, 56)
                active = self.driver_name_edit_id == vehicle_id
                current_name = self.driver_name_buffer if active else title
                self._draw_text_input(
                    surface,
                    name_rect,
                    "Driver name",
                    current_name,
                    active=active,
                    action=lambda idx=vehicle_id: self._begin_driver_name_edit(idx),
                )
                self._draw_button(surface, save_rect, "Save", action=self._commit_driver_name_edit, fill=self.palette["accent"], radius=14)

                source_rect = pygame.Rect(rect.x + 16, name_rect.bottom + 12, rect.width - 32, 56)
                self._draw_driver_source_selector(surface, source_rect, vehicle_id, str(car.get("driver", "")))

                color_y = source_rect.bottom + 12
                primary_rect = pygame.Rect(rect.x + 16, color_y, rect.width - 32, 58)
                secondary_rect = pygame.Rect(rect.x + 16, primary_rect.bottom + 10, rect.width - 32, 58)
                self._draw_color_selector(surface, primary_rect, "Primary colour", str(car.get("primary", "white")), vehicle_id=vehicle_id, field_name="primary")
                self._draw_color_selector(surface, secondary_rect, "Secondary colour", str(car.get("secondary", "white")), vehicle_id=vehicle_id, field_name="secondary")

                action_y = secondary_rect.bottom + 14
                reload_rect = pygame.Rect(rect.x + 16, action_y, (rect.width - 44) // 2, 42)
                remove_rect = pygame.Rect(reload_rect.right + 12, action_y, (rect.width - 44) // 2, 42)
                self._draw_button(surface, reload_rect, "Reload", action=lambda target=vehicle: self._reload_single_driver(target) if target is not None else None, fill=self.palette["surface"], radius=14)
                self._draw_button(surface, remove_rect, "Delete", action=lambda idx=vehicle_id: self._remove_driver(idx), fill=self.palette["card_alt"], outline=self.palette["danger"], text_color=self.palette["text"], radius=14)
            y = rect.bottom + self.DRIVER_CARD_GAP

        add_rect = pygame.Rect(panel.x + 24, y, card_w, self.DRIVER_ADD_BUTTON_HEIGHT)
        self._draw_button(surface, add_rect, "Add Driver", action=self._add_driver, fill=self.palette["accent"])

    def _draw_settings_panel(self, surface: pygame.Surface, *, detached: bool = False) -> None:
        if not self.settings_visible:
            return
        if self.settings_detached and not detached:
            return

        panel = self.panel_rect
        assert panel is not None
        _draw_vertical_gradient(surface, panel, (27, 30, 35), (14, 17, 21))
        pygame.draw.rect(surface, self.palette["panel_edge"], panel, width=1, border_radius=4)

        self._draw_text(surface, self.font_title, "Settings", (panel.x + 24, panel.y + 18), self.palette["text"])
        self._draw_text(surface, self.font_small, "Race controls, modes, track shaping, camera and drivers.", (panel.x + 24, panel.y + 58), self.palette["muted"])
        tabs_rect = pygame.Rect(panel.x + 24, panel.y + 90, panel.width - 48, 42)
        self._draw_tabs(surface, tabs_rect)
        content_y = tabs_rect.bottom + 18

        if self.selected_tab == "Race":
            self._draw_race_tab(surface, panel, content_y)
        elif self.selected_tab == "Track":
            self._clamp_track_scroll()
            content_clip = pygame.Rect(panel.x + 8, content_y - 6, panel.width - 16, max(0, panel.bottom - content_y - 10))
            prior_clip = surface.get_clip()
            surface.set_clip(content_clip)
            self._draw_track_tab(surface, panel, content_y - self.track_tab_scroll)
            surface.set_clip(prior_clip)
            max_scroll = self._max_track_scroll()
            if max_scroll > 0 and content_clip.height > 0:
                track_rect = pygame.Rect(panel.right - 10, content_y, 4, max(44, panel.bottom - content_y - 18))
                _rounded(surface, track_rect, self.palette["surface"], radius=4)
                thumb_height = max(42, int(track_rect.height * (content_clip.height / max(content_clip.height, self._track_content_height()))))
                thumb_span = max(0, track_rect.height - thumb_height)
                thumb_y = track_rect.y + int((self.track_tab_scroll / max_scroll) * thumb_span)
                thumb_rect = pygame.Rect(track_rect.x, thumb_y, track_rect.width, thumb_height)
                _rounded(surface, thumb_rect, self.palette["panel_edge"], radius=4)
        elif self.selected_tab == "View":
            self._draw_view_tab(surface, panel, content_y)
        elif self.selected_tab == "Drivers":
            self._clamp_drivers_scroll()
            content_clip = pygame.Rect(panel.x + 8, content_y - 6, panel.width - 16, max(0, panel.bottom - content_y - 10))
            prior_clip = surface.get_clip()
            surface.set_clip(content_clip)
            self._draw_drivers_tab(surface, panel, content_y - self.drivers_scroll)
            surface.set_clip(prior_clip)
            max_scroll = self._max_drivers_scroll()
            if max_scroll > 0 and content_clip.height > 0:
                track_rect = pygame.Rect(panel.right - 10, content_y, 4, max(44, panel.bottom - content_y - 18))
                _rounded(surface, track_rect, self.palette["surface"], radius=4)
                thumb_height = max(42, int(track_rect.height * (content_clip.height / max(content_clip.height, self._drivers_content_height()))))
                thumb_span = max(0, track_rect.height - thumb_height)
                thumb_y = track_rect.y + int((self.drivers_scroll / max_scroll) * thumb_span)
                thumb_rect = pygame.Rect(track_rect.x, thumb_y, track_rect.width, thumb_height)
                _rounded(surface, thumb_rect, self.palette["panel_edge"], radius=4)
        else:
            self._draw_modes_tab(surface, panel, content_y)

    def _layout(self, window_size: tuple[int, int]) -> tuple[pygame.Rect, pygame.Rect | None]:
        margin = 16
        embedded_panel = self.settings_visible and not self.settings_detached
        panel_width = 432 if embedded_panel else 0
        gap = 14 if embedded_panel else 0
        render_width = window_size[0] - margin * 2 - panel_width - gap
        render_rect = pygame.Rect(margin, margin, max(320, render_width), window_size[1] - margin * 2)
        panel_rect = None
        if embedded_panel:
            panel_rect = pygame.Rect(render_rect.right + gap, margin, panel_width, window_size[1] - margin * 2)
        return render_rect, panel_rect

    def _draw_detached_controls(self) -> None:
        if not self.settings_detached or not self.settings_visible:
            return
        if not self._open_controls_window() or self.controls_window is None or self.controls_renderer is None or SDLTexture is None:
            return
        try:
            self.controls_window_size = tuple(int(value) for value in self.controls_window.size)
            width = max(360, int(self.controls_window_size[0]))
            height = max(520, int(self.controls_window_size[1]))
            self.controls_window_size = (width, height)
            surface = pygame.Surface(self.controls_window_size, pygame.SRCALPHA)
            _draw_vertical_gradient(surface, surface.get_rect(), self.palette["bg_top"], self.palette["bg_bottom"])

            previous_panel = self.panel_rect
            previous_mouse = self.mouse_position
            previous_primary = self.mouse_primary_down
            previous_target = self._ui_action_target
            self.controls_ui_actions.clear()
            self.panel_rect = pygame.Rect(0, 0, width, height)
            self.mouse_position = self.controls_mouse_position
            self.mouse_primary_down = self.controls_mouse_primary_down
            self._ui_action_target = "controls"
            try:
                self._draw_settings_panel(surface, detached=True)
            finally:
                self.panel_rect = previous_panel
                self.mouse_position = previous_mouse
                self.mouse_primary_down = previous_primary
                self._ui_action_target = previous_target

            texture = SDLTexture.from_surface(self.controls_renderer, surface)
            self.controls_renderer.clear()
            self.controls_renderer.blit(texture)
            self.controls_renderer.present()
        except Exception as exc:
            self._status(f"Detached controls failed: {exc}")
            self._set_settings_detached(False)

    def _draw(self) -> None:
        assert self.window is not None
        self.ui_actions.clear()
        self.window_size = self.window.get_size()
        self.main_mouse_position = pygame.mouse.get_pos()
        self.mouse_position = self.main_mouse_position
        self.mouse_primary_down = bool(pygame.mouse.get_pressed(3)[0])
        self._ui_action_target = "main"
        self.render_rect, self.panel_rect = self._layout(self.window_size)
        _draw_vertical_gradient(self.window, self.window.get_rect(), self.palette["bg_top"], self.palette["bg_bottom"])
        self._render_scene(self.window, self.render_rect)
        self._draw_driver_name_tags(self.window)
        self._draw_fullscreen_button(self.window)
        self._draw_hud(self.window)
        self._draw_countdown_overlay(self.window)
        self._draw_settings_panel(self.window)
        self._draw_settings_handle(self.window)

        if self.pending_track_rebuild and self.settings_visible and self.selected_tab != "Track":
            badge = pygame.Rect(self.render_rect.right - 210, self.render_rect.y + 104, 190, 36)
            self.window.blit(_alpha_surface(badge.size, (255, 92, 58, 220)), badge)
            pygame.draw.rect(self.window, self.palette["accent_alt"], badge, width=1, border_radius=3)
            self._draw_text(self.window, self.font_small, "Track changes pending", (badge.x + 18, badge.y + 10), self.palette["text"])

        pygame.display.flip()
        self._draw_detached_controls()

    def run(self) -> list[VehicleRuntime]:
        if self.config.headless:
            self.awaiting_race_start = False
            self.countdown_active = False
            self.paused = False
            while self.running:
                reason = self._stop_condition()
                if reason:
                    self.stop_reason = reason
                    break
                if not self.paused:
                    self._step()
                reason = self._stop_condition()
                if reason:
                    self.stop_reason = reason
                    break
            return self._standings()

        self._ensure_pygame()
        clock = pygame.time.Clock()
        draw_accumulator = 1.0
        while self.running:
            target_loop_hz = self.config.physics_hz if not self.paused and self.stop_reason is None else self.config.scene_render_hz
            frame_dt = min(0.25, clock.tick(max(30, target_loop_hz)) / 1000.0)
            draw_accumulator += frame_dt
            self._handle_events()
            self._update_manual_controls(frame_dt)
            self._update_start_sequence(frame_dt)
            if not self.paused and self.stop_reason is None:
                reason = self._stop_condition()
                if reason:
                    self.stop_reason = reason
                    self.paused = True
                    self._draw()
                    draw_accumulator = 0.0
                    continue
                self.sim_accumulator = min(0.75, self.sim_accumulator + frame_dt * self.sim_speed)
                max_steps = max(
                    24,
                    min(
                        self.config.physics_hz,
                        int(math.ceil(self.sim_accumulator / self.model.opt.timestep)) + 4,
                    ),
                )
                steps = 0
                while self.sim_accumulator >= self.model.opt.timestep and steps < max_steps:
                    self._step()
                    self.sim_accumulator -= self.model.opt.timestep
                    steps += 1
                    reason = self._stop_condition()
                    if reason:
                        self.stop_reason = reason
                        self.paused = True
                        break
            draw_interval = 1.0 / max(1, self.config.scene_render_hz)
            if draw_accumulator >= draw_interval:
                self._draw()
                draw_accumulator = 0.0
        return self._standings()
