from __future__ import annotations

import math
from pathlib import Path
import shutil

from .track import TrackGeometry, _build_polyline_segments, _offset_closed_polyline

CAR_COLLISION_HALF_LENGTH = 0.33
CAR_COLLISION_HALF_WIDTH = 0.16
CAR_COLLISION_HALF_HEIGHT = 0.040


def _write_strip_mesh(path: Path, left, right, z: float) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for point in left:
            handle.write(f"v {point[0]:.6f} {point[1]:.6f} {z:.6f}\n")
        for point in right:
            handle.write(f"v {point[0]:.6f} {point[1]:.6f} {z:.6f}\n")

        count = len(left)
        for i in range(count):
            j = (i + 1) % count
            a = i + 1
            b = j + 1
            c = count + i + 1
            d = count + j + 1
            handle.write(f"f {a} {b} {d}\n")
            handle.write(f"f {a} {d} {c}\n")


def build_mjcf(
    *,
    session_dir: Path,
    template_dir: Path,
    geometry: TrackGeometry,
    cars: list[dict],
    rangefinders: int,
    reduced_scene_complexity: bool = False,
) -> Path:
    session_dir.mkdir(parents=True, exist_ok=True)
    icons_src = template_dir / "icons"
    icons_dst = session_dir / "icons"
    if icons_src.is_dir():
        shutil.copytree(icons_src, icons_dst, dirs_exist_ok=True)

    track_mesh = session_dir / "track_surface.obj"
    _write_strip_mesh(track_mesh, geometry.track_inner, geometry.track_outer, z=0.01)

    finish_a, finish_b = geometry.finish_line
    finish_mid = 0.5 * (finish_a + finish_b)
    finish_delta = finish_b - finish_a
    finish_yaw = math.atan2(float(finish_delta[1]), float(finish_delta[0]))
    finish_len = float((finish_delta[0] ** 2 + finish_delta[1] ** 2) ** 0.5)

    xml = []
    xml.append("<mujoco>")
    xml.append('  <compiler angle="radian" autolimits="true"/>')
    xml.append('  <option timestep="0.0083333333" gravity="0 0 -9.81"/>')
    xml.append("  <visual>")
    xml.append('    <global offwidth="4096" offheight="2160"/>')
    xml.append('    <headlight ambient="0.28 0.28 0.30" diffuse="0.66 0.66 0.68" specular="0.10 0.10 0.10"/>')
    xml.append('    <rgba haze="0.07 0.08 0.09 1"/>')
    xml.append("  </visual>")
    xml.append("  <asset>")
    xml.append('    <texture name="grass" type="2d" builtin="checker" rgb1="0.11 0.14 0.12" rgb2="0.08 0.10 0.09" width="512" height="512"/>')
    xml.append('    <material name="ground" texture="grass" texrepeat="16 16" reflectance="0.01"/>')
    xml.append('    <material name="asphalt" rgba="0.19 0.19 0.20 1.0" specular="0.03" shininess="0.08"/>')
    xml.append('    <material name="finish" rgba="0.98 0.98 0.98 1.0"/>')
    xml.append(f'    <mesh name="track_surface" file="{track_mesh.as_posix()}" inertia="shell"/>')
    icon_flags: list[bool] = []
    for i, car in enumerate(cars):
        primary = _resolve_color(car.get("primary", "red"))
        secondary = _resolve_color(car.get("secondary", "white"))
        xml.append(f'    <material name="car_{i}_primary" rgba="{primary[0]} {primary[1]} {primary[2]} 1"/>')
        xml.append(f'    <material name="car_{i}_secondary" rgba="{secondary[0]} {secondary[1]} {secondary[2]} 1"/>')
        xml.append(f'    <material name="car_{i}_wheel" rgba="0.08 0.08 0.08 1"/>')
        icon_name = car.get("icon") or ""
        has_icon = bool(icon_name and (icons_dst / icon_name).is_file())
        icon_flags.append(has_icon)
        if has_icon:
            xml.append(f'    <texture type="2d" name="car_{i}_icon_tex" file="{(icons_dst / icon_name).as_posix()}"/>')
            xml.append(f'    <material name="car_{i}_icon" texture="car_{i}_icon_tex" rgba="1 1 1 1"/>')
    xml.append("  </asset>")
    xml.append("  <worldbody>")
    xml.append('    <light pos="0 0 18" dir="0 0 -1" diffuse="0.85 0.85 0.85"/>')
    xml.append('    <geom name="ground" type="plane" size="180 180 0.1" pos="0 0 0" material="ground" friction="1.4 0.01 0.01"/>')
    xml.append('    <geom name="track_visual" type="mesh" mesh="track_surface" material="asphalt" contype="0" conaffinity="0"/>')
    xml.append(
        f'    <geom name="finish_line" type="box" size="{finish_len * 0.5:.6f} 0.05 0.002" '
        f'pos="{finish_mid[0]:.6f} {finish_mid[1]:.6f} 0.013" euler="0 0 {finish_yaw:.6f}" material="finish" contype="0" conaffinity="0"/>'
    )

    curb_segments, wall_segments = _scene_visual_segments(geometry, reduced_scene_complexity=reduced_scene_complexity)

    for index, segment in enumerate(curb_segments):
        xml.append(
            f'    <geom name="curb_{index}" type="box" size="{segment.size[0]:.6f} {segment.size[1]:.6f} {segment.size[2]:.6f}" '
            f'pos="{segment.position[0]:.6f} {segment.position[1]:.6f} {segment.position[2]:.6f}" euler="0 0 {segment.yaw:.6f}" '
            f'rgba="{segment.rgba[0]:.4f} {segment.rgba[1]:.4f} {segment.rgba[2]:.4f} {segment.rgba[3]:.4f}" contype="0" conaffinity="0"/>'
        )

    for index, segment in enumerate(wall_segments):
        xml.append(
            f'    <geom name="wall_{index}" type="box" size="{segment.size[0]:.6f} {segment.size[1]:.6f} {segment.size[2]:.6f}" '
            f'pos="{segment.position[0]:.6f} {segment.position[1]:.6f} {segment.position[2]:.6f}" euler="0 0 {segment.yaw:.6f}" '
            f'rgba="{segment.rgba[0]:.4f} {segment.rgba[1]:.4f} {segment.rgba[2]:.4f} {segment.rgba[3]:.4f}" friction="0.9 0.01 0.01"/>'
        )

    for i, car in enumerate(cars):
        xml.extend(_car_body_xml(i=i, name=car.get("name", f"car {i}"), rangefinders=rangefinders, has_icon=icon_flags[i]))
    xml.append("  </worldbody>")
    xml.append("  <sensor>")
    for i, _car in enumerate(cars):
        for j in range(rangefinders):
            xml.append(f'    <rangefinder name="rangefinder_{i}_{j}" site="rangefinder_{i}_{j}"/>')
    xml.append("  </sensor>")
    xml.append("</mujoco>")

    mjcf_path = session_dir / "world.xml"
    mjcf_path.write_text("\n".join(xml), encoding="utf-8")
    return mjcf_path


def _scene_visual_segments(geometry: TrackGeometry, *, reduced_scene_complexity: bool) -> tuple[list, list]:
    if not reduced_scene_complexity:
        return geometry.curb_segments, geometry.wall_segments

    wall_mid_offset = geometry.settings.half_width + geometry.settings.curb_width + geometry.settings.wall_gap + geometry.settings.wall_thickness * 0.5
    wall_panel_length = geometry.settings.panel_length * 2.4
    curb_panel_length = geometry.settings.panel_length * 1.9
    wall_colors = ((0.80, 0.82, 0.84, 1.0), (0.69, 0.72, 0.75, 1.0))
    curb_colors = ((0.73, 0.12, 0.10, 1.0), (0.93, 0.93, 0.92, 1.0))

    wall_segments = _build_polyline_segments(
        points=_offset_closed_polyline(geometry.centerline, wall_mid_offset),
        width=geometry.settings.wall_thickness,
        height=geometry.settings.wall_height,
        panel_length=wall_panel_length,
        colors=wall_colors,
    ) + _build_polyline_segments(
        points=_offset_closed_polyline(geometry.centerline, -wall_mid_offset),
        width=geometry.settings.wall_thickness,
        height=geometry.settings.wall_height,
        panel_length=wall_panel_length,
        colors=wall_colors,
    )

    curb_segments = _build_polyline_segments(
        points=geometry.outer_curb,
        width=geometry.settings.curb_width,
        height=geometry.settings.curb_height,
        panel_length=curb_panel_length,
        colors=curb_colors,
    ) + _build_polyline_segments(
        points=geometry.inner_curb,
        width=geometry.settings.curb_width,
        height=geometry.settings.curb_height,
        panel_length=curb_panel_length,
        colors=curb_colors,
    )
    return curb_segments, wall_segments


def _car_body_xml(*, i: int, name: str, rangefinders: int, has_icon: bool) -> list[str]:
    inter_ray_angle = 360.0 / rangefinders
    rx, ry, rz = -0.04, 0.0, 0.12
    lr = 0.03
    lines = [
        f'    <body name="car_{i}" pos="0 0 0.08">',
        f'      <freejoint name="car_{i}"/>',
        f'      <geom name="car_{i}_collision" type="box" size="{CAR_COLLISION_HALF_LENGTH:.3f} {CAR_COLLISION_HALF_WIDTH:.3f} {CAR_COLLISION_HALF_HEIGHT:.3f}" rgba="0 0 0 0" mass="3.0" friction="1.4 0.01 0.01"/>',
        f'      <geom name="car_{i}_floor" type="box" size="0.33 0.15 0.012" pos="0 0 0.018" rgba="0.10 0.10 0.10 1" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_pod_l" type="box" size="0.15 0.05 0.026" pos="0.03 0.095 0.043" material="car_{i}_primary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_pod_r" type="box" size="0.15 0.05 0.026" pos="0.03 -0.095 0.043" material="car_{i}_primary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_spine" type="box" size="0.20 0.045 0.030" pos="0.01 0 0.055" material="car_{i}_primary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_nose" type="box" size="0.15 0.032 0.020" pos="0.28 0 0.042" material="car_{i}_secondary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_cockpit" type="box" size="0.08 0.055 0.024" pos="-0.03 0 0.066" rgba="0.12 0.13 0.14 1" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_front_wing" type="box" size="0.06 0.21 0.006" pos="0.37 0 0.020" material="car_{i}_secondary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_rear_wing" type="box" size="0.04 0.18 0.028" pos="-0.31 0 0.085" material="car_{i}_secondary" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_fl" type="cylinder" size="0.055 0.020" pos="0.18 0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_fr" type="cylinder" size="0.055 0.020" pos="0.18 -0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_bl" type="cylinder" size="0.058 0.022" pos="-0.16 0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_wheel_br" type="cylinder" size="0.058 0.022" pos="-0.16 -0.16 0.024" euler="1.5708 0 0" material="car_{i}_wheel" contype="0" conaffinity="0"/>',
        f'      <geom name="car_{i}_lidar" type="cylinder" size="0.032 0.010" pos="{rx:.6f} {ry:.6f} {rz:.6f}" rgba="0.88 0.88 0.88 1" contype="0" conaffinity="0"/>',
    ]
    if has_icon:
        lines.append(f'      <site type="ellipsoid" size="0.032 0.032 0.003" pos="{rx:.6f} {ry:.6f} {rz + 0.016:.6f}" material="car_{i}_icon"/>')
    for j in range(rangefinders):
        angle_deg = inter_ray_angle * j - 90.0
        theta = -math.radians(angle_deg)
        lines.append(
            f'      <site name="rangefinder_{i}_{j}" pos="{rx + lr * math.sin(theta):.6f} {lr * math.cos(theta):.6f} {rz:.6f}" '
            f'euler="{math.radians(90):.6f} {math.radians(angle_deg):.6f} 0" rgba="0 0 0 0"/>'
        )
    lines.append("    </body>")
    return lines


def _resolve_color(value) -> tuple[float, float, float]:
    if isinstance(value, (list, tuple)) and len(value) >= 3:
        return float(value[0]) / 255.0, float(value[1]) / 255.0, float(value[2]) / 255.0
    lookup = {
        "trinityred": (0.694, 0.165, 0.137),
        "orangered": (1.0, 0.27, 0.0),
        "crimson": (0.80, 0.14, 0.25),
        "dodgerblue": (0.12, 0.56, 1.0),
        "royalblue": (0.25, 0.41, 0.88),
        "mediumseagreen": (0.24, 0.70, 0.44),
        "forestgreen": (0.16, 0.46, 0.31),
        "gold": (1.0, 0.84, 0.0),
        "amber": (0.87, 0.56, 0.16),
        "silver": (0.69, 0.71, 0.73),
        "white": (1.0, 1.0, 1.0),
        "red": (1.0, 0.0, 0.0),
        "black": (0.0, 0.0, 0.0),
    }
    return lookup.get(str(value).lower(), (1.0, 1.0, 1.0))
