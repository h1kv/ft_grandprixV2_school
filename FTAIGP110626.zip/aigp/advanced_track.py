from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math
from pathlib import Path
import tomllib

import numpy as np
import pygame

from .track import DEFAULT_TRACKS, SegmentStyle, TrackGeometry, TrackSettings, load_track_geometry


DEFAULT_ADVANCED_TRACK = "alpine"
MIN_TERRAIN_MESH_RESOLUTION = 16
MAX_TERRAIN_MESH_RESOLUTION = 160


def _clip(value: float, lower: float, upper: float) -> float:
    return lower if value < lower else upper if value > upper else value


def _unit(vector: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if norm <= 1e-9:
        return np.array([1.0, 0.0, 0.0], dtype=np.float32)
    return (vector / norm).astype(np.float32)


def _smooth_circular(values: np.ndarray, window: int) -> np.ndarray:
    if window <= 1:
        return values.astype(np.float32, copy=True)
    if window % 2 == 0:
        window += 1
    pad = window // 2
    padded = np.concatenate([values[-pad:], values, values[:pad]])
    kernel = np.ones(window, dtype=np.float32) / float(window)
    return np.convolve(padded, kernel, mode="valid").astype(np.float32)


def _smoothing_window(count: int, strength: float) -> int:
    if count <= 3:
        return 1
    strength = _clip(float(strength), 0.0, 1.0)
    if strength <= 1e-4:
        return 1
    return max(3, int(round(1 + strength * min(51, max(5, count * 0.08)))))


@dataclass(slots=True)
class CurvePoint:
    progress: float
    value: float


@dataclass(slots=True)
class AdvancedTrackSpec:
    name: str
    display_name: str
    base_track: str
    preview_path: Path | None
    defaults: dict[str, float]
    elevation_points: list[CurvePoint]
    bank_points: list[CurvePoint]
    terrain_heightmap_path: Path | None
    terrain_world_size: float
    terrain_height_scale: float
    terrain_mesh_resolution: int


@dataclass(slots=True)
class AdvancedSurfaceSample:
    progress: float
    signed_offset: float
    height: float
    pitch: float
    roll: float
    grade: float
    bank: float
    tangent3d: np.ndarray
    lateral3d: np.ndarray
    up3d: np.ndarray
    terrain_mix: float
    roughness: float
    vertical_curvature: float
    grounded: bool


@dataclass(slots=True)
class AdvancedTrackWorld:
    spec: AdvancedTrackSpec
    settings: TrackSettings
    base_geometry: TrackGeometry
    centerline_heights: np.ndarray
    bank_angles: np.ndarray
    vertical_curvature: np.ndarray
    road_centerline_3d: np.ndarray
    track_inner_3d: np.ndarray
    track_outer_3d: np.ndarray
    inner_curb_3d: np.ndarray
    outer_curb_3d: np.ndarray
    inner_wall_3d: np.ndarray
    outer_wall_3d: np.ndarray
    terrain_heightmap: np.ndarray | None
    terrain_bounds: tuple[np.ndarray, np.ndarray]
    terrain_height_scale: float

    @property
    def preview_path(self) -> Path | None:
        return self.spec.preview_path

    @property
    def display_name(self) -> str:
        return self.spec.display_name

    def _progress_frame(self, progress: float) -> tuple[int, float, np.ndarray, np.ndarray, float, float, float]:
        return _road_frame(self.base_geometry, self.centerline_heights, self.bank_angles, progress)

    def _frame_at_progress(
        self,
        progress: float,
        *,
        index_hint: int | None = None,
    ) -> tuple[int, float, np.ndarray, np.ndarray, float, float, float]:
        return _road_frame(
            self.base_geometry,
            self.centerline_heights,
            self.bank_angles,
            progress,
            index_hint=index_hint,
        )

    def _terrain_height(self, xy: np.ndarray) -> float | None:
        if self.terrain_heightmap is None:
            return None
        minimum, maximum = self.terrain_bounds
        span = np.maximum(maximum - minimum, 1e-6)
        u = _clip((float(xy[0]) - float(minimum[0])) / float(span[0]), 0.0, 1.0)
        v = _clip((float(xy[1]) - float(minimum[1])) / float(span[1]), 0.0, 1.0)
        heightmap = self.terrain_heightmap
        x = u * (heightmap.shape[1] - 1)
        y = (1.0 - v) * (heightmap.shape[0] - 1)
        x0 = int(math.floor(x))
        x1 = min(heightmap.shape[1] - 1, x0 + 1)
        y0 = int(math.floor(y))
        y1 = min(heightmap.shape[0] - 1, y0 + 1)
        tx = x - x0
        ty = y - y0
        row0 = (1.0 - tx) * heightmap[y0, x0] + tx * heightmap[y0, x1]
        row1 = (1.0 - tx) * heightmap[y1, x0] + tx * heightmap[y1, x1]
        return float(((1.0 - ty) * row0 + ty * row1) * self.terrain_height_scale)

    def sample_surface(
        self,
        position: np.ndarray,
        *,
        hint_progress: float | None = None,
    ) -> AdvancedSurfaceSample:
        index, center_xy, tangent2d, signed_offset, progress = self.base_geometry.project(
            position.astype(np.float32),
            hint_progress=hint_progress,
        )
        return self.sample_surface_at_progress(
            progress,
            lateral_offset=signed_offset,
            xy=position.astype(np.float32),
            index_hint=index,
        )

    def sample_surface_at_progress(
        self,
        progress: float,
        *,
        lateral_offset: float = 0.0,
        xy: np.ndarray | None = None,
        index_hint: int | None = None,
    ) -> AdvancedSurfaceSample:
        wrapped = progress % self.base_geometry.total_length
        index, alpha, center_xy, tangent2d, center_height, bank, grade = self._frame_at_progress(
            wrapped,
            index_hint=index_hint,
        )
        next_index = (index + 1) % len(self.base_geometry.centerline)

        normal2d = np.array([-tangent2d[1], tangent2d[0]], dtype=np.float32)
        tangent3d = _unit(np.array([tangent2d[0], tangent2d[1], grade], dtype=np.float32))
        lateral3d = _unit(np.array([normal2d[0] * math.cos(bank), normal2d[1] * math.cos(bank), math.sin(bank)], dtype=np.float32))
        up3d = _unit(np.cross(tangent3d, lateral3d))
        road_height = center_height + float(lateral_offset) * math.sin(bank)
        pitch = math.atan2(float(tangent3d[2]), max(1e-6, math.hypot(float(tangent3d[0]), float(tangent3d[1]))))

        xy_point = center_xy + normal2d * float(lateral_offset) if xy is None else xy.astype(np.float32)
        terrain_height = self._terrain_height(xy_point)
        roughness = 0.0
        terrain_mix = 0.0
        final_height = road_height
        road_limit = self.settings.half_width + self.settings.curb_width
        if abs(lateral_offset) > self.settings.half_width:
            roughness = _clip((abs(lateral_offset) - self.settings.half_width) / max(0.25, self.settings.terrain_blend_radius), 0.0, 1.0)
        if terrain_height is not None and abs(lateral_offset) > road_limit:
            terrain_mix = _clip((abs(lateral_offset) - road_limit) / max(0.25, self.settings.terrain_blend_radius), 0.0, 1.0)
            final_height = road_height + (terrain_height - road_height) * terrain_mix
        elif terrain_height is not None and abs(lateral_offset) > self.settings.half_width:
            terrain_mix = _clip((abs(lateral_offset) - self.settings.half_width) / max(0.25, self.settings.terrain_blend_radius), 0.0, 0.45)
            final_height = road_height + (terrain_height - road_height) * terrain_mix
        vertical_curvature = float(
            (1.0 - alpha) * self.vertical_curvature[index]
            + alpha * self.vertical_curvature[next_index]
        )

        return AdvancedSurfaceSample(
            progress=wrapped,
            signed_offset=float(lateral_offset),
            height=float(final_height),
            pitch=float(pitch),
            roll=float(bank),
            grade=float(grade),
            bank=float(bank),
            tangent3d=tangent3d,
            lateral3d=lateral3d,
            up3d=up3d,
            terrain_mix=float(terrain_mix),
            roughness=float(max(roughness, terrain_mix)),
            vertical_curvature=vertical_curvature,
            grounded=True,
        )

    def terrain_render_height(self, xy: np.ndarray) -> float | None:
        terrain_height = self._terrain_height(np.asarray(xy, dtype=np.float32))
        if terrain_height is None:
            return None
        index, _point, _tangent, signed_offset, progress = self.base_geometry.project(np.asarray(xy, dtype=np.float32))
        _frame_index, _alpha, _center_xy, _tangent2d, center_height, bank, _grade = self._frame_at_progress(
            progress,
            index_hint=index,
        )
        road_height = center_height + float(signed_offset) * math.sin(bank)
        clearance = 0.12
        road_limit = self.settings.half_width + self.settings.curb_width
        carve_limit = road_limit + self.settings.wall_gap + self.settings.wall_thickness + 0.08
        blend_limit = carve_limit + max(0.5, float(self.settings.terrain_blend_radius))
        offset = abs(float(signed_offset))
        lowered = min(float(terrain_height), float(road_height) - clearance)
        if offset <= carve_limit:
            return lowered
        if offset >= blend_limit:
            return float(terrain_height)
        alpha = (offset - carve_limit) / max(0.25, blend_limit - carve_limit)
        return float(lowered + (float(terrain_height) - lowered) * alpha)

    def terrain_grid(self) -> tuple[np.ndarray, np.ndarray, np.ndarray] | None:
        if self.terrain_heightmap is None:
            return None
        resolution = max(12, self.spec.terrain_mesh_resolution)
        minimum, maximum = self.terrain_bounds
        xs = np.linspace(float(minimum[0]), float(maximum[0]), resolution, dtype=np.float32)
        ys = np.linspace(float(minimum[1]), float(maximum[1]), resolution, dtype=np.float32)
        grid_x = np.empty((resolution, resolution), dtype=np.float32)
        grid_y = np.empty((resolution, resolution), dtype=np.float32)
        grid_z = np.empty((resolution, resolution), dtype=np.float32)
        for row, y in enumerate(ys):
            for col, x in enumerate(xs):
                grid_x[row, col] = x
                grid_y[row, col] = y
                grid_z[row, col] = float(self.terrain_render_height(np.array([x, y], dtype=np.float32)) or 0.0)
        return grid_x, grid_y, grid_z


def advanced_root(template_dir: Path) -> Path:
    return template_dir / "advanced"


def discover_advanced_tracks(template_dir: Path) -> list[str]:
    root = advanced_root(template_dir)
    if not root.is_dir():
        return []
    names: list[str] = []
    for path in sorted(root.iterdir()):
        if not path.is_dir():
            continue
        if (path / "advanced.toml").is_file():
            names.append(path.name)
    return names


def load_advanced_track_spec(template_dir: Path, name: str) -> AdvancedTrackSpec:
    return _load_advanced_track_spec_cached(str(template_dir.resolve()), name)


@lru_cache(maxsize=64)
def _load_advanced_track_spec_cached(template_dir: str, name: str) -> AdvancedTrackSpec:
    folder = Path(template_dir) / "advanced" / name
    sidecar = folder / "advanced.toml"
    if not sidecar.is_file():
        raise ValueError(f"Advanced track '{name}' is missing {sidecar.name}")
    data = tomllib.loads(sidecar.read_text(encoding="utf-8"))
    base_track = str(data.get("base_track", "")).strip()
    if not base_track:
        raise ValueError(f"Advanced track '{name}' must define base_track")
    display_name = str(data.get("display_name", name)).strip() or name
    preview_name = str(data.get("preview", "preview.png")).strip() or "preview.png"
    preview_path = folder / preview_name
    defaults = dict(data.get("defaults", {}))
    terrain = data.get("terrain", {})
    elevation_points = _parse_curve_points(data.get("elevation", {}).get("points", ()), "height")
    bank_points = _parse_curve_points(data.get("bank", {}).get("points", ()), "degrees")
    heightmap_name = str(terrain.get("heightmap", "")).strip()
    heightmap_path = folder / heightmap_name if heightmap_name else None
    if heightmap_path is not None and not heightmap_path.is_file():
        raise ValueError(f"Advanced track '{name}' heightmap '{heightmap_name}' was not found")
    terrain_mesh_resolution = int(terrain.get("mesh_resolution", 48))
    if not MIN_TERRAIN_MESH_RESOLUTION <= terrain_mesh_resolution <= MAX_TERRAIN_MESH_RESOLUTION:
        raise ValueError(
            f"Advanced track '{name}' terrain mesh_resolution must be between "
            f"{MIN_TERRAIN_MESH_RESOLUTION} and {MAX_TERRAIN_MESH_RESOLUTION}"
        )
    return AdvancedTrackSpec(
        name=name,
        display_name=display_name,
        base_track=base_track,
        preview_path=preview_path if preview_path.is_file() else None,
        defaults=defaults,
        elevation_points=elevation_points,
        bank_points=bank_points,
        terrain_heightmap_path=heightmap_path,
        terrain_world_size=float(terrain.get("world_size", 64.0)),
        terrain_height_scale=float(terrain.get("height_scale", 5.0)),
        terrain_mesh_resolution=terrain_mesh_resolution,
    )


def default_track_settings_for_advanced(template_dir: Path, name: str) -> TrackSettings:
    spec = load_advanced_track_spec(template_dir, name)
    defaults = DEFAULT_TRACKS.get(spec.base_track, TrackSettings(name=spec.base_track)).copy()
    for key, value in spec.defaults.items():
        if hasattr(defaults, key):
            setattr(defaults, key, value)
    defaults.name = name
    return defaults


def load_advanced_world(template_dir: Path, settings: TrackSettings) -> tuple[TrackGeometry, AdvancedTrackWorld]:
    spec = load_advanced_track_spec(template_dir, settings.name)
    base_settings = settings.copy()
    base_settings.name = spec.base_track
    base_geometry = load_track_geometry(template_dir, base_settings)
    center_heights = _sample_curve(spec.elevation_points, base_geometry) * float(settings.elevation_scale)
    bank_angles = np.radians(_sample_curve(spec.bank_points, base_geometry) * float(settings.bank_scale)).astype(np.float32)

    height_window = _smoothing_window(len(center_heights), settings.road_height_smoothing)
    bank_window = _smoothing_window(len(bank_angles), settings.bank_smoothing)
    center_heights = _smooth_circular(center_heights, height_window)
    bank_angles = _smooth_circular(bank_angles, bank_window)
    vertical_curvature = _vertical_curvature(center_heights, base_geometry).astype(np.float32)

    base_geometry.wall_segments = _build_advanced_wall_segments(base_geometry)

    road_centerline_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.centerline)
    track_inner_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.track_inner)
    track_outer_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.track_outer)
    inner_curb_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.inner_curb)
    outer_curb_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.outer_curb)
    inner_wall_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.inner_wall_face)
    outer_wall_3d = _lift_polyline_to_road(base_geometry, center_heights, bank_angles, base_geometry.outer_wall_face)

    terrain_heightmap = _load_heightmap(spec.terrain_heightmap_path)
    bounds_points = np.vstack([base_geometry.track_inner, base_geometry.track_outer])
    minimum = bounds_points.min(axis=0).astype(np.float32)
    maximum = bounds_points.max(axis=0).astype(np.float32)
    span = np.maximum(maximum - minimum, 1e-3)
    terrain_size = max(float(spec.terrain_world_size), float(max(span)) + max(12.0, settings.terrain_blend_radius * 4.0))
    center = base_geometry.center.astype(np.float32)
    half = np.array([terrain_size * 0.5, terrain_size * 0.5], dtype=np.float32)

    world = AdvancedTrackWorld(
        spec=spec,
        settings=settings.copy(),
        base_geometry=base_geometry,
        centerline_heights=center_heights.astype(np.float32),
        bank_angles=bank_angles.astype(np.float32),
        vertical_curvature=vertical_curvature,
        road_centerline_3d=road_centerline_3d,
        track_inner_3d=track_inner_3d,
        track_outer_3d=track_outer_3d,
        inner_curb_3d=inner_curb_3d,
        outer_curb_3d=outer_curb_3d,
        inner_wall_3d=inner_wall_3d,
        outer_wall_3d=outer_wall_3d,
        terrain_heightmap=terrain_heightmap,
        terrain_bounds=(center - half, center + half),
        terrain_height_scale=float(spec.terrain_height_scale) * float(settings.terrain_height_scale),
    )
    return base_geometry, world


def _parse_curve_points(raw_points, value_key: str) -> list[CurvePoint]:
    points: list[CurvePoint] = []
    seen: set[float] = set()
    for item in raw_points:
        if not isinstance(item, dict):
            continue
        if "progress" not in item or value_key not in item:
            continue
        progress = float(item["progress"])
        if not math.isfinite(progress):
            raise ValueError(f"Advanced curve progress must be finite")
        if progress < -1e-6 or progress > 1.0 + 1e-6:
            raise ValueError("Advanced curve progress values must stay between 0.0 and 1.0")
        progress = 0.0 if abs(progress) <= 1e-6 else 1.0 if abs(progress - 1.0) <= 1e-6 else progress
        key = round(progress, 6)
        if key in seen:
            raise ValueError(f"Advanced curve contains duplicate progress value {progress:.6f}")
        seen.add(key)
        points.append(CurvePoint(progress=progress, value=float(item[value_key])))
    if not points:
        return [CurvePoint(0.0, 0.0), CurvePoint(1.0, 0.0)]
    points.sort(key=lambda point: point.progress)
    if points[0].progress > 1e-5:
        points.insert(0, CurvePoint(0.0, points[0].value))
    if points[-1].progress < 1.0 - 1e-5:
        points.append(CurvePoint(1.0, points[0].value))
    return points


def _sample_curve(points: list[CurvePoint], geometry: TrackGeometry) -> np.ndarray:
    if not points:
        return np.zeros(len(geometry.centerline), dtype=np.float32)
    progress_values = (geometry.cumulative_lengths[:-1] / max(1e-6, geometry.total_length)).astype(np.float32)
    xs = np.array([point.progress for point in points], dtype=np.float32)
    ys = np.array([point.value for point in points], dtype=np.float32)
    return np.interp(progress_values, xs, ys).astype(np.float32)


def _vertical_curvature(heights: np.ndarray, geometry: TrackGeometry) -> np.ndarray:
    count = len(heights)
    if count <= 2:
        return np.zeros(count, dtype=np.float32)
    segment_lengths = np.diff(geometry.cumulative_lengths).astype(np.float32)
    curvature = np.zeros(count, dtype=np.float32)
    for index in range(count):
        prev_index = (index - 1) % count
        next_index = (index + 1) % count
        ds_prev = max(1e-4, float(segment_lengths[prev_index]))
        ds_next = max(1e-4, float(segment_lengths[index]))
        slope_prev = (float(heights[index]) - float(heights[prev_index])) / ds_prev
        slope_next = (float(heights[next_index]) - float(heights[index])) / ds_next
        curvature[index] = float(2.0 * (slope_next - slope_prev) / max(1e-4, ds_prev + ds_next))
    return curvature


def _road_frame(
    geometry: TrackGeometry,
    heights: np.ndarray,
    bank_angles: np.ndarray,
    progress: float,
    *,
    index_hint: int | None = None,
) -> tuple[int, float, np.ndarray, np.ndarray, float, float, float]:
    wrapped = progress % geometry.total_length
    if index_hint is None:
        index = int(np.searchsorted(geometry.cumulative_lengths, wrapped, side="right") - 1)
        index = max(0, min(index, len(geometry.centerline) - 1))
    else:
        index = int(max(0, min(index_hint, len(geometry.centerline) - 1)))
    next_index = (index + 1) % len(geometry.centerline)
    start = geometry.centerline[index]
    end = geometry.centerline[next_index]
    delta = end - start
    segment_length = max(1e-6, float(np.linalg.norm(delta)))
    local_distance = wrapped - float(geometry.cumulative_lengths[index])
    alpha = _clip(local_distance / segment_length, 0.0, 1.0)
    center_xy = start + delta * alpha
    tangent2d = (delta / segment_length).astype(np.float32)
    center_height = float((1.0 - alpha) * heights[index] + alpha * heights[next_index])
    bank = float((1.0 - alpha) * bank_angles[index] + alpha * bank_angles[next_index])
    if not math.isfinite(bank):
        bank = 0.0
    grade = float((heights[next_index] - heights[index]) / segment_length)
    return index, alpha, center_xy.astype(np.float32), tangent2d, center_height, bank, grade


def _lift_polyline_to_road(
    geometry: TrackGeometry,
    heights: np.ndarray,
    bank_angles: np.ndarray,
    polyline_xy: np.ndarray,
) -> np.ndarray:
    xy_points = np.asarray(polyline_xy, dtype=np.float32)
    if len(xy_points) != len(geometry.centerline):
        raise ValueError("advanced boundary lifting expects index-aligned polyline data")
    points = np.empty((len(xy_points), 3), dtype=np.float32)
    for index, xy in enumerate(xy_points):
        center_xy = geometry.centerline[index]
        lateral_offset = float(np.dot(xy - center_xy, geometry.normals[index]))
        center_height = float(heights[index])
        bank = float(bank_angles[index])
        points[index] = np.array(
            [
                xy[0],
                xy[1],
                center_height + lateral_offset * math.sin(bank),
            ],
            dtype=np.float32,
        )
    return points


def _build_advanced_wall_segments(geometry: TrackGeometry) -> list[SegmentStyle]:
    colors = ((0.80, 0.82, 0.84, 1.0), (0.69, 0.72, 0.75, 1.0))
    segments: list[SegmentStyle] = []
    segments.extend(_build_wall_face_segments(geometry, geometry.outer_wall_face, colors))
    segments.extend(_build_wall_face_segments(geometry, geometry.inner_wall_face, colors))
    return segments


def _build_wall_face_segments(
    geometry: TrackGeometry,
    face_points: np.ndarray,
    colors: tuple[tuple[float, float, float, float], tuple[float, float, float, float]],
) -> list[SegmentStyle]:
    segments: list[SegmentStyle] = []
    distance_accum = 0.0
    half_thickness = float(geometry.settings.wall_thickness) * 0.5
    half_height = float(geometry.settings.wall_height) * 0.5
    count = len(face_points)
    for index in range(count):
        face_a = np.asarray(face_points[index], dtype=np.float32)
        face_b = np.asarray(face_points[(index + 1) % count], dtype=np.float32)
        delta = face_b - face_a
        length = float(np.linalg.norm(delta))
        if length <= 1e-5:
            continue
        tangent = (delta / length).astype(np.float32)
        segment_normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        face_mid = 0.5 * (face_a + face_b)
        center_mid = 0.5 * (
            np.asarray(geometry.centerline[index], dtype=np.float32)
            + np.asarray(geometry.centerline[(index + 1) % count], dtype=np.float32)
        )
        outward_hint = face_mid - center_mid
        outward_sign = 1.0 if float(np.dot(segment_normal, outward_hint)) >= 0.0 else -1.0
        center = face_mid + segment_normal * (outward_sign * half_thickness)
        rgba = colors[int(distance_accum / max(0.45, float(geometry.settings.panel_length))) % 2]
        segments.append(
            SegmentStyle(
                position=np.array([center[0], center[1], half_height], dtype=np.float32),
                size=np.array([length * 0.5, half_thickness, half_height], dtype=np.float32),
                yaw=math.atan2(float(tangent[1]), float(tangent[0])),
                rgba=rgba,
            )
        )
        distance_accum += length
    return segments


def _load_heightmap(path: Path | None) -> np.ndarray | None:
    if path is None or not path.is_file():
        return None
    return _load_heightmap_cached(str(path.resolve()))


@lru_cache(maxsize=32)
def _load_heightmap_cached(path: str) -> np.ndarray | None:
    resolved = Path(path)
    if not resolved.is_file():
        return None
    surface = pygame.image.load(str(resolved))
    pixels = pygame.surfarray.array3d(surface).astype(np.float32)
    return (pixels.mean(axis=2).T / 255.0).astype(np.float32)
