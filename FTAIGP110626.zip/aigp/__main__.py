from __future__ import annotations

import argparse
from pathlib import Path
import sys
import tomllib

from .advanced_track import DEFAULT_ADVANCED_TRACK
from .app import DEFAULT_CARS_PATH, RACE_MODE_INFO, RaceApp, RaceConfig
from .scaffold import create_driver_file


COMMANDS = {"race", "batch", "create-driver"}
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = RaceConfig()
DEFAULT_RUNTIME_CONFIG_PATH = PROJECT_ROOT / "aigp.runtime.toml"
RUNTIME_CONFIG_FIELDS = {
    "physics_hz",
    "sensor_hz",
    "scene_render_hz",
    "render_scale",
    "reduced_scene_complexity",
    "world_mode",
    "default_advanced_track",
}


def _resolve_runtime_config_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else PROJECT_ROOT / path


def _load_runtime_overrides(config_path: str) -> dict:
    path = _resolve_runtime_config_path(config_path)
    if not path.is_file():
        return {}
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"Invalid runtime config TOML in {path}: {exc}") from exc
    section = data.get("runtime", data)
    if not isinstance(section, dict):
        raise ValueError(f"Runtime config in {path} must be a TOML table")
    unknown = sorted(set(section.keys()) - RUNTIME_CONFIG_FIELDS)
    if unknown:
        raise ValueError(f"Unknown runtime config field(s) in {path}: {', '.join(unknown)}")
    return {key: section[key] for key in RUNTIME_CONFIG_FIELDS if key in section}


def add_race_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--track", default=argparse.SUPPRESS, help="track name from template/*.png or template/advanced/*")
    parser.add_argument("--cars", dest="cars_path", default=argparse.SUPPRESS, help="cars configuration JSON")
    parser.add_argument("--driver", action="append", default=[], help="driver file(s) for a quick ad-hoc race grid")
    parser.add_argument("--drivers-dir", default="drivers", help="driver directory at the root of AIGPV2")
    parser.add_argument("--config", default=str(DEFAULT_RUNTIME_CONFIG_PATH), help="runtime TOML config file")
    parser.add_argument("--world-mode", choices=("standard", "advanced"), default=argparse.SUPPRESS, help="boot the standard flat runtime or advanced 3D mode")
    parser.add_argument("--advanced", action="store_true", help="shorthand for --world-mode advanced")
    parser.add_argument("--race-mode", choices=sorted(RACE_MODE_INFO.keys()), default="grand_prix", help="standings and challenge mode")
    parser.add_argument("--physics-hz", type=int, default=argparse.SUPPRESS, help="simulation rate; changes driving behavior")
    parser.add_argument("--sensor-hz", type=int, default=argparse.SUPPRESS, help="lidar refresh rate; changes driver observations")
    parser.add_argument("--scene-render-hz", type=int, default=argparse.SUPPRESS, help="visual scene render cap")
    parser.add_argument("--render-scale", type=float, default=argparse.SUPPRESS, help="internal MuJoCo render scale")
    parser.add_argument("--scene-complexity", choices=("full", "reduced"), default=argparse.SUPPRESS, help="scene geometry detail preset")
    parser.add_argument("--lap-target", type=int, default=10, help="lap target")
    parser.add_argument("--rangefinders", type=int, default=90, help="number of lidar rays")
    parser.add_argument("--headless", action="store_true", help="run without opening the 3D viewer")
    parser.add_argument("--max-steps", type=int, default=0, help="stop after N simulation steps")
    parser.add_argument("--max-time", type=float, default=0.0, help="stop after N simulated seconds")
    parser.add_argument("--results-json", default="", help="optional JSON race report path")
    parser.add_argument("--results-csv", default="", help="optional CSV standings path")
    parser.add_argument("--no-auto-reload", action="store_true", help="disable auto-reload on driver file changes")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="AIGPV2 Formula Trinity GP runtime", allow_abbrev=False)
    subparsers = parser.add_subparsers(dest="command")

    race_parser = subparsers.add_parser("race", help="run a single race", allow_abbrev=False)
    add_race_args(race_parser)

    batch_parser = subparsers.add_parser("batch", help="run a headless batch over discovered drivers", allow_abbrev=False)
    add_race_args(batch_parser)
    batch_parser.set_defaults(headless=True)
    batch_parser.add_argument("--pattern", default="*.py", help="glob used to discover drivers")

    create_parser = subparsers.add_parser("create-driver", help="create a new single-file driver scaffold", allow_abbrev=False)
    create_parser.add_argument("name", help="driver filename or stem")
    create_parser.add_argument("--output", default="", help="optional explicit output path")
    create_parser.add_argument("--force", action="store_true", help="overwrite an existing file")
    return parser


def _normalize_argv(argv: list[str]) -> list[str]:
    if not argv or argv[0].startswith("-") or argv[0] not in COMMANDS:
        return ["race", *argv]
    return argv


def _build_config(args: argparse.Namespace, *, cars_data: list[dict] | None = None) -> RaceConfig:
    runtime_overrides = _load_runtime_overrides(args.config)
    world_mode = getattr(args, "world_mode", runtime_overrides.get("world_mode", DEFAULT_CONFIG.world_mode))
    if getattr(args, "advanced", False):
        world_mode = "advanced"
    default_advanced_track = str(runtime_overrides.get("default_advanced_track", DEFAULT_ADVANCED_TRACK))
    cars_path_explicit = hasattr(args, "cars_path")
    cars_path = getattr(args, "cars_path", DEFAULT_CARS_PATH)
    requested_track = getattr(args, "track", None)
    if requested_track is None:
        requested_track = default_advanced_track if world_mode == "advanced" else DEFAULT_CONFIG.track
    return RaceConfig(
        track=requested_track,
        world_mode=world_mode,
        default_advanced_track=default_advanced_track,
        cars_path=cars_path,
        cars_path_explicit=cars_path_explicit,
        drivers_dir=args.drivers_dir,
        cars_data=cars_data,
        race_mode=args.race_mode,
        rangefinders=args.rangefinders,
        physics_hz=getattr(args, "physics_hz", runtime_overrides.get("physics_hz", DEFAULT_CONFIG.physics_hz)),
        sensor_hz=getattr(args, "sensor_hz", runtime_overrides.get("sensor_hz", DEFAULT_CONFIG.sensor_hz)),
        scene_render_hz=getattr(args, "scene_render_hz", runtime_overrides.get("scene_render_hz", DEFAULT_CONFIG.scene_render_hz)),
        render_scale=getattr(args, "render_scale", runtime_overrides.get("render_scale", DEFAULT_CONFIG.render_scale)),
        reduced_scene_complexity=(
            getattr(args, "scene_complexity") == "reduced"
            if hasattr(args, "scene_complexity")
            else runtime_overrides.get("reduced_scene_complexity", DEFAULT_CONFIG.reduced_scene_complexity)
        ),
        lap_target=args.lap_target,
        headless=args.headless,
        max_steps=args.max_steps,
        max_time=args.max_time,
        auto_reload=not args.no_auto_reload,
    )


def _print_results(app: RaceApp) -> None:
    print(f'Final standings ({app._race_mode_label()}):')
    for row in app.build_results()["standings"]:
        if app.config.race_mode == "qualifying":
            metric = f'{row["best_lap_time"]:.2f}s' if row["best_lap_time"] is not None else "no lap"
        elif app.config.race_mode == "clean_race":
            metric = f'{row["total_contacts"]} hits'
        elif app.config.race_mode == "precision":
            metric = f'{row["mean_center_error"]:.2f}m' if row["mean_center_error"] is not None else "--"
        elif app.config.race_mode == "consistency":
            metric = f'{row["consistency_spread"]:.2f}s' if row["consistency_spread"] is not None else "--"
        else:
            metric = f'{row["finish_time"]:.2f}s' if row["finish_time"] is not None else f'{row["absolute_completion_percent"]:.2f}%'
        print(f'{row["place"]:>2}. {row["name"]:<24} {metric:>10}  avg={row["mean_driver_ms"]:.3f}ms')


def _run_race(args: argparse.Namespace, *, cars_data: list[dict] | None = None) -> int:
    try:
        app = RaceApp(_build_config(args, cars_data=cars_data))
    except ValueError as exc:
        print(exc)
        return 2
    try:
        app.run()
        if args.results_json or args.results_csv:
            app.save_results(json_path=args.results_json or None, csv_path=args.results_csv or None)
        if args.headless:
            _print_results(app)
        return 0
    finally:
        app.close()


def _driver_entries_from_paths(paths: list[Path]) -> list[dict]:
    entries = []
    for path in paths:
        if path.name in {"__init__.py", "template.py"} or path.suffix != ".py":
            continue
        full_path = path if path.is_absolute() else PROJECT_ROOT / path
        entries.append({"driver": str(full_path.resolve()), "name": path.stem.replace("_", " ").replace("-", " ").title()})
    return entries


def _discover_batch_entries(args: argparse.Namespace) -> list[dict]:
    drivers_dir = Path(args.drivers_dir)
    if not drivers_dir.is_absolute():
        drivers_dir = PROJECT_ROOT / drivers_dir
    paths = [Path(value) for value in args.driver] if args.driver else sorted(drivers_dir.glob(args.pattern))
    return _driver_entries_from_paths(paths)


def _run_batch(args: argparse.Namespace) -> int:
    entries = _discover_batch_entries(args)
    if not entries:
        print("No driver files matched the batch selection.")
        return 1
    args.headless = True
    return _run_race(args, cars_data=entries)


def _run_create_driver(args: argparse.Namespace) -> int:
    if args.output:
        output = Path(args.output)
    else:
        name_path = Path(args.name)
        output = name_path if len(name_path.parts) > 1 or name_path.suffix == ".py" else PROJECT_ROOT / "drivers" / name_path
    try:
        created = create_driver_file(output, force=args.force)
    except FileExistsError as exc:
        print(exc)
        return 1
    print(f"Created driver scaffold at {created}")
    return 0


def main(argv: list[str] | None = None) -> int:
    argv = _normalize_argv(list(sys.argv[1:] if argv is None else argv))
    args = build_parser().parse_args(argv)
    if args.command == "race":
        cars_data = _driver_entries_from_paths([Path(value) for value in args.driver]) if args.driver else None
        if args.driver and not cars_data:
            print("No usable driver files were passed to --driver.")
            return 1
        return _run_race(args, cars_data=cars_data)
    if args.command == "batch":
        return _run_batch(args)
    if args.command == "create-driver":
        return _run_create_driver(args)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
