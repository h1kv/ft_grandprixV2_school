from __future__ import annotations

from dataclasses import asdict, dataclass
from functools import lru_cache
import math
from pathlib import Path
import re
import xml.etree.ElementTree as ET

import numpy as np
import svg.path


def _unit(vector: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vector))
    if norm <= 1e-9:
        return np.array([1.0, 0.0], dtype=np.float32)
    return (vector / norm).astype(np.float32)


def _cross_2d(a: np.ndarray, b: np.ndarray) -> float:
    return float(a[0] * b[1] - a[1] * b[0])


@lru_cache(maxsize=32)
def _search_offsets(search_radius: int) -> np.ndarray:
    return np.arange(-search_radius, search_radius + 1, dtype=np.int32)


def _line_intersection(p: np.ndarray, r: np.ndarray, q: np.ndarray, s: np.ndarray) -> np.ndarray | None:
    det = _cross_2d(r, s)
    if abs(det) <= 1e-8:
        return None
    t = _cross_2d(q - p, s) / det
    return (p + r * t).astype(np.float32)


def _segment_segment_intersection(
    a0: np.ndarray,
    a1: np.ndarray,
    b0: np.ndarray,
    b1: np.ndarray,
) -> tuple[float, float, np.ndarray] | None:
    r = a1 - a0
    s = b1 - b0
    det = _cross_2d(r, s)
    if abs(det) <= 1e-8:
        return None
    delta = b0 - a0
    t = _cross_2d(delta, s) / det
    u = _cross_2d(delta, r) / det
    if 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0:
        point = (a0 + r * t).astype(np.float32)
        return float(t), float(u), point
    return None


def _point_in_polygon(point: np.ndarray, polygon: np.ndarray) -> bool:
    x = float(point[0])
    y = float(point[1])
    inside = False
    count = len(polygon)
    j = count - 1
    for i in range(count):
        xi = float(polygon[i][0])
        yi = float(polygon[i][1])
        xj = float(polygon[j][0])
        yj = float(polygon[j][1])
        intersects = ((yi > y) != (yj > y))
        if intersects:
            cross_x = (xj - xi) * (y - yi) / max(1e-9, (yj - yi)) + xi
            if x < cross_x:
                inside = not inside
        j = i
    return inside


def _resample_closed(points: np.ndarray, samples: int) -> np.ndarray:
    closed = np.vstack([points, points[0]])
    deltas = np.diff(closed, axis=0)
    lengths = np.linalg.norm(deltas, axis=1)
    cumulative = np.concatenate([[0.0], np.cumsum(lengths)])
    total = float(cumulative[-1])
    targets = np.linspace(0.0, total, samples, endpoint=False, dtype=np.float32)
    resampled = np.empty((samples, 2), dtype=np.float32)
    seg_index = 0
    for i, distance in enumerate(targets):
        while seg_index + 1 < len(cumulative) and cumulative[seg_index + 1] <= distance:
            seg_index += 1
        start = closed[seg_index]
        end = closed[seg_index + 1]
        segment_length = max(1e-6, float(lengths[seg_index]))
        fraction = (distance - float(cumulative[seg_index])) / segment_length
        resampled[i] = start + (end - start) * fraction
    return resampled


def _extract_svg_points(svg_path: Path, samples: int) -> np.ndarray:
    root = ET.parse(svg_path).getroot()
    namespace = re.match(r"\{(.+)\}", root.tag)
    ns = "{" + namespace.group(1) + "}" if namespace else ""
    path_tag = root.find(f".//{ns}path")
    if path_tag is None:
        raise ValueError(f"Could not find a path in {svg_path}")
    path = svg.path.parse_path(path_tag.attrib["d"])
    raw = np.array(
        [[path.point(i / (samples * 4)).real, path.point(i / (samples * 4)).imag] for i in range(samples * 4)],
        dtype=np.float32,
    )
    return _resample_closed(raw, samples)


def _sample_closed_polyline(points: np.ndarray, spacing: float) -> np.ndarray:
    closed = np.vstack([points, points[0]])
    deltas = np.diff(closed, axis=0)
    lengths = np.linalg.norm(deltas, axis=1)
    cumulative = np.concatenate([[0.0], np.cumsum(lengths)])
    total = float(cumulative[-1])
    count = max(3, int(math.ceil(total / max(1e-3, spacing))))
    targets = np.linspace(0.0, total, count, endpoint=False, dtype=np.float32)
    sampled = np.empty((count, 2), dtype=np.float32)
    seg_index = 0
    for i, distance in enumerate(targets):
        while seg_index + 1 < len(cumulative) and cumulative[seg_index + 1] <= distance:
            seg_index += 1
        start = closed[seg_index]
        end = closed[seg_index + 1]
        segment_length = max(1e-6, float(lengths[seg_index]))
        fraction = (distance - float(cumulative[seg_index])) / segment_length
        sampled[i] = start + (end - start) * fraction
    return sampled


@dataclass(slots=True)
class TrackSettings:
    name: str = "track"
    world_size: float = 40.0
    samples: int = 320
    track_scale: float = 1.0
    half_width: float = 1.75
    curb_width: float = 0.24
    curb_height: float = 0.03
    wall_gap: float = 0.26
    wall_height: float = 0.86
    wall_thickness: float = 0.18
    panel_length: float = 1.00
    elevation_scale: float = 1.0
    bank_scale: float = 1.0
    terrain_height_scale: float = 1.0
    terrain_blend_radius: float = 6.0
    road_height_smoothing: float = 0.70
    bank_smoothing: float = 0.55

    def copy(self) -> "TrackSettings":
        return TrackSettings(**asdict(self))


@dataclass(slots=True)
class SegmentStyle:
    position: np.ndarray
    size: np.ndarray
    yaw: float
    rgba: tuple[float, float, float, float]


@dataclass(slots=True)
class TrackGeometry:
    settings: TrackSettings
    centerline: np.ndarray
    tangents: np.ndarray
    normals: np.ndarray
    cumulative_lengths: np.ndarray
    total_length: float
    track_inner: np.ndarray
    track_outer: np.ndarray
    inner_curb: np.ndarray
    outer_curb: np.ndarray
    inner_wall_face: np.ndarray
    outer_wall_face: np.ndarray
    track_envelope: np.ndarray
    track_hole: np.ndarray
    wall_segments: list[SegmentStyle]
    curb_segments: list[SegmentStyle]
    finish_line: tuple[np.ndarray, np.ndarray]
    segment_ends: np.ndarray
    segment_vectors: np.ndarray
    segment_lengths_sq: np.ndarray
    all_indices: np.ndarray

    def project(
        self,
        position: np.ndarray,
        *,
        hint_progress: float | None = None,
        search_radius: int = 12,
    ) -> tuple[int, np.ndarray, np.ndarray, float, float]:
        a = self.centerline
        count = len(self.centerline)
        if hint_progress is None or search_radius >= count // 2:
            indices = self.all_indices
        else:
            wrapped = hint_progress % self.total_length
            center_index = int(np.searchsorted(self.cumulative_lengths, wrapped, side="right") - 1)
            indices = (center_index + _search_offsets(search_radius)) % count

        seg_a = a[indices]
        ab = self.segment_vectors[indices]
        denom = self.segment_lengths_sq[indices]
        ap = position[None, :] - seg_a
        t = np.clip(np.einsum("ij,ij->i", ap, ab) / np.maximum(1e-9, denom), 0.0, 1.0)
        closest = seg_a + ab * t[:, None]
        diff = position[None, :] - closest
        local_index = int(np.argmin(np.einsum("ij,ij->i", diff, diff)))
        index = int(indices[local_index])
        point = closest[local_index].astype(np.float32)
        tangent = _unit(ab[local_index])
        normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        signed_offset = float(np.dot(position - point, normal))
        progress = float(self.cumulative_lengths[index] + t[local_index] * math.sqrt(float(denom[local_index])))
        return index, point, tangent, signed_offset, progress

    def point_at(self, progress: float, *, lateral_offset: float = 0.0) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        wrapped = progress % self.total_length
        index = int(np.searchsorted(self.cumulative_lengths, wrapped, side="right") - 1)
        index = max(0, min(index, len(self.centerline) - 1))
        start = self.centerline[index]
        delta = self.segment_vectors[index]
        length = max(1e-6, math.sqrt(float(self.segment_lengths_sq[index])))
        tangent = _unit(delta)
        normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        local = wrapped - float(self.cumulative_lengths[index])
        center = start + delta * (local / length)
        point = center + normal * lateral_offset
        return point.astype(np.float32), tangent, normal

    @property
    def center(self) -> np.ndarray:
        return np.mean(self.centerline, axis=0).astype(np.float32)

    @property
    def barrier_inner_face_offset(self) -> float:
        return self.settings.half_width + self.settings.curb_width + self.settings.wall_gap

    def _wall_segment_indices(self, hint_progress: float | None, search_radius: int) -> np.ndarray:
        count = len(self.centerline)
        if hint_progress is None or search_radius >= count // 2:
            return self.all_indices
        wrapped = hint_progress % self.total_length
        center_index = int(np.searchsorted(self.cumulative_lengths, wrapped, side="right") - 1)
        return (center_index + _search_offsets(search_radius)) % count

    def first_wall_hit(
        self,
        start: np.ndarray,
        end: np.ndarray,
        *,
        hint_progress: float | None = None,
        search_radius: int = 18,
    ) -> tuple[float, np.ndarray] | None:
        best_t = float("inf")
        best_point: np.ndarray | None = None
        indices = self._wall_segment_indices(hint_progress, search_radius)
        for points in (self.inner_wall_face, self.outer_wall_face):
            for index in indices:
                hit = _segment_segment_intersection(start, end, points[index], points[(index + 1) % len(points)])
                if hit is None:
                    continue
                t, _u, point = hit
                if t < best_t:
                    best_t = t
                    best_point = point
        if best_point is None:
            return None
        return best_t, best_point

    def is_point_on_track(
        self,
        point: np.ndarray,
        *,
        hint_progress: float | None = None,
        search_radius: int = 12,
        clearance: float = 0.38,
    ) -> bool:
        if hint_progress is None:
            search_radius = len(self.centerline)
        _index, center, _tangent, signed_offset, _progress = self.project(
            point.astype(np.float32),
            hint_progress=hint_progress,
            search_radius=search_radius,
        )
        barrier_limit = self.barrier_inner_face_offset - max(0.0, clearance)
        if abs(signed_offset) > barrier_limit + 1e-4:
            return False
        if hint_progress is not None:
            return True
        hit = self.first_wall_hit(center.astype(np.float32), point.astype(np.float32))
        if hit is None:
            return True
        hit_t, _hit_point = hit
        return hit_t >= 0.999


DEFAULT_TRACKS: dict[str, TrackSettings] = {
    "track": TrackSettings(name="track", half_width=1.75, curb_width=0.24, wall_gap=0.26, wall_height=0.86, samples=360),
    "circle": TrackSettings(name="circle", half_width=1.90, curb_width=0.22, wall_gap=0.30, wall_height=0.82, samples=280),
    "small-circle": TrackSettings(name="small-circle", half_width=1.55, curb_width=0.20, wall_gap=0.24, wall_height=0.78, samples=240),
    "inkscape": TrackSettings(name="inkscape", half_width=1.70, curb_width=0.24, wall_gap=0.26, wall_height=0.82, samples=320),
}


def discover_tracks(template_dir: Path) -> list[str]:
    names = []
    for svg_path in sorted(template_dir.glob("*-path.svg")):
        name = svg_path.stem[:-5]
        image_path = template_dir / f"{name}.png"
        if image_path.is_file():
            names.append(name)
    return names


def load_track_geometry(template_dir: Path, settings: TrackSettings) -> TrackGeometry:
    svg_path = template_dir / f"{settings.name}-path.svg"
    points = _extract_svg_points(svg_path, settings.samples)
    raw_min = points.min(axis=0)
    raw_max = points.max(axis=0)
    raw_center = 0.5 * (raw_min + raw_max)
    raw_span = np.maximum(raw_max - raw_min, 1e-6)
    barrier_margin = settings.half_width + settings.curb_width + settings.wall_gap + settings.wall_thickness + 1.4
    usable_extent = max(6.0, settings.world_size - barrier_margin * 2.0)
    # 100% is the standard layout size, while 50% gives a compact half-scale version.
    scale = (usable_extent / max(float(raw_span[0]), float(raw_span[1]))) * (2.0 * max(0.15, settings.track_scale))
    centerline = np.empty_like(points)
    centerline[:, 0] = (points[:, 0] - raw_center[0]) * scale
    centerline[:, 1] = -(points[:, 1] - raw_center[1]) * scale

    tangents = np.empty_like(centerline)
    normals = np.empty_like(centerline)
    for i in range(len(centerline)):
        delta = centerline[(i + 1) % len(centerline)] - centerline[i - 1]
        tangent = _unit(delta)
        tangents[i] = tangent
        normals[i] = np.array([-tangent[1], tangent[0]], dtype=np.float32)

    closed = np.vstack([centerline, centerline[0]])
    cumulative = np.concatenate([[0.0], np.cumsum(np.linalg.norm(np.diff(closed, axis=0), axis=1))]).astype(np.float32)
    total_length = float(cumulative[-1])
    segment_ends = np.roll(centerline, -1, axis=0)
    segment_vectors = (segment_ends - centerline).astype(np.float32)
    segment_lengths_sq = np.einsum("ij,ij->i", segment_vectors, segment_vectors).astype(np.float32)
    all_indices = np.arange(len(centerline), dtype=np.int32)

    track_inner = _offset_closed_polyline(centerline, -settings.half_width)
    track_outer = _offset_closed_polyline(centerline, settings.half_width)
    inner_curb = _offset_closed_polyline(centerline, -(settings.half_width + settings.curb_width * 0.5))
    outer_curb = _offset_closed_polyline(centerline, settings.half_width + settings.curb_width * 0.5)
    inner_wall_face = _offset_closed_polyline(centerline, -(settings.half_width + settings.curb_width + settings.wall_gap))
    outer_wall_face = _offset_closed_polyline(centerline, settings.half_width + settings.curb_width + settings.wall_gap)

    wall_segments = _build_polyline_segments(
        points=_offset_closed_polyline(centerline, settings.half_width + settings.curb_width + settings.wall_gap + settings.wall_thickness * 0.5),
        width=settings.wall_thickness,
        height=settings.wall_height,
        panel_length=settings.panel_length,
        colors=((0.80, 0.82, 0.84, 1.0), (0.69, 0.72, 0.75, 1.0)),
    ) + _build_polyline_segments(
        points=_offset_closed_polyline(centerline, -(settings.half_width + settings.curb_width + settings.wall_gap + settings.wall_thickness * 0.5)),
        width=settings.wall_thickness,
        height=settings.wall_height,
        panel_length=settings.panel_length,
        colors=((0.80, 0.82, 0.84, 1.0), (0.69, 0.72, 0.75, 1.0)),
    )

    curb_segments = _build_polyline_segments(
        points=outer_curb,
        width=settings.curb_width,
        height=settings.curb_height,
        panel_length=settings.panel_length * 0.85,
        colors=((0.73, 0.12, 0.10, 1.0), (0.93, 0.93, 0.92, 1.0)),
    ) + _build_polyline_segments(
        points=inner_curb,
        width=settings.curb_width,
        height=settings.curb_height,
        panel_length=settings.panel_length * 0.85,
        colors=((0.73, 0.12, 0.10, 1.0), (0.93, 0.93, 0.92, 1.0)),
    )

    finish_a = track_inner[0]
    finish_b = track_outer[0]
    track_envelope = track_inner
    track_hole = track_outer
    probe_step = max(1, len(centerline) // 24)
    for probe in centerline[::probe_step]:
        in_inner = _point_in_polygon(probe, track_inner)
        in_outer = _point_in_polygon(probe, track_outer)
        if in_inner == in_outer:
            continue
        if in_inner:
            track_envelope = track_inner
            track_hole = track_outer
        else:
            track_envelope = track_outer
            track_hole = track_inner
        break
    return TrackGeometry(
        settings=settings,
        centerline=centerline,
        tangents=tangents,
        normals=normals,
        cumulative_lengths=cumulative,
        total_length=total_length,
        track_inner=track_inner,
        track_outer=track_outer,
        inner_curb=inner_curb,
        outer_curb=outer_curb,
        inner_wall_face=inner_wall_face,
        outer_wall_face=outer_wall_face,
        track_envelope=track_envelope,
        track_hole=track_hole,
        wall_segments=wall_segments,
        curb_segments=curb_segments,
        finish_line=(finish_a, finish_b),
        segment_ends=segment_ends,
        segment_vectors=segment_vectors,
        segment_lengths_sq=segment_lengths_sq,
        all_indices=all_indices,
    )


def _offset_closed_polyline(points: np.ndarray, offset: float, *, miter_limit: float = 2.6, inside_corner_scale: float = 0.4) -> np.ndarray:
    result = np.empty_like(points)
    for i in range(len(points)):
        prev_point = points[i - 1]
        current = points[i]
        next_point = points[(i + 1) % len(points)]
        prev_dir = _unit(current - prev_point)
        next_dir = _unit(next_point - current)
        prev_normal = np.array([-prev_dir[1], prev_dir[0]], dtype=np.float32)
        next_normal = np.array([-next_dir[1], next_dir[0]], dtype=np.float32)
        prev_shift = current + prev_normal * offset
        next_shift = current + next_normal * offset

        # The inside of a corner should clip rather than form long miter spikes or loop triangles.
        turn = _cross_2d(prev_dir, next_dir)
        if offset * turn > 1e-4:
            chamfer_target = 0.5 * (prev_shift + next_shift)
            result[i] = current + (chamfer_target - current) * inside_corner_scale
            continue

        intersection = _line_intersection(prev_shift, prev_dir, next_shift, next_dir)
        if intersection is None:
            chamfer_target = 0.5 * (prev_shift + next_shift)
            result[i] = current + (chamfer_target - current) * inside_corner_scale
            continue

        miter_length = float(np.linalg.norm(intersection - current))
        if not math.isfinite(miter_length) or miter_length > abs(offset) * miter_limit + 0.35:
            chamfer_target = 0.5 * (prev_shift + next_shift)
            result[i] = current + (chamfer_target - current) * inside_corner_scale
            continue

        result[i] = intersection
    return result.astype(np.float32)


def _build_polyline_segments(
    *,
    points: np.ndarray,
    width: float,
    height: float,
    panel_length: float,
    colors: tuple[tuple[float, float, float, float], tuple[float, float, float, float]],
) -> list[SegmentStyle]:
    control_points = _sample_closed_polyline(points, max(0.45, float(panel_length)))
    segments: list[SegmentStyle] = []
    distance_accum = 0.0
    for i in range(len(control_points)):
        start = control_points[i]
        end = control_points[(i + 1) % len(control_points)]
        delta = end - start
        length = float(np.linalg.norm(delta))
        if length <= 1e-5:
            continue
        tangent = delta / length
        yaw = math.atan2(float(tangent[1]), float(tangent[0]))
        midpoint = 0.5 * (start + end)
        rgba = colors[int(distance_accum / max(0.45, float(panel_length))) % 2]
        z_center = height * 0.5 + (0.001 if height < 0.08 else 0.0)
        segments.append(
            SegmentStyle(
                position=np.array([midpoint[0], midpoint[1], z_center], dtype=np.float32),
                size=np.array([length * 0.5, width * 0.5, height * 0.5], dtype=np.float32),
                yaw=yaw,
                rgba=rgba,
            )
        )
        distance_accum += length
    return segments


def ray_segment_intersection(origin: np.ndarray, direction: np.ndarray, a: np.ndarray, b: np.ndarray) -> float | None:
    segment = b - a
    det = _cross_2d(direction, segment)
    if abs(det) <= 1e-8:
        return None
    delta = a - origin
    t = _cross_2d(delta, segment) / det
    u = _cross_2d(delta, direction) / det
    if t >= 0.0 and 0.0 <= u <= 1.0:
        return t
    return None
