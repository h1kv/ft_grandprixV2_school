from __future__ import annotations

from pathlib import Path


def _normalize_output_path(path: Path) -> Path:
    if path.suffix != ".py":
        path = path.with_suffix(".py")
    return path


def create_driver_file(output_path: Path, *, force: bool = False) -> Path:
    output_path = _normalize_output_path(output_path)
    if output_path.exists() and not force:
        raise FileExistsError(f"{output_path} already exists. Pass --force to overwrite it.")

    project_root = Path(__file__).resolve().parents[1]
    starter_path = project_root / "drivers" / "template.py"
    starter_code = starter_path.read_text(encoding="utf-8")
    banner = (
        f'"""AIGPV2 driver scaffold for `{output_path.stem}`.\n\n'
        "Keep this as a single Python file and edit `process_lidar()`.\n"
        '"""\n\n'
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(banner + starter_code, encoding="utf-8")
    return output_path.resolve()
