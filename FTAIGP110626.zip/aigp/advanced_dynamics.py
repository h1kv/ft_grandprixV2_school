from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(slots=True)
class AdvancedDynamicsFactors:
    grip_scale: float
    drag_multiplier: float
    slope_acceleration: float
    load_factor: float
    camber_factor: float


def _clip(value: float, lower: float, upper: float) -> float:
    return lower if value < lower else upper if value > upper else value


def slope_acceleration(grade: float) -> float:
    return -9.81 * float(grade) * 0.82


def vertical_load_factor(speed: float, vertical_curvature: float) -> float:
    speed = abs(float(speed))
    curvature = float(vertical_curvature)
    load = 1.0 + 0.92 * (speed * speed * curvature) / 9.81
    return _clip(load, 0.38, 1.55)


def camber_turn_factor(bank_radians: float, turn_direction: float, turn_intensity: float) -> float:
    intensity = _clip(float(turn_intensity), 0.0, 1.0)
    direction = 0.0 if abs(float(turn_direction)) < 1e-5 else math.copysign(1.0, float(turn_direction))
    if intensity <= 1e-5 or direction == 0.0:
        return 1.0
    support = _clip((-direction) * math.sin(float(bank_radians)) / math.sin(math.radians(16.0)), -1.0, 1.0)
    helpful = max(0.0, support)
    harmful = max(0.0, -support)
    factor = 1.0 + 0.22 * helpful * intensity - 0.38 * harmful * intensity
    return _clip(factor, 0.56, 1.24)


def terrain_drag_bonus(surface_mix: float) -> float:
    clamped = max(0.0, min(1.0, float(surface_mix)))
    return 1.0 + 0.55 * clamped


def combine_surface_dynamics(
    *,
    base_grip: float,
    base_drag: float,
    bank_radians: float,
    terrain_mix: float,
    roughness: float,
    grade: float,
    speed: float = 0.0,
    vertical_curvature: float = 0.0,
    turn_direction: float = 0.0,
    turn_intensity: float = 0.0,
) -> AdvancedDynamicsFactors:
    roughness_penalty = 1.0 - 0.20 * max(0.0, float(roughness))
    load_factor = vertical_load_factor(speed, vertical_curvature)
    camber_factor = camber_turn_factor(bank_radians, turn_direction, turn_intensity)
    grip = max(0.34, float(base_grip) * roughness_penalty * load_factor * camber_factor)
    drag = max(
        1.0,
        float(base_drag)
        * terrain_drag_bonus(terrain_mix)
        * (1.0 + 0.18 * max(0.0, float(roughness)))
        * (1.0 + 0.10 * max(0.0, 1.0 - load_factor)),
    )
    return AdvancedDynamicsFactors(
        grip_scale=grip,
        drag_multiplier=drag,
        slope_acceleration=slope_acceleration(grade),
        load_factor=load_factor,
        camber_factor=camber_factor,
    )
