from __future__ import annotations

from dataclasses import dataclass

import numpy as np


ADVANCED_LIDAR_RING_PITCHES: tuple[float, ...] = (-12.0, 0.0, 14.0)
ADVANCED_LIDAR_RAYS = 48


@dataclass(slots=True)
class AdvancedObservation:
    lidar: np.ndarray
    lidar_ring_pitches: tuple[float, ...]
    yaw: float
    pitch: float
    roll: float
    yaw_rate: float
    pitch_rate: float
    roll_rate: float
    body_velocity: tuple[float, float, float]
    ride_height: float
    vertical_velocity: float
    airborne_time: float
    grounded: bool
    surface_load: float
    vertical_curvature: float
    slope: float
    bank: float
    lap_completion: float
    absolute_completion: float
    time: float


def advanced_sensor_shape() -> tuple[int, int]:
    return len(ADVANCED_LIDAR_RING_PITCHES), ADVANCED_LIDAR_RAYS


def reshape_advanced_ranges(flat_ranges: np.ndarray) -> np.ndarray:
    ring_count, rays = advanced_sensor_shape()
    return np.asarray(flat_ranges, dtype=np.float32).reshape(ring_count, rays)


def flatten_legacy_lidar(scan: np.ndarray) -> np.ndarray:
    shaped = np.asarray(scan, dtype=np.float32)
    if shaped.ndim != 2:
        return shaped.astype(np.float32, copy=True)
    if shaped.shape[0] == 0:
        return np.zeros(0, dtype=np.float32)
    if shaped.shape[0] == 1:
        return shaped[0].astype(np.float32, copy=True)
    # Legacy 2D drivers expect a horizon-style scan. Using the per-ray minimum
    # across rings makes downhill terrain and banking look like an obstacle
    # directly ahead, so we project the 3D scan back to a stable median slice.
    return np.median(shaped, axis=0).astype(np.float32, copy=False)
