# Cars Configs

Default shipped race grid:

- `aigpv2.json`

This is the configuration used by the default runtime setup.

Advanced-mode starter grid:

- `advanced_alpine.json`

The runtime uses this grid automatically when advanced mode boots from the default cars config. It keeps the advanced default lightweight and avoids loading flat-track sample cars that are not tuned for hills, banking, or multi-ring lidar.

Local-only or experimental car-grid configs can be kept in:

- `_LOCAL_ARCHIVE_IGNORE_FOR_REPO_UPLOAD/`
