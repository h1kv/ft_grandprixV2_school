# Formula Trinity GP (`AIGPV2`)

`AIGPV2` is the standalone Formula Trinity GP runtime.

It includes:

- 3D MuJoCo rendering
- single-file Python competitors in `drivers/`
- editable SVG-based track generation
- full viewer/settings UI
- challenge modes, headless runs, and exportable race results

## Quick Start

For non-code Windows laptops, double-click:

```text
AIGP Setup Windows.bat
AIGP Health Check.bat
AIGP Run Official Race.bat
```

Use `AIGP Launcher.bat` when you want the simple viewer menu. Use `AIGP Run Official Race.bat` for the official headless Standard 2D race export.

`AIGP Launcher.bat` is intentionally simple:

- `1`: Standard Mode, full visual scene with default 60 Hz scene refresh, 0.80 render scale, and full scene complexity.
- `2`: Low Power Mode, same drivers, physics, sensors, scene geometry, and race rules, but lower visual load with 20 Hz scene refresh and 0.55 render scale.

Use `AIGP Diagnostic Launcher.bat` for health checks, official exports, all-driver diagnostics, Advanced 3D tests, and driver scaffolding.

Use `AIGP Presentation.bat` for a hidden high-visual-budget viewer: 120 Hz scene refresh, 1.0 render scale, and full scene complexity. It keeps the same drivers, physics, sensors, geometry, collisions, and race rules as Standard Mode.

From the repository root:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m aigp
```

Useful commands:

```bash
python -m aigp
python -m aigp --advanced
python -m aigp --driver drivers/minimal_centerline.py --headless --max-steps 600
python -m aigp --headless --max-steps 1200
python -m aigp --headless --results-json .rendered/results.json
python -m aigp --config aigp.runtime.toml
python tools/benchmark_runtime.py --mode both --steps 600 --warmup-steps 120
python -m aigp --headless --lap-target 1 --results-json .rendered/results.json --results-csv .rendered/results.csv
python -m aigp batch --driver drivers/ultimate.py --driver drivers/simple_track_attack.py
python -m aigp create-driver my_new_bot
python -m unittest discover -s tests -v
```

## Documentation

- [Running the GP and building cars](docs/RUNNING_AND_BUILDING_CARS.md)
- [Windows launcher for non-code users](docs/WINDOWS_LAUNCHER.md)
- [Release candidate handoff](docs/RELEASE_CANDIDATE_HANDOFF.md)
- [Racer quick start](docs/RACER_QUICK_START.md)
- [Advanced 3D racer principles](docs/ADVANCED_3D_RACER_PRINCIPLES.md)
- [Developer guide and architecture](docs/DEVELOPMENT.md)
- [Advanced track sidecars](docs/ADVANCED_TRACKS.md)
- [Contributing and reviewer setup](CONTRIBUTING.md)

## Important Project Conventions

- Competitor drivers live directly in `drivers/`
- Tracks come from `template/<name>-path.svg` plus `template/<name>.png`
- Advanced tracks live under `template/advanced/<name>/advanced.toml` with sidecar-authored height/bank data
- The default race grid is `template/cars/aigpv2.json`
- Advanced mode uses `template/cars/advanced_alpine.json` automatically unless you pass `--cars`
- Runtime performance and viewer defaults live in `aigp.runtime.toml`
- The default sample grid uses:
  - `drivers/minimal_centerline.py`
  - `drivers/ultimate.py`
  - `drivers/simple_track_attack.py`
- Local-only archives and experiments can live under `_LOCAL_ARCHIVE_IGNORE_FOR_REPO_UPLOAD/` without affecting the shipped repo layout
- The shipped runtime config defaults are:
  - `world_mode = "standard"`
  - `default_advanced_track = "alpine"`
  - `physics_hz = 120`
  - `sensor_hz = 60`
  - `scene_render_hz = 60`
  - `render_scale = 0.80`
  - `reduced_scene_complexity = false`

Use `--driver path/to/driver.py` one or more times when you want a quick ad-hoc race without editing a cars JSON file.

## Stack

- `MuJoCo` for 3D rendering and rangefinder sensors
- `pygame` for the viewer and settings UI
- `numpy` for geometry and control math

## Testing

Run the regression suite with:

```bash
python -m unittest discover -s tests -v
```

That covers:

- CLI/scaffolding
- runtime modes
- geometry
- containment regressions
- spawn validity
- results/export flow

### Core AIGPV2 code by Conor Moran based on the ideas and layout of AIGPV1 written by Chinaza Uzoukwu
- Designed for drivers to be back-compatable with AIGPV1 driver files.