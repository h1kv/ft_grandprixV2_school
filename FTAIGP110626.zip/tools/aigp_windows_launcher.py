"""Small Windows-facing launcher used by the root `.bat` files.

The batch files handle Python discovery; this script keeps the menu and
non-interactive event-day actions in normal Python where they are easier to
test. Every action routes through `python -m aigp` so CLI behavior stays the
single source of truth.
"""

from __future__ import annotations

import argparse
from collections.abc import Callable
from datetime import datetime
import json
from pathlib import Path
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / ".rendered" / "launcher_results"
IGNORED_DRIVER_FILES = {"__init__.py", "driver_template.py", "template.py"}
DISCOVERED_DRIVER_LIVERIES = (
    ("royalblue", "white"),
    ("forestgreen", "gold"),
    ("trinityred", "white"),
    ("silver", "trinityred"),
    ("gold", "black"),
    ("white", "royalblue"),
)
MenuAction = Callable[[], int]
MenuEntry = tuple[str, str, tuple[str, ...], MenuAction]


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def _runtime_ready() -> tuple[bool, str]:
    """Check imports before starting the heavier MuJoCo runtime."""
    missing: list[str] = []
    for module_name in ("mujoco", "numpy", "PIL", "pygame", "svg.path"):
        try:
            __import__(module_name)
        except Exception:
            missing.append(module_name)
    if missing:
        return False, ", ".join(missing)
    return True, ""


def _run(args: list[str]) -> int:
    ready, missing = _runtime_ready()
    if not ready:
        print()
        print("AIGP dependencies are not installed for this Python environment.")
        print(f"Missing: {missing}")
        print('Close this window and run "AIGP Setup Windows.bat", then launch again.')
        return 1
    print()
    print("Running:")
    print("  python -m aigp " + " ".join(args))
    print()
    return subprocess.call([sys.executable, "-m", "aigp", *args], cwd=PROJECT_ROOT)


def _standard_viewer() -> int:
    return _run(["--world-mode", "standard"])


def _standard_low_power_viewer() -> int:
    return _run(
        [
            "--world-mode",
            "standard",
            "--scene-render-hz",
            "20",
            "--render-scale",
            "0.55",
        ]
    )


def _presentation_viewer() -> int:
    """High-visual-budget viewer for demos; physics and sensors stay unchanged."""
    return _run(
        [
            "--world-mode",
            "standard",
            "--scene-render-hz",
            "120",
            "--render-scale",
            "1.0",
            "--scene-complexity",
            "full",
        ]
    )


def _title_from_stem(stem: str) -> str:
    return stem.replace("_", " ").replace("-", " ").title()


def _is_driver_file(path: Path) -> bool:
    if path.suffix.lower() != ".py" or path.name in IGNORED_DRIVER_FILES:
        return False
    if path.name.startswith("_") or "__pycache__" in path.parts:
        return False
    return path.is_file()


def _driver_ref_from_path(path: Path) -> str:
    resolved = path.resolve()
    try:
        relative = resolved.relative_to(PROJECT_ROOT.resolve())
    except ValueError:
        return f"file://{resolved}"
    parts = relative.with_suffix("").parts
    if any(part.startswith(".") or not part.replace("_", "").isalnum() for part in parts):
        return f"file://{resolved}"
    return ".".join(parts)


def _driver_entries_from_folder(drivers_dir: Path, *, active: bool) -> list[dict]:
    if not drivers_dir.exists():
        return []
    paths = sorted(
        (path for path in drivers_dir.rglob("*.py") if _is_driver_file(path)),
        key=lambda path: path.relative_to(drivers_dir).as_posix().casefold(),
    )
    entries = []
    for index, path in enumerate(paths):
        primary, secondary = DISCOVERED_DRIVER_LIVERIES[index % len(DISCOVERED_DRIVER_LIVERIES)]
        entries.append(
            {
                "driver": _driver_ref_from_path(path),
                "name": _title_from_stem(path.stem),
                "primary": primary,
                "secondary": secondary,
                "icon": "white.png",
                "active": active,
            }
        )
    return entries


def _write_cars_manifest(entries: list[dict], stem: str) -> Path:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / f"{stem}_{_timestamp()}.json"
    path.write_text(json.dumps(entries, indent=2), encoding="utf-8")
    return path


def _official_grid_viewer() -> int:
    """Open the event setup grid with every driver discovered but inactive."""
    entries = _driver_entries_from_folder(PROJECT_ROOT / "drivers", active=False)
    if not entries:
        print("No Python driver files were found under drivers/.")
        return 1
    manifest = _write_cars_manifest(entries, "official_grid_inactive")
    print(f"Loaded {len(entries)} drivers as inactive entries from drivers/.")
    return _run(["--world-mode", "standard", "--cars", str(manifest)])


def _standard_race_export() -> int:
    """Run the curated race-day grid and export standings."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = _timestamp()
    return _run(
        [
            "--world-mode",
            "standard",
            "--headless",
            "--lap-target",
            "1",
            "--max-steps",
            "12000",
            "--results-json",
            str(RESULTS_DIR / f"standard_race_{stamp}.json"),
            "--results-csv",
            str(RESULTS_DIR / f"standard_race_{stamp}.csv"),
        ]
    )


def _standard_diagnostics_batch() -> int:
    """Run every discovered driver file; useful for debugging, not standings."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    stamp = _timestamp()
    return _run(
        [
            "batch",
            "--world-mode",
            "standard",
            "--lap-target",
            "1",
            "--max-steps",
            "12000",
            "--results-json",
            str(RESULTS_DIR / f"standard_batch_{stamp}.json"),
            "--results-csv",
            str(RESULTS_DIR / f"standard_batch_{stamp}.csv"),
        ]
    )


def _advanced_viewer() -> int:
    return _run(["--advanced"])


def _advanced_summit() -> int:
    return _run(["--advanced", "--track", "summit"])


def _quick_health_check() -> int:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    return _run(
        [
            "--world-mode",
            "standard",
            "--driver",
            "drivers/minimal_centerline.py",
            "--headless",
            "--lap-target",
            "1",
            "--max-steps",
            "6000",
            "--results-json",
            str(RESULTS_DIR / f"health_check_{_timestamp()}.json"),
        ]
    )


def _create_driver() -> int:
    name = input("New driver name, for example my_driver: ").strip()
    if not name:
        print("No driver name entered.")
        return 1
    return _run(["create-driver", name])


MAIN_MENU: tuple[MenuEntry, ...] = (
    (
        "1",
        "Standard Mode",
        (
            "Full visual scene for normal running.",
            "Uses default render settings: 60 Hz scene refresh, 0.80 render scale, full scene complexity.",
        ),
        _standard_viewer,
    ),
    (
        "2",
        "Low Power Mode",
        (
            "Same drivers, physics, sensors, and race rules as Standard Mode.",
            "Cuts visual load only: 20 Hz scene refresh and 0.55 render scale.",
            "Keeps full scene geometry so LiDAR and collisions match Standard Mode.",
        ),
        _standard_low_power_viewer,
    ),
)

DIAGNOSTIC_MENU: tuple[MenuEntry, ...] = (
    (
        "1",
        "Launch Standard Mode viewer",
        (
            "Full visual scene: 60 Hz scene refresh, 0.80 render scale, full scene complexity.",
            "Use this when the laptop can run the normal viewer smoothly.",
        ),
        _standard_viewer,
    ),
    (
        "2",
        "Launch Low Power Mode viewer",
        (
            "Same physics and drivers as Standard Mode.",
            "Visual-only savings: 20 Hz scene refresh and 0.55 render scale.",
            "Full scene geometry is preserved for sensor parity.",
        ),
        _standard_low_power_viewer,
    ),
    (
        "3",
        "Run official Standard race and export results",
        ("Curated event grid; writes JSON/CSV standings under .rendered/launcher_results.",),
        _standard_race_export,
    ),
    (
        "4",
        "Run all-driver diagnostics batch",
        ("Runs every discovered driver file, including scaffold or experimental bots.",),
        _standard_diagnostics_batch,
    ),
    ("5", "Launch Advanced 3D viewer", ("Advanced terrain, banking, jumps, and multi-ring LiDAR.",), _advanced_viewer),
    ("6", "Launch Advanced 3D Summit jump test", ("Advanced stress test track for crests and jumps.",), _advanced_summit),
    ("7", "Run quick Standard health check", ("Short one-car smoke test for laptop readiness.",), _quick_health_check),
    ("8", "Create a new driver file", ("Scaffolds a new single-file Python racer under drivers/.",), _create_driver),
    (
        "9",
        "Launch official setup grid",
        ("Loads every driver under drivers/ as inactive, ready for organizers to enable selected entrants.",),
        _official_grid_viewer,
    ),
)
MENU = DIAGNOSTIC_MENU
ACTION_ALIASES = {
    "standard": _standard_viewer,
    "low-power": _standard_low_power_viewer,
    "race": _standard_race_export,
    "export": _standard_race_export,
    "batch": _standard_diagnostics_batch,
    "diagnostics": _standard_diagnostics_batch,
    "advanced": _advanced_viewer,
    "summit": _advanced_summit,
    "health": _quick_health_check,
    "presentation": _presentation_viewer,
    "official-grid": _official_grid_viewer,
}


def _print_menu(title: str, menu: tuple[MenuEntry, ...], intro: str = "") -> None:
    print()
    print(title)
    print("=" * len(title))
    if intro:
        print(intro)
        print()
    for key, label, descriptions, _action in menu:
        print(f"{key}. {label}")
        for description in descriptions:
            print(f"   {description}")
    print("Q. Quit")
    print()


def _menu_for_name(name: str) -> tuple[str, tuple[MenuEntry, ...], str]:
    if name == "diagnostic":
        return (
            "Formula Trinity GP Diagnostic Launcher",
            DIAGNOSTIC_MENU,
            "Tools for exports, health checks, advanced testing, and debugging.",
        )
    return (
        "Formula Trinity GP Launcher",
        MAIN_MENU,
        "Choose how much visual load this laptop should run. Physics and driver behavior stay the same.",
    )


def _run_menu(title: str, menu: tuple[MenuEntry, ...], intro: str = "") -> int:
    while True:
        _print_menu(title, menu, intro)
        choice = input("Choose an option: ").strip().lower()
        if choice in {"q", "quit", "exit"}:
            return 0
        for key, _label, _descriptions, action in menu:
            if choice == key:
                exit_code = int(action())
                print()
                if exit_code == 0:
                    print("AIGP was closed. Returning to the launcher menu.")
                else:
                    print(f"AIGP exited with code {exit_code}. Returning to the launcher menu.")
                break
        else:
            print("Unknown option. Choose one of the listed numbers, or Q to quit.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Windows-friendly AIGP launcher")
    parser.add_argument("--list-actions", action="store_true", help="print available launcher actions and exit")
    parser.add_argument("--action", choices=sorted(ACTION_ALIASES), help="run one launcher action non-interactively")
    parser.add_argument("--menu", choices=("main", "diagnostic"), default="main", help="interactive menu to show")
    args = parser.parse_args(argv)
    title, menu, intro = _menu_for_name(args.menu)
    if args.list_actions:
        _print_menu(title, menu, intro)
        return 0
    if args.action:
        return int(ACTION_ALIASES[args.action]())

    return _run_menu(title, menu, intro)


if __name__ == "__main__":
    raise SystemExit(main())
