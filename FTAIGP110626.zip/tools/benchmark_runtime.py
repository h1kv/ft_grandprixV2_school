from __future__ import annotations

import argparse
import gc
import json
from pathlib import Path
import sys
import tempfile
import time

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from aigp.app import RaceApp, RaceConfig
from aigp.advanced_track import DEFAULT_ADVANCED_TRACK


def _resolve_path(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else (PROJECT_ROOT / path).resolve()


def _track_for_mode(mode: str, args: argparse.Namespace) -> str:
    if mode == "advanced":
        return args.advanced_track or DEFAULT_ADVANCED_TRACK
    return args.standard_track or "track"


def benchmark_mode(mode: str, args: argparse.Namespace) -> dict[str, float | int | str]:
    cars_path = getattr(args, "cars", "template/cars/aigpv2.json")
    with tempfile.TemporaryDirectory(prefix=f"aigpv2-bench-{mode}-") as rendered_dir:
        config = RaceConfig(
            headless=True,
            world_mode=mode,
            track=_track_for_mode(mode, args),
            cars_path=str(_resolve_path(cars_path)),
            cars_path_explicit=hasattr(args, "cars"),
            drivers_dir=str(_resolve_path(args.drivers_dir)),
            rendered_dir=rendered_dir,
            physics_hz=args.physics_hz,
            sensor_hz=args.sensor_hz,
            scene_render_hz=args.scene_render_hz,
            reduced_scene_complexity=args.reduced_scene_complexity,
            auto_reload=False,
        )
        app = RaceApp(config)
        try:
            for _ in range(args.warmup_steps):
                app._step()

            driver_time_before = sum(vehicle.driver_total_time for vehicle in app.vehicles)
            driver_calls_before = sum(vehicle.driver_call_count for vehicle in app.vehicles)

            gc_was_enabled = gc.isenabled()
            if gc_was_enabled:
                gc.disable()
            started = time.perf_counter()
            try:
                for _ in range(args.steps):
                    app._step()
                elapsed = time.perf_counter() - started
            finally:
                if gc_was_enabled:
                    gc.enable()

            driver_time_after = sum(vehicle.driver_total_time for vehicle in app.vehicles)
            driver_calls_after = sum(vehicle.driver_call_count for vehicle in app.vehicles)
        finally:
            app.close()

    driver_time = max(0.0, driver_time_after - driver_time_before)
    driver_calls = max(0, driver_calls_after - driver_calls_before)
    sim_seconds = args.steps / max(1, args.physics_hz)
    return {
        "mode": mode,
        "track": config.track,
        "cars": len(app.cars_raw),
        "warmup_steps": args.warmup_steps,
        "steps": args.steps,
        "wall_seconds": round(elapsed, 6),
        "milliseconds_per_step": round((elapsed / max(1, args.steps)) * 1000.0, 4),
        "sim_seconds": round(sim_seconds, 6),
        "sim_x_realtime": round(sim_seconds / max(elapsed, 1e-9), 4),
        "driver_calls": driver_calls,
        "driver_total_ms": round(driver_time * 1000.0, 4),
        "driver_avg_ms": round((driver_time / max(1, driver_calls)) * 1000.0, 4),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Benchmark standard and advanced AIGPV2 runtimes.")
    parser.add_argument("--mode", choices=("standard", "advanced", "both"), default="both", help="which runtime mode to benchmark")
    parser.add_argument("--steps", type=int, default=600, help="measured simulation steps per mode")
    parser.add_argument("--warmup-steps", type=int, default=120, help="warmup simulation steps before timing")
    parser.add_argument("--cars", default=argparse.SUPPRESS, help="cars JSON used for the benchmark grid")
    parser.add_argument("--drivers-dir", default="drivers", help="driver directory root")
    parser.add_argument("--standard-track", default="track", help="standard-mode track name")
    parser.add_argument("--advanced-track", default=DEFAULT_ADVANCED_TRACK, help="advanced-mode track name")
    parser.add_argument("--physics-hz", type=int, default=120, help="physics rate for the benchmark run")
    parser.add_argument("--sensor-hz", type=int, default=60, help="sensor rate for the benchmark run")
    parser.add_argument("--scene-render-hz", type=int, default=60, help="scene render cap stored in the benchmark config")
    parser.add_argument("--reduced-scene-complexity", action="store_true", help="benchmark with reduced wall/curb visuals")
    parser.add_argument("--json-out", default="", help="optional JSON file to write with the benchmark summary")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.steps <= 0 or args.warmup_steps < 0:
        raise SystemExit("steps must be > 0 and warmup_steps must be >= 0")

    modes = ("standard", "advanced") if args.mode == "both" else (args.mode,)
    results = [benchmark_mode(mode, args) for mode in modes]

    for row in results:
        print(
            f"{row['mode']:<8} track={row['track']:<8} cars={row['cars']} "
            f"step_ms={row['milliseconds_per_step']:.3f} sim_x={row['sim_x_realtime']:.2f} "
            f"driver_avg_ms={row['driver_avg_ms']:.3f}"
        )

    if args.json_out:
        output_path = _resolve_path(args.json_out)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
        print(f"Wrote benchmark summary to {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
