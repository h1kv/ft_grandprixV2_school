from __future__ import annotations

import unittest

import numpy as np

from aigp.advanced_sensors import flatten_legacy_lidar


class AdvancedSensorTests(unittest.TestCase):
    def test_flatten_legacy_lidar_uses_a_stable_median_projection(self) -> None:
        scan = np.array(
            [
                [5.0, 1.0, 8.0, 4.0],
                [5.0, 7.0, 8.0, 6.0],
                [5.0, 20.0, 2.0, 9.0],
            ],
            dtype=np.float32,
        )
        flat = flatten_legacy_lidar(scan)
        np.testing.assert_allclose(flat, np.array([5.0, 7.0, 8.0, 6.0], dtype=np.float32))

    def test_flatten_legacy_lidar_leaves_1d_scan_unchanged(self) -> None:
        scan = np.array([1.0, 2.0, 3.0], dtype=np.float32)
        flat = flatten_legacy_lidar(scan)
        np.testing.assert_allclose(flat, scan)


if __name__ == "__main__":
    unittest.main()
