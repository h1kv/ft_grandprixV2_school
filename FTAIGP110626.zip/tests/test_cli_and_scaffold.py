from __future__ import annotations

import contextlib
import io
import importlib.util
from pathlib import Path
import json
import os
import tempfile
import unittest
from unittest.mock import patch

from aigp.__main__ import _build_config, _normalize_argv, build_parser, main
from aigp.app import RaceConfig
from aigp.scaffold import create_driver_file
from drivers.simple_track_attack import Config as TrackAttackConfig, TrackGuide


PROJECT_ROOT = Path(__file__).resolve().parents[1]


class CliAndScaffoldTests(unittest.TestCase):
    def test_normalize_argv_defaults_to_race(self) -> None:
        self.assertEqual(_normalize_argv(["--headless"]), ["race", "--headless"])
        self.assertEqual(_normalize_argv(["batch", "--headless"]), ["batch", "--headless"])

    def test_parser_accepts_race_mode(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["race", "--race-mode", "qualifying", "--headless"])
        self.assertEqual(args.command, "race")
        self.assertEqual(args.race_mode, "qualifying")
        self.assertTrue(args.headless)

    def test_parser_does_not_abbreviate_driver_as_drivers_dir(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["race", "--headless", "--driver", str(PROJECT_ROOT / "drivers" / "minimal_centerline.py")])
        self.assertEqual(args.driver, [str(PROJECT_ROOT / "drivers" / "minimal_centerline.py")])
        self.assertEqual(args.drivers_dir, "drivers")

    def test_parser_defaults_match_runtime_defaults(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["race", "--headless"])
        defaults = RaceConfig()
        config = _build_config(args)
        self.assertEqual(config.track, defaults.track)
        self.assertEqual(config.physics_hz, defaults.physics_hz)
        self.assertEqual(config.sensor_hz, defaults.sensor_hz)
        self.assertEqual(config.scene_render_hz, defaults.scene_render_hz)
        self.assertEqual(config.render_scale, defaults.render_scale)
        self.assertEqual(config.reduced_scene_complexity, defaults.reduced_scene_complexity)
        self.assertEqual(config.world_mode, defaults.world_mode)
        self.assertEqual(config.default_advanced_track, defaults.default_advanced_track)

    def test_parser_accepts_sensor_hz(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["race", "--headless", "--sensor-hz", "45"])
        self.assertEqual(args.sensor_hz, 45)

    def test_runtime_toml_overrides_are_loaded(self) -> None:
        parser = build_parser()
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "runtime.toml"
            config_path.write_text(
                "[runtime]\n"
                "physics_hz = 90\n"
                "sensor_hz = 30\n"
                "scene_render_hz = 120\n"
                "render_scale = 0.70\n"
                "reduced_scene_complexity = true\n"
                "world_mode = 'advanced'\n"
                "default_advanced_track = 'alpine'\n",
                encoding="utf-8",
            )
            args = parser.parse_args(["race", "--headless", "--config", str(config_path)])
            config = _build_config(args)

        self.assertEqual(config.physics_hz, 90)
        self.assertEqual(config.sensor_hz, 30)
        self.assertEqual(config.scene_render_hz, 120)
        self.assertAlmostEqual(config.render_scale, 0.70)
        self.assertTrue(config.reduced_scene_complexity)
        self.assertEqual(config.world_mode, "advanced")
        self.assertEqual(config.default_advanced_track, "alpine")
        self.assertEqual(config.track, "alpine")

    def test_cli_flags_override_runtime_toml(self) -> None:
        parser = build_parser()
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "runtime.toml"
            config_path.write_text(
                "[runtime]\n"
                "physics_hz = 90\n"
                "sensor_hz = 30\n"
                "scene_render_hz = 30\n"
                "render_scale = 0.70\n"
                "reduced_scene_complexity = true\n"
                "world_mode = 'advanced'\n"
                "default_advanced_track = 'alpine'\n",
                encoding="utf-8",
            )
            args = parser.parse_args(
                [
                    "race",
                    "--headless",
                    "--config",
                    str(config_path),
                    "--world-mode",
                    "standard",
                    "--track",
                    "track",
                    "--physics-hz",
                    "120",
                    "--sensor-hz",
                    "60",
                    "--scene-render-hz",
                    "90",
                    "--render-scale",
                    "0.85",
                    "--scene-complexity",
                    "full",
                ]
            )
            config = _build_config(args)

        self.assertEqual(config.physics_hz, 120)
        self.assertEqual(config.sensor_hz, 60)
        self.assertEqual(config.scene_render_hz, 90)
        self.assertAlmostEqual(config.render_scale, 0.85)
        self.assertFalse(config.reduced_scene_complexity)
        self.assertEqual(config.world_mode, "standard")
        self.assertEqual(config.track, "track")

    def test_advanced_flag_selects_default_advanced_track(self) -> None:
        parser = build_parser()
        args = parser.parse_args(["race", "--headless", "--advanced"])
        config = _build_config(args)
        self.assertEqual(config.world_mode, "advanced")
        self.assertEqual(config.track, config.default_advanced_track)
        self.assertFalse(config.cars_path_explicit)

    def test_explicit_cars_path_is_honored_in_advanced_mode(self) -> None:
        parser = build_parser()
        cars_path = str(PROJECT_ROOT / "template" / "cars" / "aigpv2.json")
        args = parser.parse_args(["race", "--headless", "--advanced", "--cars", cars_path])
        config = _build_config(args)
        self.assertTrue(config.cars_path_explicit)
        self.assertEqual(config.cars_path, cars_path)

    def test_race_config_rejects_non_positive_runtime_fields(self) -> None:
        invalid_cases = (
            {"rangefinders": 0},
            {"sensor_hz": 0},
            {"physics_hz": 0},
            {"scene_render_hz": 0},
            {"lap_target": 0},
        )
        for overrides in invalid_cases:
            with self.subTest(overrides=overrides):
                with self.assertRaises(ValueError):
                    RaceConfig(**overrides)

    def test_race_config_rejects_invalid_render_scale(self) -> None:
        for render_scale in (0.50, 1.05):
            with self.subTest(render_scale=render_scale):
                with self.assertRaises(ValueError):
                    RaceConfig(render_scale=render_scale)

    def test_main_returns_error_for_invalid_runtime_config(self) -> None:
        exit_code = main(["race", "--headless", "--rangefinders", "0"])
        self.assertEqual(exit_code, 2)

    def test_main_returns_error_for_invalid_runtime_toml(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "runtime.toml"
            config_path.write_text("[runtime]\nphysics_hz =\n", encoding="utf-8")
            exit_code = main(["race", "--headless", "--config", str(config_path)])
        self.assertEqual(exit_code, 2)

    def test_create_driver_file_writes_single_python_file(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "new_driver"
            created = create_driver_file(output)
            self.assertEqual(created.suffix, ".py")
            text = created.read_text(encoding="utf-8")
            self.assertIn("class Driver", text)
            self.assertIn("process_lidar", text)

    def test_headless_race_writes_results_json(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            results_path = Path(temp_dir) / "results.json"
            manifest_path = PROJECT_ROOT / "template" / "cars" / "aigpv2.json"
            expected_grid = json.loads(manifest_path.read_text(encoding="utf-8"))
            exit_code = main(
                [
                    "race",
                    "--headless",
                    "--drivers-dir",
                    str(PROJECT_ROOT / "drivers"),
                    "--cars",
                    str(PROJECT_ROOT / "template" / "cars" / "aigpv2.json"),
                    "--max-steps",
                    "6",
                    "--results-json",
                    str(results_path),
                ]
            )
            self.assertEqual(exit_code, 0)
            self.assertTrue(results_path.exists())
            payload = json.loads(results_path.read_text(encoding="utf-8"))
            self.assertEqual(payload["runtime"], "AIGPV2")
            self.assertEqual(len(payload["standings"]), len(expected_grid))

    def test_race_driver_flag_builds_ad_hoc_grid(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            results_path = Path(temp_dir) / "race-driver.json"
            exit_code = main(
                [
                    "race",
                    "--headless",
                    "--driver",
                    str(PROJECT_ROOT / "drivers" / "minimal_centerline.py"),
                    "--max-steps",
                    "6",
                    "--results-json",
                    str(results_path),
                ]
            )
            self.assertEqual(exit_code, 0)
            payload = json.loads(results_path.read_text(encoding="utf-8"))
            self.assertEqual([row["name"] for row in payload["standings"]], ["Minimal Centerline"])

    def test_batch_mode_writes_json_and_csv(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            json_path = Path(temp_dir) / "batch.json"
            csv_path = Path(temp_dir) / "batch.csv"
            exit_code = main(
                [
                    "batch",
                    "--driver",
                    str(PROJECT_ROOT / "drivers" / "minimal_centerline.py"),
                    "--driver",
                    str(PROJECT_ROOT / "drivers" / "simple_track_attack.py"),
                    "--max-steps",
                    "6",
                    "--results-json",
                    str(json_path),
                    "--results-csv",
                    str(csv_path),
                ]
            )
            self.assertEqual(exit_code, 0)
            self.assertTrue(json_path.exists())
            self.assertTrue(csv_path.exists())
            payload = json.loads(json_path.read_text(encoding="utf-8"))
            self.assertEqual([row["name"] for row in payload["standings"]], ["Minimal Centerline", "Simple Track Attack"])
            csv_text = csv_path.read_text(encoding="utf-8")
            self.assertIn("Minimal Centerline", csv_text)
            self.assertIn("Simple Track Attack", csv_text)

    def test_simple_track_attack_loads_standard_guide_by_default(self) -> None:
        previous = os.environ.pop("AIGP_TRACK_GUIDE", None)
        try:
            guide = TrackGuide(str(PROJECT_ROOT), TrackAttackConfig())
        finally:
            if previous is not None:
                os.environ["AIGP_TRACK_GUIDE"] = previous

        self.assertTrue(guide.ok)
        self.assertGreater(guide.n, 0)

    def test_windows_launcher_separates_race_export_from_diagnostics_batch(self) -> None:
        launcher_path = PROJECT_ROOT / "tools" / "aigp_windows_launcher.py"
        spec = importlib.util.spec_from_file_location("aigp_windows_launcher_for_test", launcher_path)
        self.assertIsNotNone(spec)
        assert spec is not None and spec.loader is not None
        launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(launcher)

        main_labels = {key: label for key, label, _descriptions, _action in launcher.MAIN_MENU}
        self.assertEqual(set(main_labels), {"1", "2"})
        self.assertEqual(main_labels["1"], "Standard Mode")
        self.assertEqual(main_labels["2"], "Low Power Mode")

        diagnostic_labels = {key: label for key, label, _descriptions, _action in launcher.DIAGNOSTIC_MENU}
        self.assertIn("official Standard race", diagnostic_labels["3"])
        self.assertIn("diagnostics batch", diagnostic_labels["4"])
        self.assertIs(launcher.ACTION_ALIASES["race"], launcher._standard_race_export)
        self.assertIs(launcher.ACTION_ALIASES["batch"], launcher._standard_diagnostics_batch)

    def test_windows_launcher_official_setup_grid_loads_drivers_inactive(self) -> None:
        launcher_path = PROJECT_ROOT / "tools" / "aigp_windows_launcher.py"
        spec = importlib.util.spec_from_file_location("aigp_windows_launcher_official_grid_test", launcher_path)
        self.assertIsNotNone(spec)
        assert spec is not None and spec.loader is not None
        launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(launcher)

        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            drivers_dir = root / "drivers"
            drivers_dir.mkdir()
            nested_dir = drivers_dir / "nested"
            nested_dir.mkdir()
            (drivers_dir / "alpha_driver.py").write_text("class Driver: pass\n", encoding="utf-8")
            (nested_dir / "beta_driver.py").write_text("class Driver: pass\n", encoding="utf-8")
            (drivers_dir / "driver_template.py").write_text("class Driver: pass\n", encoding="utf-8")
            (drivers_dir / "template.py").write_text("class Driver: pass\n", encoding="utf-8")
            (drivers_dir / "_helper.py").write_text("class Driver: pass\n", encoding="utf-8")

            captured: list[str] = []

            def fake_run(args: list[str]) -> int:
                captured.extend(args)
                return 0

            with (
                patch.object(launcher, "PROJECT_ROOT", root),
                patch.object(launcher, "RESULTS_DIR", root / ".rendered" / "launcher_results"),
                patch.object(launcher, "_run", fake_run),
            ):
                exit_code = launcher._official_grid_viewer()

            self.assertEqual(exit_code, 0)
            self.assertNotIn("--headless", captured)
            self.assertIn("--cars", captured)
            manifest_path = Path(captured[captured.index("--cars") + 1])
            payload = json.loads(manifest_path.read_text(encoding="utf-8"))
            self.assertEqual([entry["name"] for entry in payload], ["Alpha Driver", "Beta Driver"])
            self.assertEqual([entry["driver"] for entry in payload], ["drivers.alpha_driver", "drivers.nested.beta_driver"])
            self.assertTrue(all(entry["active"] is False for entry in payload))
            self.assertEqual(launcher.ACTION_ALIASES["official-grid"], launcher._official_grid_viewer)

    def test_presentation_launcher_action_is_hidden_from_main_menu_and_maxes_visual_budget(self) -> None:
        launcher_path = PROJECT_ROOT / "tools" / "aigp_windows_launcher.py"
        spec = importlib.util.spec_from_file_location("aigp_windows_launcher_presentation_test", launcher_path)
        self.assertIsNotNone(spec)
        assert spec is not None and spec.loader is not None
        launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(launcher)

        captured: list[str] = []

        def fake_run(args: list[str]) -> int:
            captured.extend(args)
            return 0

        with patch.object(launcher, "_run", fake_run):
            exit_code = launcher._presentation_viewer()

        self.assertEqual(exit_code, 0)
        self.assertIn("presentation", launcher.ACTION_ALIASES)
        self.assertNotIn("presentation", {label.lower() for _key, label, _descriptions, _action in launcher.MAIN_MENU})
        self.assertIn("--scene-render-hz", captured)
        self.assertEqual(captured[captured.index("--scene-render-hz") + 1], "120")
        self.assertIn("--render-scale", captured)
        self.assertEqual(captured[captured.index("--render-scale") + 1], "1.0")
        self.assertIn("--scene-complexity", captured)
        self.assertEqual(captured[captured.index("--scene-complexity") + 1], "full")

    def test_event_day_windows_shortcuts_point_to_launcher_actions(self) -> None:
        shortcuts = {
            "AIGP Run Official Race.bat": "--action race",
            "AIGP Official Race Setup.bat": "--action official-grid",
            "AIGP Health Check.bat": "--action health",
            "AIGP Presentation.bat": "--action presentation",
        }
        for filename, expected_action in shortcuts.items():
            with self.subTest(filename=filename):
                path = PROJECT_ROOT / filename
                self.assertTrue(path.is_file())
                text = path.read_text(encoding="utf-8")
                self.assertIn('call "AIGP Launcher.bat"', text)
                self.assertIn(expected_action, text)

        launcher_text = (PROJECT_ROOT / "AIGP Launcher.bat").read_text(encoding="utf-8")
        self.assertIn("--menu main", launcher_text)

        diagnostic_text = (PROJECT_ROOT / "AIGP Diagnostic Launcher.bat").read_text(encoding="utf-8")
        self.assertIn("--menu diagnostic", diagnostic_text)

        event_readme = PROJECT_ROOT / "AIGP Event Day README.txt"
        self.assertTrue(event_readme.is_file())
        readme_text = event_readme.read_text(encoding="utf-8")
        self.assertIn("AIGP Run Official Race.bat", readme_text)
        self.assertIn(".rendered\\launcher_results", readme_text)

    def test_windows_launcher_returns_to_prompt_after_action_closes(self) -> None:
        launcher_path = PROJECT_ROOT / "tools" / "aigp_windows_launcher.py"
        spec = importlib.util.spec_from_file_location("aigp_windows_launcher_loop_test", launcher_path)
        self.assertIsNotNone(spec)
        assert spec is not None and spec.loader is not None
        launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(launcher)

        calls = []

        def fake_action() -> int:
            calls.append("ran")
            return 0

        menu = (("1", "Fake AIGP", ("test action",), fake_action),)
        output = io.StringIO()
        with patch("builtins.input", side_effect=["1", "q"]), contextlib.redirect_stdout(output):
            exit_code = launcher._run_menu("Test Launcher", menu)

        self.assertEqual(exit_code, 0)
        self.assertEqual(calls, ["ran"])
        self.assertIn("AIGP was closed. Returning to the launcher menu.", output.getvalue())

    def test_low_power_launcher_keeps_sensor_geometry_unchanged(self) -> None:
        launcher_path = PROJECT_ROOT / "tools" / "aigp_windows_launcher.py"
        spec = importlib.util.spec_from_file_location("aigp_windows_launcher_low_power_test", launcher_path)
        self.assertIsNotNone(spec)
        assert spec is not None and spec.loader is not None
        launcher = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(launcher)

        captured = []

        def fake_run(args: list[str]) -> int:
            captured.extend(args)
            return 0

        with patch.object(launcher, "_run", fake_run):
            exit_code = launcher._standard_low_power_viewer()

        self.assertEqual(exit_code, 0)
        self.assertIn("--scene-render-hz", captured)
        self.assertEqual(captured[captured.index("--scene-render-hz") + 1], "20")
        self.assertIn("--render-scale", captured)
        self.assertEqual(captured[captured.index("--render-scale") + 1], "0.55")
        self.assertNotIn("--scene-complexity", captured)


if __name__ == "__main__":
    unittest.main()
