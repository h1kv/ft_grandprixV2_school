from __future__ import annotations

import math
import unittest

from aigp.advanced_dynamics import camber_turn_factor, combine_surface_dynamics, vertical_load_factor


class AdvancedDynamicsTests(unittest.TestCase):
    def test_signed_camber_supports_only_the_matching_turn_direction(self) -> None:
        right_turn_supported = camber_turn_factor(math.radians(12.0), turn_direction=-1.0, turn_intensity=1.0)
        left_turn_off_camber = camber_turn_factor(math.radians(12.0), turn_direction=1.0, turn_intensity=1.0)

        self.assertGreater(right_turn_supported, 1.0)
        self.assertLess(left_turn_off_camber, 1.0)
        self.assertGreater(right_turn_supported, left_turn_off_camber)

    def test_vertical_load_factor_distinguishes_crests_from_compressions(self) -> None:
        crest = vertical_load_factor(9.5, -0.08)
        flat = vertical_load_factor(9.5, 0.0)
        compression = vertical_load_factor(9.5, 0.08)

        self.assertLess(crest, flat)
        self.assertGreater(compression, flat)

    def test_combined_surface_dynamics_penalize_light_off_camber_turns(self) -> None:
        supportive = combine_surface_dynamics(
            base_grip=1.0,
            base_drag=1.0,
            bank_radians=math.radians(12.0),
            terrain_mix=0.0,
            roughness=0.0,
            grade=0.0,
            speed=8.5,
            vertical_curvature=0.05,
            turn_direction=-1.0,
            turn_intensity=0.95,
        )
        hostile = combine_surface_dynamics(
            base_grip=1.0,
            base_drag=1.0,
            bank_radians=math.radians(12.0),
            terrain_mix=0.0,
            roughness=0.0,
            grade=0.0,
            speed=8.5,
            vertical_curvature=-0.05,
            turn_direction=1.0,
            turn_intensity=0.95,
        )

        self.assertGreater(supportive.grip_scale, hostile.grip_scale)
        self.assertGreater(supportive.load_factor, hostile.load_factor)
        self.assertGreater(supportive.camber_factor, hostile.camber_factor)


if __name__ == "__main__":
    unittest.main()
