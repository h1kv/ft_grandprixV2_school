from __future__ import annotations

import math
import os
from pathlib import Path
import tempfile
import unittest

import numpy as np
import pygame

from aigp.advanced_sensors import ADVANCED_LIDAR_RING_PITCHES, ADVANCED_LIDAR_RAYS
from aigp.app import DriverWrapper, RaceApp, RaceConfig, START_LIGHT_COUNT, VehicleRuntime, _advanced_body_surface_offset, _euler_to_matrix, _render_pitch


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEST_DRIVER = PROJECT_ROOT / "drivers" / "minimal_centerline.py"


def _make_vehicle(vehicle_id: int, name: str) -> VehicleRuntime:
    return VehicleRuntime(
        id=vehicle_id,
        name=name,
        driver_ref=str(TEST_DRIVER),
        driver_path=TEST_DRIVER,
        controller=DriverWrapper(TEST_DRIVER),
        joint_name=f"car_{vehicle_id}",
        body_name=f"car_{vehicle_id}",
        sensor_ids=np.zeros(0, dtype=np.int32),
        spawn_progress=0.0,
        spawn_lateral_offset=0.0,
    )


class RuntimeModeTests(unittest.TestCase):
    def _make_app(self) -> RaceApp:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        return app

    def test_watch_vehicle_and_trackside_cycle(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        self.assertGreater(len(app.trackside_cameras), 0)
        app._watch_vehicle(1)
        self.assertEqual(app.watching, 1)
        self.assertEqual(app.camera_mode, "follow")
        app._cycle_trackside_view()
        self.assertEqual(app.camera_mode, "trackside")
        self.assertGreaterEqual(app.trackside_camera_index, 0)

    def test_standard_mode_does_not_load_advanced_world(self) -> None:
        app = self._make_app()
        self.assertIsNone(app.advanced_world)
        self.assertNotIn("alpine", app.available_tracks)

    def test_advanced_mode_loads_default_track_and_catalog(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                track="missing-track",
                cars_data=[],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        self.assertIsNotNone(app.advanced_world)
        self.assertEqual(app.track_settings.name, "alpine")
        self.assertIn("alpine", app.available_tracks)
        self.assertIn("summit", app.available_tracks)

    def test_advanced_mode_rejects_invalid_catalog_with_clear_error(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        temp_template = tempfile.TemporaryDirectory()
        self.addCleanup(temp_template.cleanup)
        template_dir = Path(temp_template.name) / "template"
        broken_dir = template_dir / "advanced" / "broken"
        broken_dir.mkdir(parents=True)
        (broken_dir / "advanced.toml").write_text(
            "display_name = 'Broken'\n"
            "base_track = 'track'\n"
            "\n"
            "[terrain]\n"
            "heightmap = 'missing.png'\n",
            encoding="utf-8",
        )

        with self.assertRaisesRegex(ValueError, "No valid advanced tracks were found"):
            RaceApp(
                RaceConfig(
                    headless=True,
                    world_mode="advanced",
                    template_dir=str(template_dir),
                    cars_data=[],
                    rendered_dir=temp_render.name,
                    drivers_dir=str(PROJECT_ROOT / "drivers"),
                )
            )

    def test_advanced_mode_uses_multiring_lidar_shape(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        self.assertEqual(vehicle.last_ranges.shape, (len(ADVANCED_LIDAR_RING_PITCHES), ADVANCED_LIDAR_RAYS))
        self.assertEqual(vehicle.last_legacy_ranges.shape, (ADVANCED_LIDAR_RAYS,))

    def test_advanced_driver_receives_structured_observation(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        temp_driver_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_driver_dir.cleanup)
        driver_path = Path(temp_driver_dir.name) / "advanced_probe.py"
        driver_path.write_text(
            "class Driver:\n"
            "    def __init__(self):\n"
            "        self.last_shape = None\n"
            "        self.last_grounded = None\n"
            "        self.last_vertical = None\n"
            "    def process_advanced(self, observation):\n"
            "        self.last_shape = tuple(int(v) for v in observation.lidar.shape)\n"
            "        self.last_grounded = bool(observation.grounded)\n"
            "        self.last_vertical = (float(observation.ride_height), float(observation.vertical_velocity), float(observation.airborne_time), float(observation.body_velocity[2]))\n"
            "        return 4.0, 0.0\n",
            encoding="utf-8",
        )
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": str(driver_path), "name": "Probe"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        app._step()
        driver = app.vehicles[0].controller.driver
        self.assertEqual(driver.last_shape, (len(ADVANCED_LIDAR_RING_PITCHES), ADVANCED_LIDAR_RAYS))
        self.assertTrue(driver.last_grounded)
        self.assertEqual(driver.last_vertical, (0.0, 0.0, 0.0, 0.0))

    def test_shipped_advanced_driver_reaches_useful_test_speed(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                track="alpine",
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
                auto_reload=False,
            )
        )
        self.addCleanup(app.close)
        app.paused = False
        speeds: list[float] = []
        commands: list[float] = []
        for _ in range(1600):
            app._step()
            vehicle = app.vehicles[0]
            speeds.append(abs(float(vehicle.speed)))
            commands.append(float(vehicle.target_speed))

        vehicle = app.vehicles[0]
        self.assertGreater(float(np.mean(speeds)), 3.0)
        self.assertGreater(float(np.max(commands)), 7.0)
        self.assertEqual(vehicle.wall_contacts + vehicle.car_contacts, 0)

    def test_legacy_driver_receives_flattened_lidar_in_advanced_mode(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        temp_driver_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_driver_dir.cleanup)
        driver_path = Path(temp_driver_dir.name) / "legacy_probe.py"
        driver_path.write_text(
            "import numpy as np\n"
            "class Driver:\n"
            "    def __init__(self):\n"
            "        self.last_ndim = None\n"
            "        self.last_size = None\n"
            "    def process_lidar(self, ranges, state=None):\n"
            "        data = np.asarray(ranges)\n"
            "        self.last_ndim = int(data.ndim)\n"
            "        self.last_size = int(data.size)\n"
            "        return 4.0, 0.0\n",
            encoding="utf-8",
        )
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": str(driver_path), "name": "Legacy"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        app._step()
        driver = app.vehicles[0].controller.driver
        self.assertEqual(driver.last_ndim, 1)
        self.assertEqual(driver.last_size, ADVANCED_LIDAR_RAYS)

    def test_advanced_surface_updates_height_and_orientation(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        assert app.geometry is not None
        vehicle = app.vehicles[0]
        progress = app.geometry.total_length * 0.38
        point, tangent, normal = app.geometry.point_at(progress, lateral_offset=0.7)
        vehicle.position[:] = point
        vehicle.yaw = math.atan2(float(tangent[1]), float(tangent[0]))
        app._update_vehicle_surface_state(vehicle)
        self.assertGreater(vehicle.surface_height, 1.0)
        self.assertGreater(abs(vehicle.pitch) + abs(vehicle.roll), 0.01)

    def test_advanced_crests_reduce_surface_load_relative_to_compressions(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                track="summit",
                cars_data=[{"driver": "drivers.advanced_alpine_runner", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        assert app.geometry is not None
        assert app.advanced_world is not None
        vehicle = app.vehicles[0]
        crest_index = int(np.argmin(app.advanced_world.vertical_curvature))
        compression_index = int(np.argmax(app.advanced_world.vertical_curvature))

        crest_progress = float(app.geometry.cumulative_lengths[crest_index])
        crest_point, crest_tangent, _crest_normal = app.geometry.point_at(crest_progress)
        vehicle.position[:] = crest_point
        vehicle.track_index_hint = crest_index
        vehicle.yaw = math.atan2(float(crest_tangent[1]), float(crest_tangent[0]))
        app._set_vehicle_planar_velocity(vehicle, forward_speed=9.0, lateral_speed=0.0)
        app._update_vehicle_surface_state(vehicle)
        crest_load = vehicle.surface_load

        compression_progress = float(app.geometry.cumulative_lengths[compression_index])
        compression_point, compression_tangent, _compression_normal = app.geometry.point_at(compression_progress)
        vehicle.position[:] = compression_point
        vehicle.track_index_hint = compression_index
        vehicle.yaw = math.atan2(float(compression_tangent[1]), float(compression_tangent[0]))
        app._set_vehicle_planar_velocity(vehicle, forward_speed=9.0, lateral_speed=0.0)
        app._update_vehicle_surface_state(vehicle)
        compression_load = vehicle.surface_load

        self.assertLess(crest_load, 1.0)
        self.assertGreater(compression_load, 1.0)
        self.assertLess(crest_load, compression_load)

    def test_advanced_track_rebuild_keeps_world_loaded(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        original_length = app.geometry.total_length
        app.edit_track_settings.track_scale = 0.82
        app._apply_track_changes()
        self.assertIsNotNone(app.advanced_world)
        self.assertEqual(app.track_settings.name, "alpine")
        self.assertNotAlmostEqual(app.geometry.total_length, original_length, delta=0.1)

    def test_driver_settings_panel_scrolls_expanded_card_into_view(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta"},
                    {"driver": "drivers.ultimate", "name": "Gamma"},
                    {"driver": "drivers.driver_01", "name": "Delta"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        app.selected_tab = "Drivers"
        app.panel_rect = pygame.Rect(900, 16, 432, 720)
        app._toggle_driver_settings(2)

        bounds = app._driver_card_bounds(2)
        self.assertIsNotNone(bounds)
        assert bounds is not None
        top, bottom = bounds
        self.assertEqual(app._driver_card_height(2), app.DRIVER_CARD_EXPANDED_HEIGHT)
        self.assertGreater(app.drivers_scroll, 0)
        self.assertLessEqual(bottom - app.drivers_scroll, app._drivers_visible_height())

        next_bounds = app._driver_card_bounds(3)
        self.assertIsNotNone(next_bounds)
        assert next_bounds is not None
        self.assertEqual(next_bounds[0], bottom + app.DRIVER_CARD_GAP)

    def test_settings_handle_stays_outside_open_panel(self) -> None:
        app = self._make_app()
        app.render_rect = pygame.Rect(16, 16, 960, 720)
        app.panel_rect = pygame.Rect(990, 16, 432, 720)
        app.settings_visible = True

        handle_rect = app._settings_handle_rect()

        self.assertLess(handle_rect.left, app.panel_rect.x)
        self.assertLessEqual(handle_rect.right, app.panel_rect.x + 1)
        self.assertEqual(handle_rect.y, app.render_rect.y + 18)

    def test_layout_uses_full_race_area_when_settings_are_hidden_or_detached(self) -> None:
        app = self._make_app()
        window_size = (1920, 1080)

        app.settings_visible = False
        app.settings_detached = False
        hidden_render, hidden_panel = app._layout(window_size)

        app.settings_visible = True
        app.settings_detached = True
        detached_render, detached_panel = app._layout(window_size)

        app.settings_visible = True
        app.settings_detached = False
        embedded_render, embedded_panel = app._layout(window_size)

        self.assertEqual(hidden_panel, None)
        self.assertEqual(detached_panel, None)
        self.assertEqual(hidden_render.width, window_size[0] - 32)
        self.assertEqual(detached_render.width, hidden_render.width)
        self.assertIsNotNone(embedded_panel)
        self.assertLess(embedded_render.width, hidden_render.width)

    def test_inactive_driver_remains_in_roster_but_is_not_staged(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Inactive", "active": False},
                    {"driver": "drivers.simple_track_attack", "name": "Active"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)

        self.assertEqual(len(app.cars_raw), 2)
        self.assertFalse(app.cars_raw[0]["active"])
        self.assertTrue(app.cars_raw[1]["active"])
        self.assertEqual(len(app.vehicles), 1)
        self.assertEqual(app.vehicles[0].name, "Active")
        self.assertEqual(app.vehicles[0].car_index, 1)
        self.assertEqual(app._vehicle_for_car_index(0), None)
        self.assertIs(app._vehicle_for_car_index(1), app.vehicles[0])
        self.assertEqual(len(app.build_results()["standings"]), 1)

    def test_driver_active_toggle_restages_without_deleting_roster_entry(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta", "active": False},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)

        self.assertEqual([vehicle.name for vehicle in app.vehicles], ["Alpha"])

        app._set_driver_active(1, True)
        self.assertEqual(len(app.cars_raw), 2)
        self.assertEqual([vehicle.name for vehicle in app.vehicles], ["Alpha", "Beta"])
        self.assertTrue(app.cars_raw[1]["active"])

        app._set_driver_active(0, False)
        self.assertEqual(len(app.cars_raw), 2)
        self.assertEqual([vehicle.name for vehicle in app.vehicles], ["Beta"])
        self.assertFalse(app.cars_raw[0]["active"])

    def test_cycle_driver_source_updates_car_entry_and_vehicle_driver(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)

        app._cycle_driver_source(0, 1)

        self.assertEqual(app.cars_raw[0]["driver"], "drivers.simple_track_attack")
        self.assertEqual(app.vehicles[0].driver_ref, "drivers.simple_track_attack")
        self.assertTrue(app.vehicles[0].driver_path.name.endswith("simple_track_attack.py"))

    def test_set_driver_color_accepts_custom_rgb_values(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)

        app._set_driver_color(0, "primary", (12, 34, 56))

        self.assertEqual(app.cars_raw[0]["primary"], [12, 34, 56])

    def test_driver_calls_follow_sensor_cadence(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
                physics_hz=120,
                sensor_hz=60,
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]

        for _ in range(4):
            app._step()

        self.assertEqual(vehicle.driver_call_count, 2)

    def test_spawn_positions_start_inside_track_corridor(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta"},
                    {"driver": "drivers.ultimate", "name": "Gamma"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        for vehicle in app.vehicles:
            self.assertTrue(app._vehicle_is_on_track(vehicle))

    def test_wall_side_clearance_matches_vehicle_collision_box(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        segment = app.geometry.wall_segments[0]
        center = np.asarray(segment.position[:2], dtype=np.float32)
        tangent = np.array([math.cos(segment.yaw), math.sin(segment.yaw)], dtype=np.float32)
        normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
        clear_position = center + normal * (float(segment.size[1]) + app.config.car_half_width + 0.002)
        overlap_position = center + normal * (float(segment.size[1]) + app.config.car_half_width - 0.010)

        self.assertIsNone(app._wall_segment_overlap(vehicle, segment, position=clear_position, yaw=segment.yaw))
        overlap = app._wall_segment_overlap(vehicle, segment, position=overlap_position, yaw=segment.yaw)
        self.assertIsNotNone(overlap)
        assert overlap is not None
        self.assertAlmostEqual(overlap[1], 0.01, delta=0.002)

    def test_vehicle_accelerates_normally_from_spawn(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        for _ in range(60):
            app._step()
        self.assertGreater(vehicle.speed, 1.0)
        self.assertGreater(app.sim_time, 0.3)

    def test_gui_launch_starts_paused_and_uses_countdown(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=False,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        self.assertTrue(app.paused)
        self.assertTrue(app.awaiting_race_start)
        app._toggle_pause_or_start()
        self.assertTrue(app.countdown_active)
        self.assertTrue(app.paused)
        app._update_start_sequence(START_LIGHT_COUNT + 0.1)
        self.assertFalse(app.countdown_active)
        self.assertFalse(app.awaiting_race_start)
        self.assertFalse(app.paused)

    def test_trackside_reverse_returns_to_monitored_driver(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        app._watch_vehicle(0)
        app._step_trackside_relative(1)
        self.assertEqual(app.camera_mode, "trackside")
        app._step_trackside_relative(-1)
        self.assertEqual(app.camera_mode, "follow")
        self.assertEqual(app.watching, 0)

    def test_wall_penetration_is_clamped_back_inside_the_track(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        wall_a = app.geometry.outer_wall_face[0]
        wall_b = app.geometry.outer_wall_face[1]
        wall_mid = 0.5 * (wall_a + wall_b)
        wall_tangent = wall_b - wall_a
        wall_tangent = wall_tangent / max(1e-6, float(np.linalg.norm(wall_tangent)))
        wall_normal = np.array([wall_tangent[1], -wall_tangent[0]], dtype=np.float32)
        _index, center, _tangent, _offset, progress = app.geometry.project(wall_mid)
        if float(np.dot(center - wall_mid, wall_normal)) < 0.0:
            wall_normal = -wall_normal
        previous = wall_mid + wall_normal * 0.25
        vehicle.position[:] = wall_mid - wall_normal * 0.35
        vehicle.spawn_progress = progress
        vehicle.raw_progress = 0.0
        vehicle.wall_touching = False
        vehicle.speed = 4.0
        vehicle.yaw = math.atan2(float(-wall_normal[1]), float(-wall_normal[0]))

        hit = app._resolve_wall_penetration(vehicle, previous)

        self.assertTrue(hit)
        self.assertTrue(vehicle.wall_touching)
        self.assertGreaterEqual(vehicle.wall_contacts, 1)
        self.assertAlmostEqual(vehicle.speed, 0.0, delta=1e-5)
        _index, _point, tangent, signed_offset, _progress = app.geometry.project(
            vehicle.position,
            hint_progress=app._absolute_track_progress(vehicle),
        )
        barrier_limit = app.geometry.barrier_inner_face_offset - app._vehicle_lateral_support(vehicle, tangent)
        self.assertLessEqual(abs(signed_offset), barrier_limit + 1e-3)

    def test_wall_segment_boxes_resolve_as_solid_barriers(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None

        target = None
        for segment in app.geometry.wall_segments:
            center = np.asarray(segment.position[:2], dtype=np.float32)
            tangent = np.array([math.cos(segment.yaw), math.sin(segment.yaw)], dtype=np.float32)
            normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
            corners = [
                center + tangent * sx * float(segment.size[0]) + normal * sy * float(segment.size[1])
                for sx in (-1.0, 1.0)
                for sy in (-1.0, 1.0)
            ]
            for corner in corners:
                if not app.geometry.is_point_on_track(corner.astype(np.float32), clearance=0.0):
                    continue
                into_wall = center - corner
                norm = float(np.linalg.norm(into_wall))
                if norm <= 1e-6:
                    continue
                into_wall = into_wall / norm
                previous = corner - into_wall * 0.03
                current = corner + into_wall * 0.05
                if app._wall_segment_overlap(vehicle, segment, position=current.astype(np.float32)) is None:
                    continue
                target = (segment, previous.astype(np.float32), current.astype(np.float32))
                break
            if target is not None:
                break

        self.assertIsNotNone(target)
        assert target is not None
        segment, previous, current = target
        vehicle.position[:] = current
        vehicle.wall_touching = False
        vehicle.speed = 2.5

        app._stabilize_vehicle_after_motion(vehicle, previous)

        self.assertTrue(vehicle.wall_touching)
        self.assertGreaterEqual(vehicle.wall_contacts, 1)
        self.assertIsNone(app._wall_segment_overlap(vehicle, segment))
        self.assertTrue(app._vehicle_is_on_track(vehicle))

    def test_out_of_corridor_vehicle_is_recovered_to_last_safe_point(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        previous = None
        current = None
        for progress in app.geometry.cumulative_lengths[::12]:
            point, tangent, normal = app.geometry.point_at(float(progress))
            barrier_limit = app.geometry.barrier_inner_face_offset - app._vehicle_lateral_support(vehicle, tangent)
            for side in (1.0, -1.0):
                candidate_previous = point + normal * side * (barrier_limit - 0.10)
                candidate_current = point + normal * side * (barrier_limit + 0.35)
                if app._vehicle_is_on_track(vehicle, position=candidate_previous, hint_progress=float(progress)) and not app._vehicle_is_on_track(
                    vehicle,
                    position=candidate_current,
                    hint_progress=float(progress),
                ):
                    previous = candidate_previous
                    current = candidate_current
                    break
            if previous is not None:
                break
        self.assertIsNotNone(previous)
        self.assertIsNotNone(current)
        assert previous is not None
        assert current is not None
        vehicle.position[:] = current
        vehicle.wall_touching = False
        vehicle.speed = 3.0

        recovered = app._recover_to_track_corridor(vehicle, previous)

        self.assertTrue(recovered)
        self.assertTrue(app._vehicle_is_on_track(vehicle))
        self.assertTrue(vehicle.wall_touching)
        self.assertGreaterEqual(vehicle.wall_contacts, 1)

    def test_vehicle_restores_last_safe_state_when_outside_track(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        point, tangent, normal = app.geometry.point_at(vehicle.spawn_progress)
        barrier_limit = app.geometry.barrier_inner_face_offset - app._vehicle_lateral_support(vehicle, tangent)
        vehicle.last_safe_position[:] = point
        vehicle.position[:] = point + normal * (
            barrier_limit + app.geometry.settings.wall_thickness + app._vehicle_lateral_support(vehicle, tangent) + 0.95
        )
        vehicle.speed = 4.0

        app._restore_last_safe_state(vehicle)

        np.testing.assert_allclose(vehicle.position, point, atol=1e-5)
        self.assertEqual(vehicle.speed, 0.0)
        self.assertTrue(app._vehicle_is_on_track(vehicle))

    def test_restore_does_not_teleport_normal_wall_crash_positions(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        point, tangent, normal = app.geometry.point_at(vehicle.spawn_progress)
        barrier_limit = app.geometry.barrier_inner_face_offset - app._vehicle_lateral_support(vehicle, tangent)
        crashed = point + normal * (barrier_limit + 0.25)
        vehicle.last_safe_position[:] = point
        vehicle.position[:] = crashed
        vehicle.speed = 2.0

        app._restore_last_safe_state(vehicle)

        np.testing.assert_allclose(vehicle.position, crashed, atol=1e-5)
        self.assertEqual(vehicle.speed, 2.0)

    def test_vehicle_collision_resolution_uses_box_footprint(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        alpha, beta = app.vehicles
        assert app.geometry is not None
        spacing = app.config.car_half_width + 0.01
        overlap_spacing = app.config.car_half_width - 0.01
        candidate = None
        for progress in app.geometry.cumulative_lengths[::12]:
            point, tangent, normal = app.geometry.point_at(float(progress))
            yaw = math.atan2(float(tangent[1]), float(tangent[0]))
            alpha.yaw = yaw
            beta.yaw = yaw
            clear_alpha = point - normal * spacing
            clear_beta = point + normal * spacing
            if not app._vehicle_is_on_track(alpha, position=clear_alpha, hint_progress=float(progress)):
                continue
            if not app._vehicle_is_on_track(beta, position=clear_beta, hint_progress=float(progress)):
                continue
            hit_alpha = point - normal * overlap_spacing
            hit_beta = point + normal * overlap_spacing
            overlap = app._vehicle_pair_overlap(alpha, beta, position_a=hit_alpha, position_b=hit_beta)
            if overlap is None:
                continue
            push, penetration = overlap
            correction = push * (penetration * 0.5 + 1e-3)
            if not app._vehicle_is_on_track(alpha, position=hit_alpha + correction, hint_progress=float(progress)):
                continue
            if not app._vehicle_is_on_track(beta, position=hit_beta - correction, hint_progress=float(progress)):
                continue
            candidate = (point, normal, yaw)
            break

        self.assertIsNotNone(candidate)
        assert candidate is not None
        point, normal, yaw = candidate
        alpha.yaw = yaw
        beta.yaw = yaw
        alpha.position[:] = point - normal * spacing
        beta.position[:] = point + normal * spacing
        app._resolve_vehicle_collisions()

        self.assertIsNone(app._vehicle_pair_overlap(alpha, beta))
        self.assertEqual(alpha.car_contacts, 0)
        self.assertEqual(beta.car_contacts, 0)

        alpha.position[:] = point - normal * overlap_spacing
        beta.position[:] = point + normal * overlap_spacing
        alpha.speed = 5.0
        beta.speed = 5.0

        app._resolve_vehicle_collisions()

        self.assertEqual(alpha.car_contacts, 1)
        self.assertEqual(beta.car_contacts, 1)
        self.assertIsNone(app._vehicle_pair_overlap(alpha, beta))
        self.assertTrue(app._vehicle_is_on_track(alpha))
        self.assertTrue(app._vehicle_is_on_track(beta))
        self.assertAlmostEqual(alpha.speed, 5.0, delta=0.05)
        self.assertAlmostEqual(beta.speed, 5.0, delta=0.05)

    def test_rear_end_collision_transfers_speed_forward(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[
                    {"driver": "drivers.minimal_centerline", "name": "Alpha"},
                    {"driver": "drivers.simple_track_attack", "name": "Beta"},
                ],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        alpha, beta = app.vehicles
        assert app.geometry is not None
        point, tangent, _normal = app.geometry.point_at(0.0)
        yaw = math.atan2(float(tangent[1]), float(tangent[0]))
        alpha.yaw = yaw
        beta.yaw = yaw
        alpha.position[:] = point + tangent * 0.28
        beta.position[:] = point - tangent * 0.28
        app._set_vehicle_planar_velocity(alpha, forward_speed=2.0, lateral_speed=0.0)
        app._set_vehicle_planar_velocity(beta, forward_speed=5.0, lateral_speed=0.0)

        app._resolve_vehicle_collisions()

        self.assertEqual(alpha.car_contacts, 1)
        self.assertEqual(beta.car_contacts, 1)
        self.assertIsNone(app._vehicle_pair_overlap(alpha, beta))
        self.assertGreater(alpha.speed, 2.5)
        self.assertLess(beta.speed, 4.5)
        self.assertAlmostEqual(alpha.speed + beta.speed, 7.0, delta=0.2)

    def test_acceleration_braking_and_drag_follow_configured_rates(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        dt = 0.05
        drag = 1.0 / (1.0 + app.config.drag_coefficient * dt)

        vehicle.target_speed = app.config.max_speed_command
        vehicle.target_steer = 0.0
        vehicle.speed = 0.0
        app._advance_vehicle(vehicle, dt)

        self.assertAlmostEqual(vehicle.speed, app.config.accel_rate * dt * drag, delta=1e-5)

        vehicle.target_speed = 0.0
        vehicle.target_steer = 0.0
        vehicle.speed = 6.0
        app._advance_vehicle(vehicle, dt)

        expected_braking = (6.0 - app.config.brake_rate * dt) * drag
        self.assertAlmostEqual(vehicle.speed, expected_braking, delta=1e-5)

    def test_surface_dynamics_reduce_grip_near_track_edge(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        point, tangent, normal = app.geometry.point_at(vehicle.spawn_progress)
        support = app._vehicle_lateral_support(vehicle, tangent)
        track_limit = max(0.0, app.geometry.settings.half_width - support)
        barrier_limit = max(track_limit, app.geometry.barrier_inner_face_offset - support)
        edge_offset = min(barrier_limit - 0.01, track_limit + max(0.05, (barrier_limit - track_limit) * 0.55))

        center_grip, center_drag, _center_surface, _center_factors = app._surface_dynamics(vehicle, position=point, hint_progress=vehicle.spawn_progress)
        edge_grip, edge_drag, _edge_surface, _edge_factors = app._surface_dynamics(
            vehicle,
            position=point + normal * edge_offset,
            hint_progress=vehicle.spawn_progress,
        )

        self.assertLess(edge_grip, center_grip)
        self.assertGreater(edge_drag, center_drag)

    def test_high_speed_cornering_produces_lateral_slide(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        vehicle.target_speed = 10.5
        vehicle.target_steer = 1.0
        vehicle.speed = 10.5
        app._set_vehicle_planar_velocity(vehicle, forward_speed=10.5)
        no_slip_yaw_rate = vehicle.speed / app.config.wheelbase * math.tan(app.config.max_steer_angle)

        app._advance_vehicle(vehicle, 0.05)

        _forward_axis, lateral_axis = app._vehicle_axes(vehicle.yaw)
        lateral_speed = float(np.dot(vehicle.velocity[:2], lateral_axis))
        self.assertGreater(abs(lateral_speed), 0.10)
        self.assertLess(abs(vehicle.yaw_rate), abs(no_slip_yaw_rate) * 0.75)

    def test_sync_vehicle_pose_keeps_car_grounded(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]

        for _ in range(8):
            app._step()

        joint = app.data.joint(vehicle.joint_name)
        self.assertAlmostEqual(float(joint.qpos[2]), 0.08, delta=1e-6)
        self.assertAlmostEqual(float(joint.qvel[2]), 0.0, delta=1e-6)
        self.assertAlmostEqual(float(vehicle.velocity[2]), 0.0, delta=1e-6)

    def test_advanced_sync_vehicle_pose_matches_wheel_contact_offset(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.advanced_alpine_runner", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]

        for _ in range(8):
            app._step()

        joint = app.data.joint(vehicle.joint_name)
        expected = vehicle.surface_height + _advanced_body_surface_offset(vehicle.roll, _render_pitch(vehicle.pitch))
        self.assertAlmostEqual(float(joint.qpos[2]), expected, delta=1e-6)
        self.assertLess(float(joint.qpos[2] - vehicle.surface_height), 0.05)
        forward_axis = _euler_to_matrix(vehicle.roll, _render_pitch(vehicle.pitch), vehicle.yaw)[:, 0]
        if vehicle.surface_grade > 0.01:
            self.assertGreater(float(forward_axis[2]), 0.0)
        elif vehicle.surface_grade < -0.01:
            self.assertLess(float(forward_axis[2]), 0.0)

    def test_advanced_crests_launch_with_real_vertical_pose(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.advanced_alpine_runner", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        assert app.advanced_world is not None
        dt = 1.0 / app.config.physics_hz

        crest_index = int(np.argmin(app.advanced_world.vertical_curvature))
        crest_progress = float(app.geometry.cumulative_lengths[crest_index])
        crest_point, crest_tangent, _crest_normal = app.geometry.point_at(crest_progress)
        vehicle.position[:] = crest_point
        vehicle.track_index_hint = crest_index
        vehicle.yaw = math.atan2(float(crest_tangent[1]), float(crest_tangent[0]))
        app._set_vehicle_planar_velocity(vehicle, forward_speed=11.0)
        vehicle.grounded = True
        vehicle.light_contact_time = 0.0
        vehicle.contact_scrub_time = 0.0

        app._update_vehicle_surface_state(vehicle, dt=dt)

        self.assertFalse(vehicle.grounded)
        self.assertGreater(vehicle.light_contact_time, 0.0)
        self.assertGreater(vehicle.ride_height, 0.0)
        self.assertGreater(vehicle.vertical_velocity, 0.0)

        app._sync_vehicle_pose(vehicle)
        joint = app.data.joint(vehicle.joint_name)
        expected_grounded = vehicle.surface_height + _advanced_body_surface_offset(vehicle.roll, _render_pitch(vehicle.pitch))
        self.assertGreater(float(joint.qpos[2]), expected_grounded)
        self.assertAlmostEqual(float(joint.qvel[2]), vehicle.vertical_velocity, delta=1e-6)

        vehicle.grounded = True
        vehicle.ride_height = 0.0
        vehicle.vertical_velocity = 0.0
        app._update_vehicle_surface_state(vehicle, dt=dt)

        self.assertTrue(vehicle.grounded)
        self.assertEqual(vehicle.vertical_velocity, 0.0)

    def test_advanced_airborne_motion_and_contact_scrub(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.advanced_alpine_runner", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]
        assert app.geometry is not None
        assert app.advanced_world is not None
        dt = 0.05

        vehicle.grounded = False
        vehicle.ride_height = 0.60
        vehicle.vertical_velocity = 1.20
        vehicle.airborne_time = 0.20
        vehicle.target_speed = 5.0
        vehicle.target_steer = 0.0
        vehicle.steer = 0.0
        app._set_vehicle_planar_velocity(vehicle, forward_speed=5.0)

        app._advance_vehicle(vehicle, dt)

        self.assertFalse(vehicle.grounded)
        self.assertAlmostEqual(vehicle.vertical_velocity, 1.20 - 9.81 * dt, delta=1e-5)
        self.assertGreater(vehicle.ride_height, 0.60)

        compression_index = int(np.argmax(app.advanced_world.vertical_curvature))
        compression_progress = float(app.geometry.cumulative_lengths[compression_index])
        compression_point, compression_tangent, _compression_normal = app.geometry.point_at(compression_progress)
        vehicle.position[:] = compression_point
        vehicle.track_index_hint = compression_index
        vehicle.yaw = math.atan2(float(compression_tangent[1]), float(compression_tangent[0]))
        app._set_vehicle_planar_velocity(vehicle, forward_speed=6.0)
        app._update_vehicle_surface_state(vehicle, dt=dt)
        vehicle.grounded = False
        vehicle.ride_height = -0.02
        vehicle.vertical_velocity = -3.0
        vehicle.airborne_time = 0.40

        app._update_vehicle_surface_state(vehicle, dt=dt)

        self.assertTrue(vehicle.grounded)
        self.assertGreater(vehicle.contact_scrub_time, 0.0)

        start_position = vehicle.position.copy()
        start_yaw = vehicle.yaw
        vehicle.target_speed = 6.0
        vehicle.target_steer = 0.0
        vehicle.steer = 0.0
        vehicle.contact_scrub_time = 0.0
        app._set_vehicle_planar_velocity(vehicle, forward_speed=6.0)
        app._advance_vehicle(vehicle, dt)
        baseline_speed = vehicle.speed

        vehicle.position[:] = start_position
        vehicle.yaw = start_yaw
        vehicle.target_speed = 6.0
        vehicle.target_steer = 0.0
        vehicle.steer = 0.0
        vehicle.contact_scrub_time = 0.30
        app._set_vehicle_planar_velocity(vehicle, forward_speed=6.0)
        app._advance_vehicle(vehicle, dt)

        self.assertLess(vehicle.speed, baseline_speed)
        self.assertLess(vehicle.contact_scrub_time, 0.30)

    def test_advanced_mode_prefers_the_shipped_advanced_cars_preset(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        self.assertIsNotNone(app.cars_file)
        assert app.cars_file is not None
        self.assertEqual(app.cars_file.name, "advanced_alpine.json")
        self.assertEqual(app.config.cars_path.replace("\\", "/"), "template/cars/advanced_alpine.json")
        self.assertEqual(len(app.vehicles), 1)
        self.assertEqual(app.vehicles[0].driver_ref, "drivers.advanced_alpine_runner")

    def test_advanced_mode_honors_explicit_default_cars_path(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        explicit_path = PROJECT_ROOT / "template" / "cars" / "aigpv2.json"
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_path=str(explicit_path),
                cars_path_explicit=True,
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        self.assertIsNotNone(app.cars_file)
        assert app.cars_file is not None
        self.assertEqual(app.cars_file.name, "aigpv2.json")
        self.assertEqual(app.config.cars_path, str(explicit_path))
        self.assertGreater(len(app.vehicles), 1)

    def test_advanced_mode_stages_continuous_curb_meshes(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                world_mode="advanced",
                cars_data=[{"driver": "drivers.advanced_alpine_runner", "name": "Alpha"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        assert app.session_dir is not None
        xml = (app.session_dir / "world.xml").read_text(encoding="utf-8")
        self.assertIn('mesh name="curb_red_mesh"', xml)
        self.assertIn('mesh name="curb_white_mesh"', xml)
        self.assertIn('geom name="curb_red"', xml)
        self.assertIn('geom name="curb_white"', xml)
        self.assertNotIn('geom name="curb_0"', xml)

    def test_qualifying_mode_orders_by_best_lap(self) -> None:
        app = self._make_app()
        alpha = _make_vehicle(0, "Alpha")
        beta = _make_vehicle(1, "Beta")
        alpha.lap_times = [12.8, 12.4]
        beta.lap_times = [13.2, 13.0]
        alpha.unwrapped_progress = 1.2
        beta.unwrapped_progress = 1.5
        app.vehicles = [alpha, beta]
        app._set_race_mode("qualifying")
        standings = app._standings()
        self.assertEqual([vehicle.name for vehicle in standings], ["Alpha", "Beta"])

    def test_clean_race_mode_orders_by_contact_count(self) -> None:
        app = self._make_app()
        alpha = _make_vehicle(0, "Alpha")
        beta = _make_vehicle(1, "Beta")
        alpha.wall_contacts = 1
        alpha.car_contacts = 0
        beta.wall_contacts = 0
        beta.car_contacts = 4
        alpha.unwrapped_progress = 0.3
        beta.unwrapped_progress = 0.95
        app.vehicles = [alpha, beta]
        app._set_race_mode("clean_race")
        standings = app._standings()
        self.assertEqual([vehicle.name for vehicle in standings], ["Alpha", "Beta"])

    def test_precision_mode_orders_by_mean_center_error(self) -> None:
        app = self._make_app()
        alpha = _make_vehicle(0, "Alpha")
        beta = _make_vehicle(1, "Beta")
        alpha.center_error_total = 18.0
        alpha.center_error_samples = 100
        beta.center_error_total = 40.0
        beta.center_error_samples = 100
        app.vehicles = [alpha, beta]
        app._set_race_mode("precision")
        standings = app._standings()
        self.assertEqual([vehicle.name for vehicle in standings], ["Alpha", "Beta"])

    def test_close_removes_staged_session_dir(self) -> None:
        app = self._make_app()
        self.assertIsNotNone(app.session_dir)
        assert app.session_dir is not None
        session_dir = app.session_dir
        self.assertTrue(session_dir.exists())
        app.close()
        self.assertFalse(session_dir.exists())

    def test_headless_run_stops_cleanly_when_no_drivers_are_loaded(self) -> None:
        app = self._make_app()
        standings = app.run()
        self.assertEqual(standings, [])
        self.assertEqual(app.stop_reason, "no vehicles loaded")
        self.assertEqual(app.step_count, 0)

    def test_missing_icon_does_not_break_mjcf_staging(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha", "icon": "missing.png"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        self.assertEqual(len(app.vehicles), 1)
        self.assertEqual(app.vehicles[0].name, "Alpha")

    def test_reduced_scene_complexity_stages_fewer_visual_segments(self) -> None:
        full_render = tempfile.TemporaryDirectory()
        reduced_render = tempfile.TemporaryDirectory()
        self.addCleanup(full_render.cleanup)
        self.addCleanup(reduced_render.cleanup)
        full = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=full_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
                reduced_scene_complexity=False,
            )
        )
        reduced = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": "drivers.minimal_centerline", "name": "Alpha"}],
                rendered_dir=reduced_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
                reduced_scene_complexity=True,
            )
        )
        self.addCleanup(full.close)
        self.addCleanup(reduced.close)
        assert full.session_dir is not None
        assert reduced.session_dir is not None

        full_xml = (full.session_dir / "world.xml").read_text(encoding="utf-8")
        reduced_xml = (reduced.session_dir / "world.xml").read_text(encoding="utf-8")

        self.assertLess(reduced_xml.count('name="wall_'), full_xml.count('name="wall_'))
        self.assertLess(reduced_xml.count('name="curb_'), full_xml.count('name="curb_'))

    def test_auto_reload_failure_updates_vehicle_error_state(self) -> None:
        temp_render = tempfile.TemporaryDirectory()
        self.addCleanup(temp_render.cleanup)
        driver_path = Path(temp_render.name) / "reload_me.py"
        driver_path.write_text(
            "class Driver:\n"
            "    def process_lidar(self, ranges, state=None):\n"
            "        return 1.0, 0.0\n",
            encoding="utf-8",
        )
        app = RaceApp(
            RaceConfig(
                headless=True,
                cars_data=[{"driver": str(driver_path), "name": "ReloadMe"}],
                rendered_dir=temp_render.name,
                drivers_dir=str(PROJECT_ROOT / "drivers"),
            )
        )
        self.addCleanup(app.close)
        vehicle = app.vehicles[0]

        driver_path.write_text("class Driver\n", encoding="utf-8")
        next_mtime = vehicle.controller.last_mtime + 5.0
        os.utime(driver_path, (next_mtime, next_mtime))
        app.last_reload_check = 0.0

        app._reload_changed_drivers()

        self.assertIsNotNone(vehicle.last_error)
        assert vehicle.last_error is not None
        self.assertIn("SyntaxError", vehicle.last_error)
        self.assertEqual(vehicle.error_count, 1)


if __name__ == "__main__":
    unittest.main()
