from __future__ import annotations

from pathlib import Path
import unittest

from aigp.track import DEFAULT_TRACKS, load_track_geometry


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_DIR = PROJECT_ROOT / "template"


def _segment_intersection(a, b, c, d) -> bool:
    def orient(p, q, r) -> float:
        return float((q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0]))

    o1 = orient(a, b, c)
    o2 = orient(a, b, d)
    o3 = orient(c, d, a)
    o4 = orient(c, d, b)
    return (o1 * o2 < -1e-6) and (o3 * o4 < -1e-6)


def _count_self_intersections(points) -> int:
    total = 0
    count = len(points)
    for i in range(count):
        a = points[i]
        b = points[(i + 1) % count]
        for j in range(i + 1, count):
            if j in {i, (i + 1) % count}:
                continue
            if (j + 1) % count in {i, (i + 1) % count}:
                continue
            c = points[j]
            d = points[(j + 1) % count]
            if _segment_intersection(a, b, c, d):
                total += 1
    return total


def _circular_index_gap(a: int, b: int, count: int) -> int:
    gap = abs(a - b)
    return min(gap, count - gap)


class TrackGeometryTests(unittest.TestCase):
    def test_default_track_has_no_boundary_self_intersections(self) -> None:
        geometry = load_track_geometry(TEMPLATE_DIR, DEFAULT_TRACKS["track"].copy())
        self.assertEqual(_count_self_intersections(geometry.track_inner), 0)
        self.assertEqual(_count_self_intersections(geometry.track_outer), 0)
        self.assertEqual(_count_self_intersections(geometry.inner_wall_face), 0)
        self.assertEqual(_count_self_intersections(geometry.outer_wall_face), 0)

    def test_track_scale_maps_50_percent_to_half_length(self) -> None:
        full = DEFAULT_TRACKS["track"].copy()
        half = DEFAULT_TRACKS["track"].copy()
        half.track_scale = 0.5
        full_geometry = load_track_geometry(TEMPLATE_DIR, full)
        half_geometry = load_track_geometry(TEMPLATE_DIR, half)
        ratio = full_geometry.total_length / half_geometry.total_length
        self.assertGreater(ratio, 1.95)
        self.assertLess(ratio, 2.05)

    def test_hinted_projection_prefers_the_local_track_branch(self) -> None:
        geometry = load_track_geometry(TEMPLATE_DIR, DEFAULT_TRACKS["track"].copy())
        pair: tuple[int, int] | None = None
        for i in range(len(geometry.centerline)):
            for j in range(i + 20, len(geometry.centerline)):
                distance = float(((geometry.centerline[i] - geometry.centerline[j]) ** 2).sum() ** 0.5)
                progress_gap = abs(float(geometry.cumulative_lengths[i] - geometry.cumulative_lengths[j]))
                progress_gap = min(progress_gap, geometry.total_length - progress_gap)
                if distance < 8.0 and progress_gap > 15.0:
                    pair = (i, j)
                    break
            if pair is not None:
                break

        self.assertIsNotNone(pair)
        assert pair is not None
        i, j = pair
        midpoint = (geometry.centerline[i] + geometry.centerline[j]) * 0.5
        projected_i = geometry.project(midpoint, hint_progress=float(geometry.cumulative_lengths[i]))[0]
        projected_j = geometry.project(midpoint, hint_progress=float(geometry.cumulative_lengths[j]))[0]
        self.assertLessEqual(_circular_index_gap(projected_i, i, len(geometry.centerline)), 12)
        self.assertLessEqual(_circular_index_gap(projected_j, j, len(geometry.centerline)), 12)
        self.assertNotEqual(projected_i, projected_j)


if __name__ == "__main__":
    unittest.main()
