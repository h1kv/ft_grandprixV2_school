from __future__ import annotations

from pathlib import Path
import math
import tempfile
import unittest

import numpy as np

from aigp.advanced_mjcf import (
    CURB_BOTTOM_MARGIN,
    CURB_LENGTH_OVERLAP,
    CURB_SINK_DEPTH,
    CURB_WIDTH_PAD,
    WALL_BOTTOM_MARGIN,
    WALL_LENGTH_OVERLAP,
    WALL_SINK_DEPTH,
    _build_curb_mesh_files,
    _build_wall_mesh_files,
    _segment_bottom_clearance,
    _segment_pose,
    _segment_visual_size,
)
from aigp.advanced_track import discover_advanced_tracks, load_advanced_track_spec, load_advanced_world
from aigp.track import TrackSettings


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _obj_vertices(paths: list[Path]) -> np.ndarray:
    vertices: list[list[float]] = []
    for path in paths:
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.startswith("v "):
                continue
            _prefix, x, y, z = line.split()
            vertices.append([float(x), float(y), float(z)])
    return np.asarray(vertices, dtype=np.float32)


class AdvancedTrackTests(unittest.TestCase):
    def test_discover_advanced_tracks_finds_shipped_tracks(self) -> None:
        tracks = discover_advanced_tracks(PROJECT_ROOT / "template")
        self.assertIn("alpine", tracks)
        self.assertIn("summit", tracks)

    def test_missing_heightmap_raises_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_dir = Path(temp_dir) / "template"
            advanced_dir = template_dir / "advanced" / "broken"
            advanced_dir.mkdir(parents=True)
            (advanced_dir / "advanced.toml").write_text(
                "display_name = 'Broken'\n"
                "base_track = 'track'\n"
                "\n"
                "[terrain]\n"
                "heightmap = 'missing.png'\n",
                encoding="utf-8",
            )
            with self.assertRaisesRegex(ValueError, "heightmap"):
                load_advanced_track_spec(template_dir, "broken")

    def test_curve_progress_one_is_preserved_as_endpoint(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_dir = Path(temp_dir) / "template"
            advanced_dir = template_dir / "advanced" / "endpoint"
            advanced_dir.mkdir(parents=True)
            (advanced_dir / "advanced.toml").write_text(
                "display_name = 'Endpoint'\n"
                "base_track = 'track'\n"
                "\n"
                "[elevation]\n"
                "points = [\n"
                "  { progress = 0.0, height = 0.0 },\n"
                "  { progress = 1.0, height = 3.5 },\n"
                "]\n",
                encoding="utf-8",
            )

            spec = load_advanced_track_spec(template_dir, "endpoint")

        self.assertEqual(spec.elevation_points[-1].progress, 1.0)
        self.assertEqual(spec.elevation_points[-1].value, 3.5)

    def test_curve_progress_outside_unit_interval_raises_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_dir = Path(temp_dir) / "template"
            advanced_dir = template_dir / "advanced" / "badprogress"
            advanced_dir.mkdir(parents=True)
            (advanced_dir / "advanced.toml").write_text(
                "display_name = 'Bad Progress'\n"
                "base_track = 'track'\n"
                "\n"
                "[bank]\n"
                "points = [{ progress = 1.2, degrees = 4.0 }]\n",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ValueError, "progress"):
                load_advanced_track_spec(template_dir, "badprogress")

    def test_terrain_mesh_resolution_is_bounded(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            template_dir = Path(temp_dir) / "template"
            advanced_dir = template_dir / "advanced" / "hugeterrain"
            advanced_dir.mkdir(parents=True)
            (advanced_dir / "advanced.toml").write_text(
                "display_name = 'Huge Terrain'\n"
                "base_track = 'track'\n"
                "\n"
                "[terrain]\n"
                "mesh_resolution = 1000\n",
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ValueError, "mesh_resolution"):
                load_advanced_track_spec(template_dir, "hugeterrain")

    def test_advanced_world_scales_with_track_settings(self) -> None:
        template_dir = PROJECT_ROOT / "template"
        base_settings = TrackSettings(name="alpine", track_scale=1.0)
        geometry_a, world_a = load_advanced_world(template_dir, base_settings)
        geometry_b, world_b = load_advanced_world(template_dir, TrackSettings(name="alpine", track_scale=0.80))

        self.assertNotAlmostEqual(geometry_a.total_length, geometry_b.total_length, delta=0.1)
        self.assertEqual(world_a.road_centerline_3d.shape[1], 3)
        self.assertEqual(world_b.road_centerline_3d.shape[1], 3)

    def test_advanced_boundaries_preserve_exact_2d_track_edges(self) -> None:
        template_dir = PROJECT_ROOT / "template"
        geometry, world = load_advanced_world(template_dir, TrackSettings(name="alpine", track_scale=1.0))

        self.assertEqual(world.track_inner_3d.shape[0], geometry.track_inner.shape[0])
        self.assertEqual(world.track_outer_3d.shape[0], geometry.track_outer.shape[0])
        self.assertEqual(world.inner_curb_3d.shape[0], geometry.inner_curb.shape[0])
        self.assertEqual(world.outer_curb_3d.shape[0], geometry.outer_curb.shape[0])

        self.assertTrue((abs(world.track_inner_3d[:, :2] - geometry.track_inner) < 1e-5).all())
        self.assertTrue((abs(world.track_outer_3d[:, :2] - geometry.track_outer) < 1e-5).all())
        self.assertTrue((abs(world.inner_curb_3d[:, :2] - geometry.inner_curb) < 1e-5).all())
        self.assertTrue((abs(world.outer_curb_3d[:, :2] - geometry.outer_curb) < 1e-5).all())
        self.assertTrue((abs(world.inner_wall_3d[:, :2] - geometry.inner_wall_face) < 1e-5).all())
        self.assertTrue((abs(world.outer_wall_3d[:, :2] - geometry.outer_wall_face) < 1e-5).all())

    def test_terrain_render_height_stays_below_the_road_corridor(self) -> None:
        template_dir = PROJECT_ROOT / "template"
        geometry, world = load_advanced_world(template_dir, TrackSettings(name="alpine", track_scale=1.0))
        point, _tangent, _normal = geometry.point_at(geometry.total_length * 0.25)
        road_sample = world.sample_surface(point)
        terrain_height = world.terrain_render_height(point)

        self.assertIsNotNone(terrain_height)
        assert terrain_height is not None
        self.assertLess(terrain_height, road_sample.height - 0.05)

    def test_advanced_wall_and_curb_visuals_embed_into_surface(self) -> None:
        template_dir = PROJECT_ROOT / "template"
        geometry, world = load_advanced_world(template_dir, TrackSettings(name="alpine", track_scale=1.0))

        worst_wall_gap = -999.0
        for segment in geometry.wall_segments:
            size = _segment_visual_size(
                segment,
                length_overlap=WALL_LENGTH_OVERLAP,
                sink_depth=WALL_SINK_DEPTH,
            )
            position, euler = _segment_pose(
                world,
                segment,
                size=size,
                sink_depth=WALL_SINK_DEPTH,
                bottom_margin=WALL_BOTTOM_MARGIN,
            )
            worst_wall_gap = max(
                worst_wall_gap,
                _segment_bottom_clearance(world, position=position, euler=euler, size=size),
            )

        worst_curb_gap = -999.0
        for segment in geometry.curb_segments:
            size = _segment_visual_size(
                segment,
                length_overlap=CURB_LENGTH_OVERLAP,
                sink_depth=CURB_SINK_DEPTH,
                width_pad=CURB_WIDTH_PAD,
            )
            position, euler = _segment_pose(
                world,
                segment,
                size=size,
                sink_depth=CURB_SINK_DEPTH,
                bottom_margin=CURB_BOTTOM_MARGIN,
            )
            worst_curb_gap = max(
                worst_curb_gap,
                _segment_bottom_clearance(world, position=position, euler=euler, size=size),
            )

        self.assertLessEqual(worst_wall_gap, -WALL_BOTTOM_MARGIN * 0.4)
        self.assertLessEqual(worst_curb_gap, -CURB_BOTTOM_MARGIN * 0.4)

    def test_advanced_wall_segments_keep_their_inner_faces_on_the_wall_curves(self) -> None:
        template_dir = PROJECT_ROOT / "template"
        geometry, _world = load_advanced_world(template_dir, TrackSettings(name="alpine", track_scale=1.0))
        half = len(geometry.wall_segments) // 2

        for offset, face_points in ((0, geometry.outer_wall_face), (half, geometry.inner_wall_face)):
            sample_step = max(1, len(face_points) // 12)
            for index in range(0, len(face_points), sample_step):
                segment = geometry.wall_segments[offset + index]
                tangent = np.array([math.cos(segment.yaw), math.sin(segment.yaw)], dtype=np.float32)
                normal = np.array([-tangent[1], tangent[0]], dtype=np.float32)
                face_mid = 0.5 * (
                    np.asarray(face_points[index], dtype=np.float32)
                    + np.asarray(face_points[(index + 1) % len(face_points)], dtype=np.float32)
                )
                inward_face = np.asarray(segment.position[:2], dtype=np.float32) - normal * float(segment.size[1])
                outward_face = np.asarray(segment.position[:2], dtype=np.float32) + normal * float(segment.size[1])
                best = inward_face if np.linalg.norm(inward_face - face_mid) <= np.linalg.norm(outward_face - face_mid) else outward_face
                np.testing.assert_allclose(best, face_mid, atol=1e-4)

    def test_advanced_visual_meshes_share_exact_road_curb_and_wall_edges(self) -> None:
        template_dir = PROJECT_ROOT / "template"
        geometry, world = load_advanced_world(template_dir, TrackSettings(name="alpine", track_scale=1.0))
        with tempfile.TemporaryDirectory() as temp_dir:
            temp_path = Path(temp_dir)
            curb_paths = _build_curb_mesh_files(
                session_dir=temp_path,
                geometry=geometry,
                world=world,
                reduced_scene_complexity=False,
            )
            wall_paths = _build_wall_mesh_files(
                session_dir=temp_path,
                geometry=geometry,
                world=world,
                reduced_scene_complexity=False,
            )
            curb_vertices = _obj_vertices(list(curb_paths.values()))
            wall_vertices = _obj_vertices(list(wall_paths.values()))

        sample_step = max(1, len(geometry.centerline) // 18)
        for edge_points in (world.track_inner_3d, world.track_outer_3d):
            for point in edge_points[::sample_step]:
                distances = np.linalg.norm(curb_vertices - point.astype(np.float32), axis=1)
                self.assertLess(float(np.min(distances)), 1e-4)

        for face_points in (world.inner_wall_3d, world.outer_wall_3d):
            for point in face_points[::sample_step]:
                xy_distances = np.linalg.norm(wall_vertices[:, :2] - point[:2].astype(np.float32), axis=1)
                self.assertLess(float(np.min(xy_distances)), 1e-4)


if __name__ == "__main__":
    unittest.main()
