@echo off
setlocal
cd /d "%~dp0"

echo Formula Trinity GP - Windows setup
echo.
echo This creates a local .venv folder and installs the runtime dependencies.
echo You only need to run this again when dependencies change.
echo.

set "PY_CMD="
set "PY_ARGS="
where py >nul 2>nul
if not errorlevel 1 (
    set "PY_CMD=py"
    set "PY_ARGS=-3"
)
if "%PY_CMD%"=="" (
    where python >nul 2>nul
    if not errorlevel 1 set "PY_CMD=python"
)
if "%PY_CMD%"=="" (
    for %%V in (313 312 311 310) do (
        if exist "%LocalAppData%\Programs\Python\Python%%V\python.exe" set "PY_CMD=%LocalAppData%\Programs\Python\Python%%V\python.exe"
    )
)

if "%PY_CMD%"=="" (
    echo Python was not found.
    echo Install Python 3.12 or newer from https://www.python.org/downloads/windows/
    echo Make sure "Add python.exe to PATH" is selected during install.
    pause
    exit /b 1
)

echo Using: %PY_CMD%
"%PY_CMD%" %PY_ARGS% -m venv .venv
if errorlevel 1 (
    echo Failed to create .venv.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 (
    echo Failed to update pip.
    pause
    exit /b 1
)

python -m pip install -r requirements.txt
if errorlevel 1 (
    echo Failed to install requirements.
    echo If this laptop is offline, connect it to the internet and run this setup again.
    pause
    exit /b 1
)

echo.
echo Setup complete. You can now double-click "AIGP Launcher.bat".
pause
