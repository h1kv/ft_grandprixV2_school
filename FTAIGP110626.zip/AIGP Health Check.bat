@echo off
setlocal
cd /d "%~dp0"

call "AIGP Launcher.bat" --action health
