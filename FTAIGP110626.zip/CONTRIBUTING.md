# Contributing To AIGPV2

This repository is meant to be usable by both competitors and maintainers. Don't push or edit GP code as a competitor.

## First Steps

From the repository root:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m unittest discover -s tests -v
python -m aigp
```

## Main Docs

- Project overview: `README.md`
- Competitor/operator usage: `docs/RUNNING_AND_BUILDING_CARS.md`
- Runtime architecture and maintenance: `docs/DEVELOPMENT.md`

## Working Areas

- `aigp/`: runtime, UI, track logic, MuJoCo integration
- `drivers/`: active sample/scaffold drivers only
- `template/`: track assets and the default race grid
- `tests/`: regression coverage

## Expectations For Changes

- Keep competitor drivers as single Python files.
- Add or update regression tests when fixing runtime bugs.
- Prefer editing docs when changing user-visible behavior or controls.
- Keep generated output and local experiments out of the live repo paths.


### Core AIGPV2 code by Conor Moran based on the ideas and layout of AIGPV1 written by Chinaza Uzoukwu
- Designed for drivers to be back-compatable with AIGPV1 driver files.