@echo off
setlocal
cd /d "%~dp0"

set "PY_CMD="
set "PY_ARGS="
if exist ".venv\Scripts\python.exe" set "PY_CMD=.venv\Scripts\python.exe"
if "%PY_CMD%"=="" (
    where py >nul 2>nul
    if not errorlevel 1 (
        set "PY_CMD=py"
        set "PY_ARGS=-3"
    )
)
if "%PY_CMD%"=="" (
    where python >nul 2>nul
    if not errorlevel 1 set "PY_CMD=python"
)
if "%PY_CMD%"=="" (
    for %%V in (313 312 311 310) do (
        if exist "%LocalAppData%\Programs\Python\Python%%V\python.exe" set "PY_CMD=%LocalAppData%\Programs\Python\Python%%V\python.exe"
    )
)

if "%PY_CMD%"=="" (
    echo Python was not found.
    echo Run "AIGP Setup Windows.bat" after installing Python 3.12 or newer.
    pause
    exit /b 1
)

"%PY_CMD%" %PY_ARGS% "tools\aigp_windows_launcher.py" --menu diagnostic %*
pause
